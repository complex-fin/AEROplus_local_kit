# AERO+ 实验报告（自动生成）

- 模式：**FULL**（校准集已拟合，检验有效）
- 原始记录：test 11 条；cal 60 条
- 超参：beta=0.5, alpha_s=1.5, gamma={'text': 0.606, 'N': 0.655, 'S': 0.606, 'f': 0.97}
- 源相关（校准集）：{'rho_text_N': 0.498, 'rho_text_S': 0.788, 'rho_text_f': 0.06, 'rho_N_S': 0.69, 'rho_N_f': -0.054, 'rho_S_f': -0.028}
- 校准参数 theta=[1.092, 0.316, 0.009, -0.766] (z1, z2, c0, b3)
- alpha* = 0.05（λ-风险最优）

## 系统对比（测试项）

| 系统 | n | acc | coverage | miss | overclaim | abstain(real) | abstain(neg) | λ-risk |
|---|---|---|---|---|---|---|---|---|
| AERO+ full | 11 | 0.55 | 1.00 | 0.45 | 0.00 | 0.00 | 0.00 | 0.303 |
| AERO+ plainds | 11 | 0.73 | 1.00 | 0.27 | 0.00 | 0.00 | 0.00 | 0.182 |
| AERO+ nocf | 11 | 0.09 | 1.00 | 0.91 | 0.00 | 0.00 | 0.00 | 0.606 |
| AERO+ nods | 11 | 0.64 | 1.00 | 0.36 | 0.00 | 0.00 | 0.00 | 0.242 |

（基线无弃权——λ-risk 不含弃权代价；AERO+ 的公平比较需基线校准集运行后另行报告）

## 与已发表基线/SOTA 对比

| dataset | system | kind | value | source |
|---|---|---|---|---|
| COPA (val acc) | fine-tuned DeBERTa/UnifiedQA class | published | pending citation | SuperGLUE leaderboard; cite snapshot date when quoting |
| custom (FULL) | AERO+ full | our-run | 0.545 | this work |
| custom (FULL) | AERO+ plainds | our-run | 0.727 | this work |
| custom (FULL) | AERO+ nocf | our-run | 0.091 | this work |
| custom (FULL) | AERO+ nods | our-run | 0.636 | this work |

（value=null 的行是占位——引用核实后回填 download/baselines_published.json，禁止估计填数）

## 假设检验
```json
{
 "H5 N": {
  "auc": 0.789,
  "ci": [
   0.529,
   1.0
  ],
  "perm_p": 0.0067
 },
 "H5 S": {
  "auc": 0.855,
  "ci": [
   0.632,
   1.0
  ],
  "perm_p": 0.0015
 },
 "H5 (N+S)/2": {
  "auc": 0.839,
  "ci": [
   0.607,
   1.0
  ],
  "perm_p": 0.0027
 },
 "H6 full vs plainds": {
  "dAUC": 0.05,
  "ci": [
   -0.066,
   0.215
  ]
 },
 "H6 full vs nods": {
  "dAUC": -0.033,
  "ci": [
   -0.091,
   0.0
  ]
 },
 "H6 AUC full": {
  "auc": 0.876,
  "ci": [
   0.628,
   1.0
  ]
 },
 "H6 AUC plainds": {
  "auc": 0.826,
  "ci": [
   0.579,
   1.0
  ]
 },
 "H6 AUC nods": {
  "auc": 0.909,
  "ci": [
   0.669,
   1.0
  ]
 },
 "H4": {
  "brier_betp": 0.121,
  "brier_cal": 0.135,
  "logloss_betp": 0.382,
  "logloss_cal": 0.417
 },
 "H3": {
  "0.05": {
   "empirical_cov": 1.0,
   "target": 0.95,
   "mean_set_size": 2.82,
   "abstain_rate": 0.0
  },
  "0.1": {
   "empirical_cov": 0.909,
   "target": 0.9,
   "mean_set_size": 2.27,
   "abstain_rate": 0.0
  },
  "0.15": {
   "empirical_cov": 0.727,
   "target": 0.85,
   "mean_set_size": 1.64,
   "abstain_rate": 0.0
  },
  "0.2": {
   "empirical_cov": 0.727,
   "target": 0.8,
   "mean_set_size": 1.36,
   "abstain_rate": 0.0
  },
  "0.25": {
   "empirical_cov": 0.727,
   "target": 0.75,
   "mean_set_size": 1.36,
   "abstain_rate": 0.0
  },
  "0.3": {
   "empirical_cov": 0.727,
   "target": 0.7,
   "mean_set_size": 1.09,
   "abstain_rate": 0.0
  }
 },
 "H7": {
  "chi2": 2.383,
  "p": 0.1227,
  "b3": -0.766
 }
}
```

## α 网格上的校准集风险

| α | risk | miss | over | abs(real) | abs(neg) | coverage |
|---|---|---|---|---|---|---|
| 0.05 | 0.400 | 0.35 | 0.25 | 0.00 | 0.00 | 0.72 |
| 0.10 | 0.400 | 0.35 | 0.25 | 0.00 | 0.00 | 0.72 |
| 0.15 | 0.400 | 0.35 | 0.25 | 0.00 | 0.00 | 0.72 |
| 0.20 | 0.400 | 0.35 | 0.25 | 0.00 | 0.00 | 0.72 |
| 0.25 | 0.400 | 0.35 | 0.25 | 0.00 | 0.00 | 0.72 |
| 0.30 | 0.400 | 0.35 | 0.25 | 0.00 | 0.00 | 0.72 |