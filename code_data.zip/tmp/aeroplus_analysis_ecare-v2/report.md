# AERO+ 实验报告（自动生成）

- 模式：**FULL**（校准集已拟合，检验有效）
- 原始记录：test 79 条；cal 40 条
- 超参：beta=0.5, alpha_s=1.5, gamma={'text': 0.552, 'N': 0.693, 'S': 0.552, 'f': 0.911}
- 源相关（校准集）：{'rho_text_N': 0.598, 'rho_text_S': 0.895, 'rho_text_f': 0.177, 'rho_N_S': 0.613, 'rho_N_f': 0.112, 'rho_S_f': 0.108}
- 校准参数 theta=[1.228, -0.374, 0.152, 1.163] (z1, z2, c0, b3)
- alpha* = 0.05（λ-风险最优）

## 系统对比（测试项）

| 系统 | n | acc | coverage | miss | overclaim | abstain(real) | abstain(neg) | λ-risk |
|---|---|---|---|---|---|---|---|---|
| AERO+ full | 79 | 0.82 | 1.00 | 0.21 | 0.15 | 0.00 | 0.00 | 0.237 |
| AERO+ plainds | 79 | 0.80 | 1.00 | 0.23 | 0.17 | 0.00 | 0.00 | 0.271 |
| AERO+ nocf | 79 | 0.67 | 1.00 | 0.59 | 0.07 | 0.00 | 0.00 | 0.443 |
| AERO+ nods | 79 | 0.77 | 1.00 | 0.28 | 0.17 | 0.00 | 0.00 | 0.305 |
| zero-shot | 39 | 0.77 | 1.00 | 0.24 | 0.00 | 0.00 | 0.00 | 0.162 |
| CoT | 30 | 0.87 | 1.00 | 0.30 | 0.05 | 0.00 | 0.00 | 0.233 |
| aero_nocf(v1) | 49 | 0.86 | 1.00 | 0.10 | 0.21 | 0.00 | 0.00 | 0.207 |

（基线无弃权——λ-risk 不含弃权代价；AERO+ 的公平比较需基线校准集运行后另行报告）

## 与已发表基线/SOTA 对比

| dataset | system | kind | value | source |
|---|---|---|---|---|
| COPA (val acc) | fine-tuned DeBERTa/UnifiedQA class | published | pending citation | SuperGLUE leaderboard; cite snapshot date when quoting |
| ecare (FULL) | AERO+ full | our-run | 0.823 | this work |
| ecare (FULL) | AERO+ plainds | our-run | 0.797 | this work |
| ecare (FULL) | AERO+ nocf | our-run | 0.671 | this work |
| ecare (FULL) | AERO+ nods | our-run | 0.772 | this work |

（value=null 的行是占位——引用核实后回填 download/baselines_published.json，禁止估计填数）

## 假设检验
```json
{
 "H5 N": {
  "auc": 0.859,
  "ci": [
   0.795,
   0.914
  ],
  "perm_p": 0.0
 },
 "H5 S": {
  "auc": 0.932,
  "ci": [
   0.88,
   0.971
  ],
  "perm_p": 0.0
 },
 "H5 (N+S)/2": {
  "auc": 0.932,
  "ci": [
   0.888,
   0.967
  ],
  "perm_p": 0.0
 },
 "H6 full vs plainds": {
  "dAUC": 0.002,
  "ci": [
   -0.008,
   0.012
  ]
 },
 "H6 full vs nods": {
  "dAUC": 0.007,
  "ci": [
   -0.004,
   0.019
  ]
 },
 "H6 AUC full": {
  "auc": 0.956,
  "ci": [
   0.92,
   0.981
  ]
 },
 "H6 AUC plainds": {
  "auc": 0.954,
  "ci": [
   0.918,
   0.98
  ]
 },
 "H6 AUC nods": {
  "auc": 0.949,
  "ci": [
   0.911,
   0.978
  ]
 },
 "H1 full vs nocf (negatives)": {
  "over_full": 6,
  "over_nocf": 3,
  "discordant": [
   4,
   1
  ],
  "mcnemar_p": 0.375
 },
 "H4": {
  "brier_betp": 0.232,
  "brier_cal": 0.261,
  "logloss_betp": 0.638,
  "logloss_cal": 0.766
 },
 "H3": {
  "0.05": {
   "empirical_cov": 0.734,
   "target": 0.95,
   "mean_set_size": 2.25,
   "abstain_rate": 0.0
  },
  "0.1": {
   "empirical_cov": 0.734,
   "target": 0.9,
   "mean_set_size": 2.23,
   "abstain_rate": 0.0
  },
  "0.15": {
   "empirical_cov": 0.734,
   "target": 0.85,
   "mean_set_size": 1.94,
   "abstain_rate": 0.0
  },
  "0.2": {
   "empirical_cov": 0.734,
   "target": 0.8,
   "mean_set_size": 1.87,
   "abstain_rate": 0.0
  },
  "0.25": {
   "empirical_cov": 0.731,
   "target": 0.75,
   "mean_set_size": 1.78,
   "abstain_rate": 0.013
  },
  "0.3": {
   "empirical_cov": 0.718,
   "target": 0.7,
   "mean_set_size": 1.77,
   "abstain_rate": 0.013
  }
 },
 "H7": {
  "chi2": 3.008,
  "p": 0.0829,
  "b3": 1.163
 }
}
```

## α 网格上的校准集风险

| α | risk | miss | over | abs(real) | abs(neg) | coverage |
|---|---|---|---|---|---|---|
| 0.05 | 0.300 | 0.35 | 0.10 | 0.00 | 0.00 | 0.78 |
| 0.10 | 0.300 | 0.35 | 0.10 | 0.00 | 0.00 | 0.78 |
| 0.15 | 0.300 | 0.35 | 0.10 | 0.00 | 0.00 | 0.78 |
| 0.20 | 0.300 | 0.35 | 0.10 | 0.00 | 0.00 | 0.78 |
| 0.25 | 0.300 | 0.35 | 0.10 | 0.00 | 0.00 | 0.78 |
| 0.30 | 0.300 | 0.35 | 0.10 | 0.00 | 0.00 | 0.78 |