# AERO+ 实验报告（自动生成）

- 模式：**FULL**（校准集已拟合，检验有效）
- 原始记录：test 60 条；cal 30 条
- 超参：beta=0.75, alpha_s=1.5, gamma={'text': 0.364, 'N': 0.467, 'S': 0.364, 'f': 0.915, 'kg': 0.862}
- 源相关（校准集）：{'rho_text_N': 0.711, 'rho_text_S': 0.847, 'rho_text_f': 0.036, 'rho_text_kg': 0.184, 'rho_N_S': 0.666, 'rho_N_f': 0.059, 'rho_N_kg': 0.129, 'rho_S_f': -0.113, 'rho_S_kg': 0.087, 'rho_f_kg': -0.063}
- 校准参数 theta=[5.948, -1.062, 2.2, 2.398] (z1, z2, c0, b3)
- alpha* = 0.05（λ-风险最优）

## 系统对比（测试项）

| 系统 | n | acc | coverage | miss | overclaim | abstain(real) | abstain(neg) | λ-risk |
|---|---|---|---|---|---|---|---|---|
| AERO+ full | 60 | 0.88 | 1.00 | 0.12 | 0.00 | 0.00 | 0.00 | 0.117 |
| AERO+ plainds | 60 | 0.97 | 1.00 | 0.03 | 0.00 | 0.00 | 0.00 | 0.033 |
| AERO+ nocf | 60 | 0.35 | 1.00 | 0.65 | 0.00 | 0.00 | 0.00 | 0.650 |
| AERO+ nods | 60 | 0.93 | 1.00 | 0.07 | 0.00 | 0.00 | 0.00 | 0.067 |

（基线无弃权——λ-risk 不含弃权代价；AERO+ 的公平比较需基线校准集运行后另行报告）

## 与已发表基线/SOTA 对比

| dataset | system | kind | value | source |
|---|---|---|---|---|
| COPA (val acc) | fine-tuned DeBERTa/UnifiedQA class | published | pending citation | SuperGLUE leaderboard; cite snapshot date when quoting |
| copa (FULL) | AERO+ full | our-run | 0.883 | this work |
| copa (FULL) | AERO+ plainds | our-run | 0.967 | this work |
| copa (FULL) | AERO+ nocf | our-run | 0.35 | this work |
| copa (FULL) | AERO+ nods | our-run | 0.933 | this work |

（value=null 的行是占位——引用核实后回填 download/baselines_published.json，禁止估计填数）

## 假设检验
```json
{
 "H5 N": {
  "auc": 0.874,
  "ci": [
   0.815,
   0.931
  ],
  "perm_p": 0.0
 },
 "H5 S": {
  "auc": 0.998,
  "ci": [
   0.994,
   1.0
  ],
  "perm_p": 0.0
 },
 "H5 (N+S)/2": {
  "auc": 0.997,
  "ci": [
   0.991,
   1.0
  ],
  "perm_p": 0.0
 },
 "H6 full vs plainds": {
  "dAUC": -0.005,
  "ci": [
   -0.015,
   0.0
  ]
 },
 "H6 full vs nods": {
  "dAUC": -0.005,
  "ci": [
   -0.014,
   0.0
  ]
 },
 "H6 AUC full": {
  "auc": 0.995,
  "ci": [
   0.985,
   1.0
  ]
 },
 "H6 AUC plainds": {
  "auc": 1.0,
  "ci": [
   1.0,
   1.0
  ]
 },
 "H6 AUC nods": {
  "auc": 1.0,
  "ci": [
   0.998,
   1.0
  ]
 },
 "H4": {
  "brier_betp": 0.248,
  "brier_cal": 0.076,
  "logloss_betp": 0.688,
  "logloss_cal": 0.25
 },
 "H3": {
  "0.05": {
   "empirical_cov": 1.0,
   "target": 0.95,
   "mean_set_size": 3.0,
   "abstain_rate": 0.0
  },
  "0.1": {
   "empirical_cov": 1.0,
   "target": 0.9,
   "mean_set_size": 1.67,
   "abstain_rate": 0.0
  },
  "0.15": {
   "empirical_cov": 1.0,
   "target": 0.85,
   "mean_set_size": 1.28,
   "abstain_rate": 0.0
  },
  "0.2": {
   "empirical_cov": 0.867,
   "target": 0.8,
   "mean_set_size": 1.13,
   "abstain_rate": 0.0
  },
  "0.25": {
   "empirical_cov": 0.843,
   "target": 0.75,
   "mean_set_size": 1.02,
   "abstain_rate": 0.15
  },
  "0.3": {
   "empirical_cov": 0.977,
   "target": 0.7,
   "mean_set_size": 1.0,
   "abstain_rate": 0.267
  }
 },
 "H7": {
  "chi2": 9.405,
  "p": 0.0022,
  "b3": 2.398
 }
}
```

## α 网格上的校准集风险

| α | risk | miss | over | abs(real) | abs(neg) | coverage |
|---|---|---|---|---|---|---|
| 0.05 | 0.150 | 0.15 | 0.00 | 0.00 | 0.00 | 0.90 |
| 0.10 | 0.150 | 0.15 | 0.00 | 0.00 | 0.00 | 0.90 |
| 0.15 | 0.150 | 0.15 | 0.00 | 0.00 | 0.00 | 0.90 |
| 0.20 | 0.150 | 0.15 | 0.00 | 0.00 | 0.00 | 0.90 |
| 0.25 | 0.150 | 0.15 | 0.00 | 0.00 | 0.00 | 0.90 |
| 0.30 | 0.150 | 0.15 | 0.00 | 0.00 | 0.00 | 0.90 |