# FinSoC-en v2 仲裁评测·小规模版（tag=finsoc-en）
冻结参数：PM_TAU=0.3, TRIG_TCONF=0.8, K_VOTES=3（e-CARE dev 冻结，零重拟合）

## 0. 数据齐全性
- aero_test=1040  aero_cal=100  cot_cal=100  cot_test=1040  sc3_cal=100  v1_preds=1040

## 1. Step① 产物：cal 上选定歧义默认方向（零 API，纯离线）
- cal 分歧项 n=19：探针对 12，CoT 对 7（二项符号检验 p=0.359；双方皆错 0）
- cal 全集：plainds 0.860 vs CoT 0.810
**选定歧义默认方向 = probe**

## 2. Step② 产物：冻结规则全流程在 cal 复演（机制检查，非调参）
- 冻结规则全流程 acc = 0.890（参照 cal：plainds 0.860 / CoT 0.810，n=100）
- 触发率 0.22，CoT 错误（n=19）召回 0.53
- 机制对照：票不一致单独触发率 0.10/召回 0.16；conf<0.8 单独触发率 0.17/召回 0.53

## 3. test 终评（n=1040，conf-only 触发 + 冻结仲裁默认=probe，零新增采集）
| 系统 | acc |
|---|---|
| CoT | 0.781 |
| plainds（证据层） | 0.864 |
| v2_selective(conf触发) | 0.870 |
| 敏感：默认反向(cot) | 0.815 |
| v1 AERO+ full（官方） | 0.798 |
| v2_selective(全冻结触发,子集) | 0.869 |

敏感性行（tc 网格，非冻结参数，不用于主张）：
- tc=0.7: acc=0.831
- tc=0.85: acc=0.874
- tc=0.9: acc=0.878

### 配对检验（McNemar 精确 + bootstrap 95% CI）
- v2_confonly vs CoT: Δ=+0.089 [+0.070,+0.110]  b/c=108/15  p=0.0000
- v2_confonly vs plainds: Δ=+0.006 [-0.007,+0.019]  b/c=27/21  p=0.4709
- v2_confonly vs v1_official: Δ=+0.072 [+0.051,+0.093]  b/c=105/30  p=0.0000

### 触发与检测统计
- 触发率 0.204；CoT 错误（n=228）召回 0.667；触发精度 0.717
- 未触发子集上 CoT acc = 0.908
- cot~plainds 一致率 0.834；分歧项上 plainds 对 = 0.746