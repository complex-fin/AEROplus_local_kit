# FinSoC-zh v2 仲裁评测·小规模版（tag=finsoc-zh）
冻结参数：PM_TAU=0.3, TRIG_TCONF=0.8, K_VOTES=3（e-CARE dev 冻结，零重拟合）

## 0. 数据齐全性
- aero_test=1040  aero_cal=100  cot_cal=100  cot_test=1040  sc3_cal=100  v1_preds=1040

## 1. Step① 产物：cal 上选定歧义默认方向（零 API，纯离线）
- cal 分歧项 n=14：探针对 10，CoT 对 4（二项符号检验 p=0.180；双方皆错 0）
- cal 全集：plainds 0.870 vs CoT 0.810
**选定歧义默认方向 = probe**

## 2. Step② 产物：冻结规则全流程在 cal 复演（机制检查，非调参）
- 冻结规则全流程 acc = 0.890（参照 cal：plainds 0.870 / CoT 0.810，n=100）
- 触发率 0.21，CoT 错误（n=19）召回 0.58
- 机制对照：票不一致单独触发率 0.07/召回 0.26；conf<0.8 单独触发率 0.18/召回 0.47

## 3. test 终评（n=1040，conf-only 触发 + 冻结仲裁默认=probe，零新增采集）
| 系统 | acc |
|---|---|
| CoT | 0.798 |
| plainds（证据层） | 0.854 |
| v2_selective(conf触发) | 0.881 |
| 敏感：默认反向(cot) | 0.829 |
| v1 AERO+ full（官方） | 0.822 |
| v2_selective(全冻结触发,子集) | 0.925 |

敏感性行（tc 网格，非冻结参数，不用于主张）：
- tc=0.7: acc=0.833
- tc=0.85: acc=0.879
- tc=0.9: acc=0.875

### 配对检验（McNemar 精确 + bootstrap 95% CI）
- v2_confonly vs CoT: Δ=+0.083 [+0.063,+0.103]  b/c=100/14  p=0.0000
- v2_confonly vs plainds: Δ=+0.027 [+0.012,+0.043]  b/c=49/21  p=0.0011
- v2_confonly vs v1_official: Δ=+0.059 [+0.038,+0.080]  b/c=93/32  p=0.0000

### 触发与检测统计
- 触发率 0.184；CoT 错误（n=210）召回 0.624；触发精度 0.686
- 未触发子集上 CoT acc = 0.907
- cot~plainds 一致率 0.816；分歧项上 plainds 对 = 0.634