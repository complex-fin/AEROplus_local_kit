@echo off
REM =============================================================================
REM AERO+ v4 full local pipeline driver -- Windows version of run_local_v4.sh
REM Usage:
REM   scripts\run_local_v4.bat verify    (smoke: 2 items per system, full chain)
REM   scripts\run_local_v4.bat collect   (full collection, resumable)
REM   scripts\run_local_v4.bat analyze   (offline analysis + stats, zero API calls)
REM Requires: node >= 18, python >= 3.10 (as "python" or "py -3"), pip deps installed.
REM =============================================================================
setlocal EnableExtensions
cd /d "%~dp0.."

set "MODE=%~1"
if "%MODE%"=="" set "MODE=verify"
set "LIMIT="
if /i "%MODE%"=="verify" set "LIMIT=--limit 2"

set "PY=python"
where python >nul 2>nul || set "PY=py -3"
where node >nul 2>nul || (echo [ERROR] node not found in PATH & exit /b 1)
%PY% --version >nul 2>nul || (echo [ERROR] python not found in PATH & exit /b 1)

if /i "%MODE%"=="verify"  (call :collect || exit /b 1)
if /i "%MODE%"=="verify"  (call :analyze || exit /b 1)
if /i "%MODE%"=="verify"  goto :done
if /i "%MODE%"=="collect" (call :collect || exit /b 1)
if /i "%MODE%"=="collect" goto :done
if /i "%MODE%"=="analyze" (call :analyze || exit /b 1)
if /i "%MODE%"=="analyze" goto :done
echo Usage: scripts\run_local_v4.bat {verify^|collect^|analyze}
exit /b 1

:done
echo [run_local_v4] %MODE% finished OK
exit /b 0

REM ---------------------------------------------------------------------------
:collect
REM step 0: XCOPA item generation (idempotent, needs pyarrow)
if not exist "tmp\xcopa_zh_test.jsonl" (
  echo [0] Generating XCOPA items zh/vi/th/sw ...
  %PY% scripts\aeroplus\make_xcopa_items.py || exit /b 1
)
REM step 1a: e-CARE 450 -- AERO+ and CF-CoT (output names: aero / cfcot)
echo [1] e-CARE 450 ^| aeroplus
node scripts\collect_v3.mjs --system aeroplus --input tmp\exp_items_v2.jsonl --output tmp\results_aero_exp.jsonl --conc 4 %LIMIT% || exit /b 1
echo [1] e-CARE 450 ^| cf_cot
node scripts\collect_v3.mjs --system cf_cot --input tmp\exp_items_v2.jsonl --output tmp\results_cfcot_exp.jsonl --conc 4 %LIMIT% || exit /b 1
REM step 1b: e-CARE 450 -- prompt baselines
for %%S in (cot selfcons zeroshot pnps sn_cot g2) do (
  echo [1] e-CARE 450 ^| %%S
  node scripts\run_exp.mjs --system %%S --input tmp\exp_items_v2.jsonl --output tmp\results_%%S_exp.jsonl --conc 4 %LIMIT% || exit /b 1
)
REM step 1c: baseline calibration on cal-60 (one-shot)
for %%S in (cot selfcons pnps sn_cot g2) do (
  echo [1] e-CARE cal-60 ^| %%S
  node scripts\run_exp.mjs --system %%S --input tmp\cal_items_v3.jsonl --output tmp\results_%%S_cal_v3.jsonl --conc 4 || exit /b 1
)
REM step 1d: XCOPA per language (aero + cot + cfcot, plus aero cal)
for %%L in (zh) do (
  echo [1] XCOPA %%L ^| aeroplus + cot + cf_cot
  node scripts\collect_v3.mjs --system aeroplus --input tmp\xcopa_%%L_test.jsonl --output tmp\results_aero_xc%%L.jsonl --conc 4 %LIMIT% || exit /b 1
  node scripts\run_exp.mjs   --system cot      --input tmp\xcopa_%%L_test.jsonl --output tmp\results_cot_xc%%L.jsonl  --conc 4 %LIMIT% || exit /b 1
  node scripts\collect_v3.mjs --system cf_cot  --input tmp\xcopa_%%L_test.jsonl --output tmp\results_cfcot_xc%%L.jsonl --conc 4 %LIMIT% || exit /b 1
  node scripts\collect_v3.mjs --system aeroplus --input tmp\xcopa_%%L_cal.jsonl --output tmp\results_aero_xc%%L_cal.jsonl --conc 4 || exit /b 1
)
exit /b 0

REM ---------------------------------------------------------------------------
:analyze
echo [2] e-CARE v4 main analysis (cal = frozen cal_v3) ...
%PY% scripts\aeroplus\run_offline.py --dataset ecare --raw tmp\results_aero_exp.jsonl --cal tmp\results_aeroplus_cal_v3.jsonl --tag ecare-v4 || exit /b 1
for %%L in (zh vi th sw) do (
  echo [2] XCOPA %%L analysis ...
  %PY% scripts\aeroplus\run_offline.py --dataset copa --raw tmp\results_aero_xc%%L.jsonl --cal tmp\results_aero_xc%%L_cal.jsonl --tag xc%%L || exit /b 1
)
echo [2] significance tests (McNemar / bootstrap / power) ...
%PY% scripts\aeroplus\stats_v4.py || exit /b 1
echo [2] selective-prediction baselines ...
%PY% scripts\aeroplus\selective_baselines.py --tag ecare-v4 --cot-cal tmp\results_cot_cal_v3.jsonl --cot-test tmp\results_cot_exp.jsonl --sc-cal tmp\results_selfcons_cal_v3.jsonl --sc-test tmp\results_selfcons_exp.jsonl --pnps-cal tmp\results_pnps_cal_v3.jsonl --pnps-test tmp\results_pnps_exp.jsonl --sncot-cal tmp\results_sn_cot_cal_v3.jsonl --sncot-test tmp\results_sn_cot_exp.jsonl --g2-cal tmp\results_g2_cal_v3.jsonl --g2-test tmp\results_g2_exp.jsonl || exit /b 1
exit /b 0
