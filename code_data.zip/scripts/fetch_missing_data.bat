@echo off
REM =============================================================================
REM Fetch missing raw data -- Windows version of fetch_missing_data.sh
REM Only the OPTIONAL finetune-baseline training data is missing from the kit;
REM everything needed for evaluation ships with the kit already.
REM Usage: scripts\fetch_missing_data.bat
REM Requires: curl (bundled with Windows 10+), python (as "python" or "py -3")
REM =============================================================================
setlocal EnableExtensions
cd /d "%~dp0.."
set "PY=python"
where python >nul 2>nul || set "PY=py -3"
%PY% --version >nul 2>nul || (echo [ERROR] python not found in PATH & exit /b 1)
where curl >nul 2>nul || (echo [ERROR] curl not found in PATH & exit /b 1)
if not exist tmp mkdir tmp
if not exist tmp\COPA mkdir tmp\COPA

echo [1/3] e-CARE train (official source, fallback chain)
if exist tmp\ecare_train.jsonl (
  echo [skip] tmp\ecare_train.jsonl already exists
) else (
  curl -sL -o tmp\ecare_train_raw.json "https://huggingface.co/datasets/12ml/e-CARE/resolve/main/causal_reasoning_train.json"
  if errorlevel 1 curl -sL -o tmp\ecare_train_raw.json "https://raw.githubusercontent.com/Waste-Wood/e-CARE/main/dataset/causal_reasoning_train.json"
  %PY% scripts\aeroplus\fetch_helpers.py convert-train
)

echo [2/3] COPA validation split (for the optional our-run finetune row)
if exist tmp\COPA\val.jsonl (
  echo [skip] tmp\COPA\val.jsonl already exists
) else (
  curl -sL -o tmp\COPA\val.parquet "https://huggingface.co/datasets/pkavumba/balanced-copa/resolve/main/data/validation-00000-of-00001.parquet"
  %PY% -c "import sys; sys.path.insert(0,'scripts/aeroplus'); import pyarrow.parquet as pq, json as j; t=pq.read_table('tmp/COPA/val.parquet').to_pylist(); open('tmp/COPA/val.jsonl','w').write('\n'.join(j.dumps(r) for r in t))" && echo [ok] converted val.parquet -^> val.jsonl || echo [warn] conversion failed; parquet kept for manual retry
)

echo [3/3] self-check
%PY% scripts\aeroplus\fetch_helpers.py check
echo [note] a missing e-CARE train does NOT affect evaluation; only the optional finetune baseline.
exit /b 0
