#!/usr/bin/env bash
# 补齐套件中缺失的原始数据（仅微调基线需要；评估所需数据已全部随包提供）
# 用法: bash scripts/fetch_missing_data.sh
set -uo pipefail
cd "$(dirname "$0")/.."

echo "[1/3] e-CARE train（官方源二选一）"
# 官方 repo: github.com/Waste-Wood/e-CARE（ACL 2022）
# HF 镜像:  huggingface.co/datasets/12ml/e-CARE
if [ ! -f tmp/ecare_train.jsonl ]; then
  mkdir -p tmp
  # 方式A: HF hub（推荐，需可访问 huggingface.co）
  curl -sL -o tmp/ecare_train_raw.json \
    "https://huggingface.co/datasets/12ml/e-CARE/resolve/main/causal_reasoning_train.json" \
  || curl -sL -o tmp/ecare_train_raw.json \
    "https://raw.githubusercontent.com/Waste-Wood/e-CARE/main/dataset/causal_reasoning_train.json"
  if [ -s tmp/ecare_train_raw.json ] && ! head -c 20 tmp/ecare_train_raw.json | grep -q "404\|<!DOCTYPE"; then
    python3 scripts/aeroplus/fetch_helpers.py convert-train
  else
    echo "[警告] 两个源均不可达。请手动下载 e-CARE train 并存为 tmp/ecare_train.jsonl"
    echo "  官方: https://github.com/Waste-Wood/e-CARE (dataset 目录)"
    echo "  HF:   https://huggingface.co/datasets/12ml/e-CARE"
  fi
else
  echo "[跳过] tmp/ecare_train.jsonl 已存在"
fi

echo "[2/3] COPA 英文 val（100 条；test 无标签不放）"
if [ ! -f tmp/COPA/val.jsonl ]; then
  curl -sL -o tmp/COPA/val.jsonl \
    "https://huggingface.co/datasets/pkavumba/balanced-copa/resolve/main/data/validation-00000-of-00001.parquet" \
  && echo "[OK] COPA val parquet -> tmp/COPA/val.jsonl（需 pyarrow 转换，或直接用 validation parquet）" \
  || echo "[警告] 不可达，可改用官方 super_glue COPA val"
else
  echo "[跳过] tmp/COPA/val.jsonl 已存在"
fi

echo "[3/3] 自检"
python3 scripts/aeroplus/fetch_helpers.py check
echo "完成。注意: e-CARE train 缺失不影响评估——只影响可选的 our-run 微调基线行。"
