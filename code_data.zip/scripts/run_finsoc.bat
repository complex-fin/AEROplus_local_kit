@echo off
REM =============================================================================
REM FINSOC domain-transfer benchmark driver -- Windows version of run_finsoc.sh
REM Usage:
REM   scripts\run_finsoc.bat verify    (smoke: 2 items per system, en+zh)
REM   scripts\run_finsoc.bat collect   (full: en 1040 + zh 1040, resumable)
REM   scripts\run_finsoc.bat analyze   (offline reports + paired stats)
REM Data (frozen, seed 20261012): tmp\finsoc_{en,zh}_{cal,test}_v1.jsonl
REM =============================================================================
setlocal EnableExtensions
cd /d "%~dp0.."

set "MODE=%~1"
if "%MODE%"=="" set "MODE=verify"
set "LIMIT="
if /i "%MODE%"=="verify" set "LIMIT=--limit 2"

set "PY=python"
where python >nul 2>nul || set "PY=py -3"
where node >nul 2>nul || (echo [ERROR] node not found in PATH & exit /b 1)
%PY% --version >nul 2>nul || (echo [ERROR] python not found in PATH & exit /b 1)

if /i "%MODE%"=="verify"  (call :collect || exit /b 1)
if /i "%MODE%"=="verify"  goto :done
if /i "%MODE%"=="collect" (call :collect || exit /b 1)
if /i "%MODE%"=="collect" goto :done
if /i "%MODE%"=="analyze" (call :analyze || exit /b 1)
if /i "%MODE%"=="analyze" goto :done
echo Usage: scripts\run_finsoc.bat {verify^|collect^|analyze}
exit /b 1

:done
echo [finsoc] %MODE% finished OK
exit /b 0

REM ---------------------------------------------------------------------------
:collect
for %%L in (en zh) do (
  echo [finsoc] collecting %%L ...
  REM aero cal: always resume-collect (collect_v3 skips existing idx; verify's 2 items will not block full run)
  node scripts\collect_v3.mjs --system aeroplus --input tmp\finsoc_%%L_cal_v1.jsonl --output tmp\results_aero_finsoc%%L_cal.jsonl --conc 4 %LIMIT% || exit /b 1
  node scripts\run_exp.mjs    --system cot       --input tmp\finsoc_%%L_cal_v1.jsonl  --output tmp\results_cot_finsoc%%L_cal.jsonl --conc 4 %LIMIT% || exit /b 1
  node scripts\collect_v3.mjs --system aeroplus --input tmp\finsoc_%%L_test_v1.jsonl --output tmp\results_aero_finsoc%%L.jsonl --conc 4 %LIMIT% || exit /b 1
  node scripts\run_exp.mjs   --system cot       --input tmp\finsoc_%%L_test_v1.jsonl --output tmp\results_cot_finsoc%%L.jsonl --conc 4 %LIMIT% || exit /b 1
  node scripts\collect_v3.mjs --system cf_cot   --input tmp\finsoc_%%L_test_v1.jsonl --output tmp\results_cfcot_finsoc%%L.jsonl --conc 4 %LIMIT% || exit /b 1
  node scripts\run_exp.mjs   --system zeroshot  --input tmp\finsoc_%%L_test_v1.jsonl --output tmp\results_zeroshot_finsoc%%L.jsonl --conc 4 %LIMIT% || exit /b 1
)
exit /b 0

REM ---------------------------------------------------------------------------
:analyze
for %%L in (en zh) do (
  echo [finsoc] analyze %%L ...
  %PY% scripts\aeroplus\run_offline.py --dataset finsoc --raw tmp\results_aero_finsoc%%L.jsonl --cal tmp\results_aero_finsoc%%L_cal.jsonl --tag finsoc-%%L || exit /b 1
  %PY% scripts\aeroplus\selective_baselines.py --tag finsoc-%%L --cot-cal tmp\results_cot_finsoc%%L_cal.jsonl --cot-test tmp\results_cot_finsoc%%L.jsonl || exit /b 1
  REM E5 P1 gate (skip if result exists: single-evaluation discipline)
  if not exist "tmp\finsoc_gate_finsoc-%%L.json" (
    %PY% scripts\aeroplus\finsoc_gate.py --tag finsoc-%%L --aero-cal tmp\results_aero_finsoc%%L_cal.jsonl --aero-test tmp\results_aero_finsoc%%L.jsonl --cot-cal tmp\results_cot_finsoc%%L_cal.jsonl --cot-test tmp\results_cot_finsoc%%L.jsonl --frozen-preset tmp\preset_p1_ecare-p1.json || exit /b 1
  )
)
echo [finsoc] paired stats (AERO+ vs CoT, McNemar + bootstrap) ...
%PY% scripts\aeroplus\finsoc_stats.py en zh || exit /b 1
exit /b 0
