#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Constructs the FINSOC domain-transfer benchmark: social & financial event
causal reasoning, bilingual (en primary + zh mirror), >=1000 test samples.

Design (mirrors e-CARE/COPA protocol; CLadder-style constructed benchmark):
  real items      gold 1|2 : premise states one side of a curated causal
                    mechanism; the genuine counterpart vs a VALENCE-FLIPPED
                    distractor (asserts the opposite outcome/direction -- a
                    model must know the mechanism, lexical overlap cannot help).
  negative items  gold 3   : BOTH candidates are non-causal w.r.t. premise.
                    neg-easy: cross-domain candidates (topically distant).
                    neg-hard: same-topic confounds (co-movement, common cause,
                    after-the-fact, background stats) -- superficial similarity
                    tempts, mechanism knowledge rejects.

Flip-token syntax: "{raise|cut}" -> + valence keeps left, - valence takes right.
All tokens in a string flip together, so anti_E/anti_C are derived, not
hand-written, and are non-causal *by construction* (opposite condition).

Deterministic: seed 20261011. Outputs:
  tmp/finsoc_en_test.jsonl (1040)  tmp/finsoc_en_cal.jsonl (100)
  tmp/finsoc_zh_test.jsonl (1040)  tmp/finsoc_zh_cal.jsonl (100)
  tmp/finsoc_validation_v1.json + tmp/finsoc_preview.md
"""
import json, random, re, hashlib, unicodedata
from collections import Counter
from pathlib import Path

SEED = 20261011
TMP = Path(__file__).resolve().parents[1] / 'tmp'

TIME_EN = ['Last quarter', 'Recently', 'In the past month', 'Earlier this year']
TIME_ZH = ['上季度，', '近期，', '过去一个月里，', '今年早些时候，']

# --------------------------------------------------------------------------
# FINANCIAL MECHANISMS (48). Fields: id, cls, a_en/a_zh actor lists, c_en/c_zh
# (cause clause, may contain {A} and flip tokens), e_en/e_zh (effect clause),
# m_en/m_zh (valence-neutral mechanism explanation, reference for eval).
# --------------------------------------------------------------------------
FIN = [
 dict(id='F01', cls='monetary', a_en=['the central bank', 'the monetary authority'], a_zh=['该国央行', '货币当局'],
      c_en='{A} {raise|cut} its benchmark interest rate.',
      c_zh='{A}{上调|下调}了基准利率。',
      e_en='Commercial banks {raise|cut} the lending rates they charge businesses.',
      e_zh='商业银行对企业的贷款利率随之{上升|下降}。',
      m_en='Policy rates transmit to bank funding costs and lending rates.',
      m_zh='政策利率传导至银行资金成本与贷款利率。'),
 dict(id='F02', cls='monetary', a_en=['the central bank', 'the banking regulator'], a_zh=['该国央行', '银行业监管机构'],
      c_en='{A} {raised|lowered} the reserve requirement ratio for banks.',
      c_zh='{A}{上调|下调}了银行的存款准备金率。',
      e_en='The amount of funds banks can lend {expanded|shrank}.',
      e_zh='银行可贷资金规模随之{扩大|收缩}。',
      m_en='Reserve requirements bind the share of deposits that must be held idle, limiting loanable funds.',
      m_zh='准备金率约束银行必须闲置存放的存款比例，从而限制可贷资金。'),
 dict(id='F03', cls='monetary', a_en=['the central bank'], a_zh=['该国央行'],
      c_en='{A} signaled {tighter|looser} monetary policy ahead.',
      c_zh='{A}释放了货币政策将{收紧|放松}的信号。',
      e_en='The domestic currency {appreciated|depreciated} against major peers.',
      e_zh='本币对主要货币{升值|贬值}。',
      m_en='Higher expected domestic rates attract capital inflows, supporting the currency.',
      m_zh='更高的预期国内利率吸引资本流入，支撑本币汇率。'),
 dict(id='F04', cls='monetary', a_en=['the central bank'], a_zh=['该国央行'],
      c_en='{A} {pushed|pulled} policy rates {up|down} sharply.',
      c_zh='{A}大幅{上调|下调}了政策利率。',
      e_en='Prices of long-term government bonds {fell|rose}.',
      e_zh='长期国债价格随之{下跌|上涨}。',
      m_en='Bond prices move inversely to yields; policy-driven yield shifts reprice existing bonds.',
      m_zh='债券价格与收益率反向变动；政策带来的收益率变化会对存量债券重新定价。'),
 dict(id='F05', cls='monetary', a_en=['the central bank'], a_zh=['该国央行'],
      c_en='{A} {cut|hiked} rates to stimulate or cool the economy.',
      c_zh='{A}为{刺激|降温}经济而{降息|加息}。',
      e_en='Mortgage refinancing applications {surged|dropped}.',
      e_zh='房贷再融资申请随之{激增|回落}。',
      m_en='Cheaper borrowing makes refinancing existing mortgages attractive.',
      m_zh='借贷成本下降使置换存量房贷更具吸引力。'),
 dict(id='F06', cls='inflation', a_en=['manufacturing firms across the region', 'producers in the industrial belt'], a_zh=['该地区制造业企业', '工业带的生产企业'],
      c_en='{A} faced {soaring|plunging} raw-material costs.',
      c_zh='{A}的原材料成本{大幅上涨|大幅回落}。',
      e_en='Factory-gate prices for finished goods {rose|declined}.',
      e_zh='制成品的出厂价格随之{上涨|下降}。',
      m_en='Input-cost pass-through raises producer prices when demand permits.',
      m_zh='在需求允许时，投入成本会向出厂价格传导。'),
 dict(id='F07', cls='inflation', a_en=['the economy', 'the country'], a_zh=['该国经济', '这个国家'],
      c_en='Money supply {expanded|contracted} much faster than output.',
      c_zh='货币供给增速远{高|低}于产出增速。',
      e_en='Consumer prices {accelerated|decelerated}.',
      e_zh='消费者物价涨势随之{加快|放缓}。',
      m_en='More money chasing the same goods lifts the general price level.',
      m_zh='同样商品对应更多货币会推高总体物价水平。'),
 dict(id='F08', cls='inflation', a_en=['households in the country'], a_zh=['该国居民家庭'],
      c_en='Consumer inflation {spiked|cooled} markedly.',
      c_zh='消费通胀显著{加剧|缓和}。',
      e_en='Real purchasing power of wages {eroded|improved}.',
      e_zh='工资的实际购买力随之{缩水|提升}。',
      m_en='Nominal wages lag prices, so inflation reduces real income.',
      m_zh='名义工资滞后于物价，通胀因此降低实际收入。'),
 dict(id='F09', cls='fiscal', a_en=['the government'], a_zh=['该国政府'],
      c_en='{A} ran a much {larger|smaller} fiscal deficit.',
      c_zh='{A}的财政赤字大幅{扩大|收窄}。',
      e_en='Government bond issuance {increased|decreased}.',
      e_zh='国债发行规模随之{增加|减少}。',
      m_en='Deficits are financed by issuance; wider gaps require more debt sales.',
      m_zh='赤字依靠发债融资，缺口越大发行越多。'),
 dict(id='F10', cls='fiscal', a_en=['the government'], a_zh=['该国政府'],
      c_en='{A} {cut|raised} personal income taxes.',
      c_zh='{A}{下调|上调}了个人所得税。',
      e_en='Household disposable income {rose|fell}.',
      e_zh='居民可支配收入随之{增加|减少}。',
      m_en='Tax rates directly shape post-tax income.',
      m_zh='税率直接决定税后收入。'),
 dict(id='F11', cls='fiscal', a_en=['the government'], a_zh=['该国政府'],
      c_en='{A} introduced {hefty|smaller} import tariffs on steel.',
      c_zh='{A}对钢铁进口{加征|减少了}高额关税。',
      e_en='Domestic prices of imported steel products {climbed|eased}.',
      e_zh='进口钢材的国内价格随之{走高|回落}。',
      m_en='Tariffs are levied at the border and passed into import prices.',
      m_zh='关税在口岸征收并计入进口商品价格。'),
 dict(id='F12', cls='fiscal', a_en=['the government'], a_zh=['该国政府'],
      c_en='{A} offered {rich|slim} purchase subsidies for electric vehicles.',
      c_zh='{A}对电动车提供了{丰厚|微薄}的购车补贴。',
      e_en='EV sales {surged|stalled}.',
      e_zh='电动车销量随之{猛增|低迷}。',
      m_en='Subsidies lower effective prices and pull demand forward.',
      m_zh='补贴降低实际购车成本，从而拉动需求。'),
 dict(id='F13', cls='corporate', a_en=['a listed retailer', 'a listed logistics firm'], a_zh=['一家上市零售企业', '一家上市物流企业'],
      c_en='{A} reported earnings far {below|above} market expectations.',
      c_zh='{A}的财报业绩远{低于|高于}市场预期。',
      e_en='Its share price {tumbled|jumped} on the announcement.',
      e_zh='公告后其股价随之{大跌|大涨}。',
      m_en='Earnings surprises reprice expectations embedded in the stock.',
      m_zh='业绩意外会修正股价中内嵌的预期。'),
 dict(id='F14', cls='corporate', a_en=['a listed manufacturer'], a_zh=['一家上市制造企业'],
      c_en='{A} announced a {large|modest} share buyback program.',
      c_zh='{A}宣布了{大规模|小规模}的股票回购计划。',
      e_en='Earnings per share {received|lost} a mechanical boost.',
      e_zh='每股收益获得{机械性增厚|摊薄稀释}。',
      m_en='Buybacks shrink the share count, mechanically lifting EPS.',
      m_zh='回购减少股本，机械性抬升每股收益。'),
 dict(id='F15', cls='corporate', a_en=['a listed tech company'], a_zh=['一家上市科技公司'],
      c_en='A {large|small} IPO lock-up expiry approached for {A}.',
      c_zh='{A}迎来{大规模|小规模}的IPO解禁期。',
      e_en='Selling pressure on the stock {intensified|stayed mild}.',
      e_zh='该股面临的抛压随之{加大|有限}。',
      m_en='Unlocking insider shares expands float and adds potential supply.',
      m_zh='解禁扩大流通盘并带来潜在供给。'),
 dict(id='F16', cls='corporate', a_en=['a mid-sized airline', 'a regional carrier'], a_zh=['一家中型航空公司', '一家区域航司'],
      c_en='{A} {grounded|expanded} a large share of its fleet for maintenance.',
      c_zh='{A}{停飞|扩充}了大量机队进行检修。',
      e_en='Its quarterly seat capacity {shrank|grew}.',
      e_zh='其季度座位运力随之{缩减|增长}。',
      m_en='Grounded aircraft directly remove available seat capacity.',
      m_zh='停飞飞机直接减少可用座位运力。'),
 dict(id='F17', cls='corporate', a_en=['a food company', 'a beverage producer'], a_zh=['一家食品企业', '一家饮料生产商'],
      c_en='{A} issued a {broad|narrow} product recall over safety concerns.',
      c_zh='{A}因安全问题发起{大范围|小范围}产品召回。',
      e_en='Consumer trust in its brands {weakened|held firm}.',
      e_zh='消费者对其品牌的信任随之{受损|保持稳固}。',
      m_en='Safety failures damage brand equity and repel customers.',
      m_zh='安全事件损害品牌资产并驱离消费者。'),
 dict(id='F18', cls='corporate', a_en=['an industrial group', 'a listed conglomerate'], a_zh=['一家工业企业集团', '一家上市多元化集团'],
      c_en='{A} booked a {hefty|token} legal settlement charge.',
      c_zh='{A}计提了{巨额|象征性}的诉讼和解费用。',
      e_en='Its quarterly net profit {shrank|was cushioned}.',
      e_zh='其季度净利润随之{缩水|受到的拖累有限}。',
      m_en='One-off charges flow straight into reported net income.',
      m_zh='一次性费用直接计入报告净利润。'),
 dict(id='F19', cls='corporate', a_en=['a luxury goods maker'], a_zh=['一家奢侈品制造商'],
      c_en='{A} {raised|slashed} prices across its flagship line.',
      c_zh='{A}对旗舰产品线全面{提价|降价}。',
      e_en='Its reported gross margin {widened|compressed}.',
      e_zh='其报告毛利率随之{走阔|收窄}。',
      m_en='With volumes steady, higher realized prices lift gross margin.',
      m_zh='在销量稳定时，实际售价上升会抬高毛利率。'),
 dict(id='F20', cls='corporate', a_en=['an e-commerce platform'], a_zh=['一家电商平台'],
      c_en='{A} ran {aggressive|modest} discount campaigns.',
      c_zh='{A}推出了{力度很大|较为温和}的促销活动。',
      e_en='Its order volume {spiked|inched up}.',
      e_zh='其订单量随之{激增|小幅增长}。',
      m_en='Deeper discounts stimulate price-sensitive demand.',
      m_zh='更大折扣会刺激价格敏感型需求。'),
 dict(id='F21', cls='credit', a_en=['a rating agency'], a_zh=['一家评级机构'],
      c_en='{A} {downgraded|upgraded} a large property developer.',
      c_zh='{A}{下调|上调}了一家大型房企的信用评级。',
      e_en='The developer\'s bond yields {spiked|compressed} in secondary trading.',
      e_zh='该房企债券的二级市场收益率随之{飙升|回落}。',
      m_en='Ratings reprice default risk into required yields.',
      m_zh='评级变化会把违约风险重定价到要求的收益率中。'),
 dict(id='F22', cls='credit', a_en=['a commercial bank'], a_zh=['一家商业银行'],
      c_en='{A} saw non-performing loans {pile up|shrink}.',
      c_zh='{A}的不良贷款大幅{增加|减少}。',
      e_en='Its loan-loss provisions {rose|fell}.',
      e_zh='其贷款减值拨备随之{上升|下降}。',
      m_en='Accounting rules tie provisions to expected credit losses.',
      m_zh='会计准则要求拨备与预期信用损失挂钩。'),
 dict(id='F23', cls='credit', a_en=['a commercial bank'], a_zh=['一家商业银行'],
      c_en='Depositors {pulled|poured} funds {out of|into} {A}.',
      c_zh='储户从{A}大量{取出|存入}资金。',
      e_en='Its wholesale funding costs {jumped|declined}.',
      e_zh='其批发融资成本随之{跳升|下降}。',
      m_en='Losing deposit base forces pricier wholesale borrowing.',
      m_zh='存款流失迫使银行依赖更贵的批发融资。'),
 dict(id='F24', cls='credit', a_en=['lenders across the market'], a_zh=['市场上的放贷机构'],
      c_en='{A} {tightened|loosened} lending standards for small firms.',
      c_zh='{A}对小微企业的放贷标准明显{收紧|放松}。',
      e_en='Credit approvals for small businesses {dwindled|expanded}.',
      e_zh='小微企业的信贷获批率随之{下降|上升}。',
      m_en='Stricter screening rejects more marginal borrowers.',
      m_zh='更严格的审核会拒绝更多边际借款人。'),
 dict(id='F25', cls='markets', a_en=['the stock market'], a_zh=['股市'],
      c_en='Panic selling {gripped|subsided in} {A}.',
      c_zh='{A}出现{恐慌性抛售|情绪明显平复}。',
      e_en='Bid-ask spreads across liquid stocks {widened|narrowed}.',
      e_zh='流动性较好的股票买卖价差随之{扩大|收窄}。',
      m_en='Emergency liquidity demand exceeds immediate supply, widening spreads.',
      m_zh='恐慌时流动性需求骤增，价差随之扩大。'),
 dict(id='F26', cls='markets', a_en=['a leveraged fund'], a_zh=['一家杠杆基金'],
      c_en='{A} faced margin calls as collateral values {fell|rose}.',
      c_zh='随着抵押品价值{下跌|上涨}，{A}接到追加保证金通知。',
      e_en='Forced selling {added|relieved} pressure on its holdings.',
      e_zh='被迫平仓{加剧|缓解}了其持仓的抛压。',
      m_en='Margin calls force asset disposal regardless of price.',
      m_zh='追加保证金迫使不计价格地处置资产。'),
 dict(id='F27', cls='markets', a_en=['a major stock'], a_zh=['一只权重股'],
      c_en='{A} was {added to|removed from} the flagship index.',
      c_zh='{A}被{纳入|移出}旗舰指数。',
      e_en='Passive fund flows into the stock {rose|fell} mechanically.',
      e_zh='被动资金对其配置随之机械性{增加|减少}。',
      m_en='Index funds must hold constituents in proportion.',
      m_zh='指数基金必须按权重持有成分股。'),
 dict(id='F28', cls='markets', a_en=['a profitable company'], a_zh=['一家盈利企业'],
      c_en='{A} announced a {surprise|long-signaled} special dividend.',
      c_zh='{A}宣布了{超出预期|早有铺垫}的特别分红。',
      e_en='Income-focused investors {flocked to|showed little added interest in} the stock.',
      e_zh='收益型投资者对该股的{追捧|新增兴趣有限}随之升温。',
      m_en='Cash distributions attract yield-seeking shareholders.',
      m_zh='现金分红吸引追求收益的股东。'),
 dict(id='F29', cls='commodity', a_en=['crude oil prices'], a_zh=['国际油价'],
      c_en='{A} {surged|slumped} on supply disruptions.',
      c_zh='受供应中断影响，{A}大幅{上涨|下跌}。',
      e_en='Operating costs for airlines {ballooned|eased}.',
      e_zh='航空公司的运营成本随之{膨胀|缓解}。',
      m_en='Jet fuel is a refinery product of crude; fuel is a top airline cost.',
      m_zh='航油是原油炼化产品，燃油是航司最大成本之一。'),
 dict(id='F30', cls='commodity', a_en=['crude oil prices'], a_zh=['国际油价'],
      c_en='{A} stayed {persistently high|unusually low}.',
      c_zh='{A}持续{高企|低迷}。',
      e_en='Consumer interest in electric vehicles {grew|waned}.',
      e_zh='消费者对电动车的兴趣随之{增强|减弱}。',
      m_en='Expensive gasoline improves the relative economics of EVs.',
      m_zh='油价高企提升电动车的相对经济性。'),
 dict(id='F31', cls='commodity', a_en=['a major grain belt'], a_zh=['一个主要产粮区'],
      c_en='{A} suffered {severe|mild} drought damage.',
      c_zh='{A}遭受了{严重|轻微}的旱灾。',
      e_en='Regional grain prices {climbed|stabilized}.',
      e_zh='区域粮价随之{攀升|趋稳}。',
      m_en='Harvest shortfalls tighten local supply and lift prices.',
      m_zh='减产收紧本地供给并推高粮价。'),
 dict(id='F32', cls='commodity', a_en=['copper demand from grid builders'], a_zh=['电网建设对铜的需求'],
      c_en='{A} {accelerated|slackened}.',
      c_zh='{A}明显{加快|放缓}。',
      e_en='Copper mining companies {raised|trimmed} expansion budgets.',
      e_zh='铜矿企业随之{上调|下调}扩产预算。',
      m_en='Sustained demand growth justifies capacity investment.',
      m_zh='持续的需求增长为产能投资提供依据。'),
 dict(id='F33', cls='fx', a_en=['the domestic currency'], a_zh=['本币'],
      c_en='{A} {depreciated|appreciated} sharply.',
      c_zh='{A}大幅{贬值|升值}。',
      e_en='Exporters\' price competitiveness {improved|eroded} abroad.',
      e_zh='出口商在海外市场的价格竞争力随之{增强|减弱}。',
      m_en='A weaker currency lowers foreign-currency prices of exports.',
      m_zh='本币走弱降低出口品的外币价格。'),
 dict(id='F34', cls='fx', a_en=['the domestic currency'], a_zh=['本币'],
      c_en='{A} {weakened|strengthened} against major trading partners.',
      c_zh='{A}对主要贸易伙伴货币{走弱|走强}。',
      e_en='Imported energy and food bills {rose|fell} in local terms.',
      e_zh='以本币计的进口能源与食品开支随之{上升|下降}。',
      m_en='Local-currency cost of imports tracks the exchange rate.',
      m_zh='进口品的本币成本随汇率变动。'),
 dict(id='F35', cls='fx', a_en=['foreign investors'], a_zh=['外国投资者'],
      c_en='{A} {withdrew|poured} portfolio capital from local bonds.',
      c_zh='{A}从本地债券市场{撤出|涌入}了组合资金。',
      e_en='The currency came under {depreciation|appreciation} pressure.',
      e_zh='本币面临{贬值|升值}压力。',
      m_en='Cross-border selling converts proceeds into foreign currency.',
      m_zh='跨境抛售需要将本币收益兑换为外币。'),
 dict(id='F36', cls='housing', a_en=['mortgage rates in the city'], a_zh=['该城市的房贷利率'],
      c_en='{A} {climbed|declined} steeply.',
      c_zh='{A}大幅{攀升|回落}。',
      e_en='Existing-home sales {cooled|heated up}.',
      e_zh='二手房成交随之{降温|升温}。',
      m_en='Higher financing costs price out marginal home buyers.',
      m_zh='融资成本上升会把边际购房者挤出市场。'),
 dict(id='F37', cls='housing', a_en=['the city government'], a_zh=['该市政府'],
      c_en='{A} imposed {strict|lax} rent controls.',
      c_zh='{A}实施了{严格|宽松}的租金管制。',
      e_en='Landlords {withdrew|listed more} units from the rental market.',
      e_zh='房东随之{撤租|放租}的意愿{上升|下降}。',
      m_en='Capped rents reduce expected returns on letting.',
      m_zh='限租降低出租的预期收益。'),
 dict(id='F38', cls='housing', a_en=['a tech hub district'], a_zh=['一个科技产业聚集区'],
      c_en='High-paying jobs in {A} {multiplied|dwindled}.',
      c_zh='{A}的高薪岗位大幅{增加|减少}。',
      e_en='Nearby home prices {hardened|softened}.',
      e_zh='周边房价随之{坚挺|走软}。',
      m_en='Local income growth bids up housing near job centers.',
      m_zh='就业中心附近的收入增长会推高住房需求与价格。'),
 dict(id='F39', cls='regulation', a_en=['the regulator'], a_zh=['监管机构'],
      c_en='{A} imposed a {record|token} fine on a telecom operator.',
      c_zh='{A}对一家电信运营商处以{创纪录|象征性}罚款。',
      e_en='The operator\'s reported profit {took a hit|was barely affected}.',
      e_zh='该运营商的账面利润随之{受损|几乎不受影响}。',
      m_en='Fines are expensed and reduce net income.',
      m_zh='罚款计入费用并减少净利润。'),
 dict(id='F40', cls='regulation', a_en=['new data-compliance rules'], a_zh=['新的数据合规要求'],
      c_en='{A} {raised|lowered} compliance costs for small platforms.',
      c_zh='{A}{提高了|降低了}小型平台的合规成本。',
      e_en='Marginal small platforms {exited|entered} the market.',
      e_zh='边缘小平台随之{退出|进入}市场。',
      m_en='Fixed compliance burdens weigh hardest on the smallest players.',
      m_zh='固定合规负担对小平台最重。'),
 dict(id='F41', cls='regulation', a_en=['the securities regulator'], a_zh=['证券监管机构'],
      c_en='{A} {tightened|relaxed} disclosure requirements for listed firms.',
      c_zh='{A}{收紧|放松}了上市公司的信息披露要求。',
      e_en='Information asymmetry for outside investors {narrowed|widened}.',
      e_zh='外部投资者的信息不对称随之{缩小|扩大}。',
      m_en='More mandated disclosure shrinks the private-information gap.',
      m_zh='强制披露增加会压缩私人信息差距。'),
 dict(id='F42', cls='banking', a_en=['a retail bank'], a_zh=['一家零售银行'],
      c_en='{A} {installed|removed} fees on basic accounts.',
      c_zh='{A}对基础账户{新增|取消}了手续费。',
      e_en='Fee-sensitive customers {moved|stayed}.',
      e_zh='对费率敏感的客户随之{流失|留存}。',
      m_en='Direct fees change the customer\'s cost of holding the account.',
      m_zh='手续费直接改变客户持户成本。'),
 dict(id='F43', cls='banking', a_en=['a payments company'], a_zh=['一家支付公司'],
      c_en='{A} {suffered|averted} a major service outage.',
      c_zh='{A}遭遇{重大|轻微}服务中断。',
      e_en='Merchants relying on it {lost|kept} sales during the window.',
      e_zh='依赖它的商户在故障期间{损失|保住}了销售额。',
      m_en='Checkout failures block transactions in real time.',
      m_zh='支付通道故障会实时阻断交易。'),
 dict(id='F44', cls='corporate', a_en=['a semiconductor firm'], a_zh=['一家半导体企业'],
      c_en='{A} secured {large|thin} advance orders from data-center builders.',
      c_zh='{A}获得数据中心厂商{大额|少量}预订单。',
      e_en='Its planned capital expenditure {expanded|was trimmed}.',
      e_zh='其资本开支计划随之{扩张|收缩}。',
      m_en='Order books justify capacity investment.',
      m_zh='订单储备为产能投资提供依据。'),
 dict(id='F45', cls='corporate', a_en=['a supermarket chain'], a_zh=['一家连锁超市'],
      c_en='{A} {won|lost} customers after a rival {closed|opened} nearby stores.',
      c_zh='由于竞争对手{关闭|新开}了附近门店，{A}{赢得|失去}了客源。',
      e_en='Its weekly foot traffic {rose|fell}.',
      e_zh='其每周客流随之{上升|下降}。',
      m_en='Nearby competitors capture or release local demand.',
      m_zh='邻近竞争者会分流或释放本地需求。'),
 dict(id='F46', cls='fiscal', a_en=['the government'], a_zh=['该国政府'],
      c_en='{A} expanded {generous|modest} child-care subsidies.',
      c_zh='{A}大幅{增加|仅小幅增加}了育儿补贴。',
      e_en='Household spending on child services {rose|held back}.',
      e_zh='家庭育儿服务支出随之{增加|受到抑制}。',
      m_en='Subsidies defray costs and release household budgets.',
      m_zh='补贴分担成本、释放家庭预算。'),
 dict(id='F47', cls='markets', a_en=['a speculative small-cap'], a_zh=['一只投机性小盘股'],
      c_en='Short interest in {A} stayed {extremely high|modest}.',
      c_zh='{A}的空头持仓{极高|有限}。',
      e_en='Any positive news risked {violent|mild} short-covering rallies.',
      e_zh='任何利好都可能引发{剧烈|温和}的空头回补反弹。',
      m_en='Crowded shorts must buy back to close, amplifying up-moves.',
      m_zh='拥挤空头平仓需买入回补，放大上涨。'),
 dict(id='F48', cls='banking', a_en=['a wealth-management arm'], a_zh=['一家财富管理子公司'],
      c_en='{A} {guaranteed|floated} principal on new products.',
      c_zh='{A}对新发产品{提供|不再提供}保本安排。',
      e_en='Risk-averse clients {subscribed eagerly|stayed on the sidelines}.',
      e_zh='风险厌恶型客户随之{踊跃认购|持币观望}。',
      m_en='Principal protection removes downside risk for conservative investors.',
      m_zh='保本安排消除保守型客户的下行风险。'),
]

# --------------------------------------------------------------------------
# SOCIAL MECHANISMS (48)
# --------------------------------------------------------------------------
SOC = [
 dict(id='S01', cls='labor', a_en=['a large factory', 'a regional manufacturer'], a_zh=['一家大型工厂', '一家区域制造企业'],
      c_en='{A} {announced|withdrew} mass layoffs.',
      c_zh='{A}{宣布|撤回}了大规模裁员计划。',
      e_en='Local unemployment claims {rose|fell}.',
      e_zh='当地失业登记随之{上升|下降}。',
      m_en='Dismissed workers file for benefits and register as unemployed.',
      m_zh='被裁员工会申领救济并登记失业。'),
 dict(id='S02', cls='labor', a_en=['layoffs across industries'], a_zh=['多行业的裁员潮'],
      c_en='{A} {intensified|eased}.',
      c_zh='{A}明显{加剧|缓和}。',
      e_en='Household consumption in the region {weakened|strengthened}.',
      e_zh='当地居民消费随之{走弱|走强}。',
      m_en='Job insecurity cuts discretionary spending.',
      m_zh='就业不安全感会压缩非必需消费。'),
 dict(id='S03', cls='labor', a_en=['the city council'], a_zh=['市议会'],
      c_en='{A} {raised|froze} the statutory minimum wage.',
      c_zh='{A}{上调|冻结}了法定最低工资。',
      e_en='Labor costs for small restaurants {increased|held steady}.',
      e_zh='小餐馆的用工成本随之{上升|保持不变}。',
      m_en='Wage floors bind hardest for low-wage service employers.',
      m_zh='最低工资对低薪服务业雇主约束最大。'),
 dict(id='S04', cls='labor', a_en=['dock workers at the port'], a_zh=['港口的码头工人'],
      c_en='{A} went on {an open-ended|a brief} strike.',
      c_zh='{A}发起了{无限期|短暂}罢工。',
      e_en='Container throughput at the port {ground down|recovered quickly}.',
      e_zh='港口集装箱吞吐量随之{骤降|快速恢复}。',
      m_en='Strikes idle berths, cranes and trucking queues.',
      m_zh='罢工使泊位、吊装与卡车排队停摆。'),
 dict(id='S05', cls='education', a_en=['a private university'], a_zh=['一所私立大学'],
      c_en='{A} {hiked|froze} undergraduate tuition.',
      c_zh='{A}{上调|冻结}了本科学费。',
      e_en='Applications from low-income students {dropped|held up}.',
      e_zh='低收入学生的申请数随之{下降|保持稳定}。',
      m_en='Sticker price screens out budget-constrained applicants.',
      m_zh='学费门槛会筛掉预算受限的申请者。'),
 dict(id='S06', cls='education', a_en=['the district'], a_zh=['该区'],
      c_en='{A} expanded {need-based|merit-only} scholarships.',
      c_zh='{A}扩大了{按需发放|仅限绩优}的奖学金覆盖。',
      e_en='Enrollment of disadvantaged students {rose|barely moved}.',
      e_zh='弱势学生的入学率随之{上升|几乎不变}。',
      m_en='Targeted aid lowers the net cost of attending.',
      m_zh='定向资助降低实际入学成本。'),
 dict(id='S07', cls='education', a_en=['schools in the district'], a_zh=['该区的学校'],
      c_en='{A} posted {markedly better|declining} exam results.',
      c_zh='{A}的考试成绩{明显提升|下滑}。',
      e_en='Home prices in the catchment area {firmed|softened}.',
      e_zh='学区房价随之{坚挺|走软}。',
      m_en='School quality is capitalized into nearby housing.',
      m_zh='学区质量会资本化到周边房价中。'),
 dict(id='S08', cls='health', a_en=['the community', 'the county'], a_zh=['该社区', '该县'],
      c_en='{A} reached {high|low} vaccination coverage.',
      c_zh='{A}的疫苗接种率达到{较高|较低}水平。',
      e_en='Reportable infections {declined|kept spreading}.',
      e_zh='可报告传染病随之{减少|持续蔓延}。',
      m_en='Vaccination reduces susceptible population and transmission.',
      m_zh='接种降低易感人群规模并阻断传播。'),
 dict(id='S09', cls='health', a_en=['the government'], a_zh=['政府'],
      c_en='{A} imposed a {steep|modest} excise tax on cigarettes.',
      c_zh='{A}对香烟征收了{高额|温和}的消费税。',
      e_en='Cigarette sales {fell|held steady}.',
      e_zh='香烟销量随之{下降|保持稳定}。',
      m_en='Excise taxes raise shelf prices and deter demand.',
      m_zh='消费税抬高终端价格并抑制需求。'),
 dict(id='S10', cls='health', a_en=['a sugar-sweetened drink levy'], a_zh=['含糖饮料税'],
      c_en='{A} {took effect|was repealed} in the province.',
      c_zh='{A}在该省{开始实施|被废除}。',
      e_en='Sugary drink purchases {curtailed|rebounded}.',
      e_zh='含糖饮料购买随之{减少|回升}。',
      m_en='Levies raise relative prices of taxed beverages.',
      m_zh='征税抬高被税饮品的相对价格。'),
 dict(id='S11', cls='health', a_en=['air pollution in the industrial suburb'], a_zh=['工业郊区的大气污染'],
      c_en='{A} {worsened|abated}.',
      c_zh='{A}明显{加重|减轻}。',
      e_en='Respiratory clinic visits {rose|declined}.',
      e_zh='呼吸科门诊量随之{上升|下降}。',
      m_en='Particulate exposure triggers asthma and COPD episodes.',
      m_zh='颗粒物暴露诱发哮喘与慢阻肺急性发作。'),
 dict(id='S12', cls='health', a_en=['the county hospital'], a_zh=['县医院'],
      c_en='{A} {lost|added} emergency physicians.',
      c_zh='{A}的急诊医生{流失|增加}。',
      e_en='Patient wait times {stretched|shortened}.',
      e_zh='患者等待时间随之{拉长|缩短}。',
      m_en='Fewer physicians raise service times per patient.',
      m_zh='医生减少会拉长单个患者的服务时间。'),
 dict(id='S13', cls='urban', a_en=['rents in the inner city'], a_zh=['中心城区租金'],
      c_en='{A} {surged|cooled}.',
      c_zh='{A}大幅{上涨|回落}。',
      e_en='Young workers {moved out to|stayed closer to} the suburbs.',
      e_zh='年轻上班族随之{迁往|留驻}近郊。',
      m_en='Housing costs push budget-constrained renters outward.',
      m_zh='居住成本会把预算受限的租客推向城市外围。'),
 dict(id='S14', cls='urban', a_en=['a new metro line'], a_zh=['一条新地铁线'],
      c_en='{A} {opened|shut down} through the district.',
      c_zh='{A}{开通|停运}并穿过该区域。',
      e_en='Property values near the stations {rose|declined}.',
      e_zh='站点周边房价随之{上涨|下跌}。',
      m_en='Transit access cuts commute costs and is capitalized into land.',
      m_zh='轨道通达降低通勤成本并资本化到土地价值。'),
 dict(id='S15', cls='urban', a_en=['firms in the metro area'], a_zh=['都会区的企业'],
      c_en='{A} {embraced|rolled back} remote work.',
      c_zh='{A}{普遍推行|收紧了}远程办公。',
      e_en='Downtown office demand {thinned|recovered}.',
      e_zh='市中心写字楼需求随之{走低|回暖}。',
      m_en='Remote schedules substitute home desks for leased offices.',
      m_zh='远程办公以居家工位替代租赁办公面积。'),
 dict(id='S16', cls='urban', a_en=['villages in the province'], a_zh=['该省的村镇'],
      c_en='Young adults {left for|returned from} cities in {A}.',
      c_zh='{A}的年轻人{进城务工|返乡回流}。',
      e_en='Local farmland left fallow {increased|decreased}.',
      e_zh='当地撂荒耕地随之{增加|减少}。',
      m_en='Depopulation removes the labor that farms marginal land.',
      m_zh='人口外流抽走耕作边际土地的劳动力。'),
 dict(id='S17', cls='demography', a_en=['the region\'s population'], a_zh=['该地区人口'],
      c_en='{A} {aged|rejuvenated} markedly.',
      c_zh='{A}明显{老龄化|年轻化}。',
      e_en='Healthcare and pension spending {ballooned|eased}.',
      e_zh='医疗与养老支出随之{膨胀|缓解}。',
      m_en='Older cohorts consume more medical and pension resources.',
      m_zh='老龄化人群消耗更多医疗与养老金资源。'),
 dict(id='S18', cls='demography', a_en=['the birth rate in the prefecture'], a_zh=['该市出生率'],
      c_en='{A} {kept sliding|rebounded}.',
      c_zh='{A}持续{走低|回升}。',
      e_en='Kindergartens {faced|relieved} enrollment shortfalls.',
      e_zh='幼儿园随之{面临|缓解}招生缺口。',
      m_en='Fewer births shrink future cohorts entering preschool.',
      m_zh='出生减少会缩小未来入园人口。'),
 dict(id='S19', cls='demography', a_en=['migrant families', 'new arrivals'], a_zh=['外来务工家庭', '新迁入人口'],
      c_en='{A} {moved in|moved out of} the manufacturing city.',
      c_zh='{A}大量{迁入|迁出}这座制造业城市。',
      e_en='Demand for low-cost rental housing {tightened|loosened}.',
      e_zh='低成本租房需求随之{趋紧|宽松}。',
      m_en='Newcomers rent before they buy, lifting rental demand.',
      m_zh='新迁入人口先租后买，抬升租赁需求。'),
 dict(id='S20', cls='demography', a_en=['the retirement wave'], a_zh=['退休潮'],
      c_en='{A} {accelerated|slowed}.',
      c_zh='{A}明显{加速|放缓}。',
      e_en='Pension fund payouts {grew|stabilized}.',
      e_zh='养老金支出随之{增长|趋稳}。',
      m_en='More retirees draw benefits concurrently.',
      m_zh='退休人口增加带来同步的待遇支取。'),
 dict(id='S21', cls='media', a_en=['a rumor about shortages'], a_zh=['一则关于短缺的传言'],
      c_en='{A} {went viral|was debunked early}.',
      c_zh='{A}{大范围传播|被及时辟谣}。',
      e_en='Households {stockpiled|ignored} the relevant goods.',
      e_zh='居民随之{抢购|无视}相关商品。',
      m_en='Believed shortage signals trigger precautionary hoarding.',
      m_zh='被相信的短缺信号引发预防性囤积。'),
 dict(id='S22', cls='media', a_en=['a data breach at the app'], a_zh=['该应用的数据泄露事件'],
      c_en='{A} {became public|was contained}.',
      c_zh='{A}{被公开曝光|被及时控制}。',
      e_en='Active users {churned|stabilized}.',
      e_zh='活跃用户随之{流失|企稳}。',
      m_en='Privacy failures erode trust and drive account closures.',
      m_zh='隐私事故侵蚀信任并引发销户。'),
 dict(id='S23', cls='media', a_en=['the streaming platform'], a_zh=['该流媒体平台'],
      c_en='{A} {aired|pulled} a hit series.',
      c_zh='{A}{上线|下架}了爆款剧集。',
      e_en='Its subscription sign-ups {jumped|stalled}.',
      e_zh='其订阅新增随之{跳增|停滞}。',
      m_en='Exclusive hits pull in new subscribers.',
      m_zh='独家爆款拉动新增订阅。'),
 dict(id='S24', cls='media', a_en=['short-video usage among teens'], a_zh=['青少年短视频使用'],
      c_en='{A} {rose|fell} after school hours.',
      c_zh='课后时段{A}{增加|减少}。',
      e_en='Offline club participation {declined|recovered}.',
      e_zh='线下社团参与随之{下降|回升}。',
      m_en='Screen time competes for the same leisure hours.',
      m_zh='屏幕时间与线下活动争夺同一时段。'),
 dict(id='S25', cls='transport', a_en=['fuel prices in the metro'], a_zh=['该都会区油价'],
      c_en='{A} {climbed|dropped} for months.',
      c_zh='{A}连续数月{上涨|下跌}。',
      e_en='Bus and subway ridership {climbed|dipped}.',
      e_zh='公交地铁客流随之{上升|回落}。',
      m_en='Driving costs substitute toward public transit.',
      m_zh='驾车成本上升促使向公共交通替代。'),
 dict(id='S26', cls='transport', a_en=['the city'], a_zh=['该市'],
      c_en='{A} {launched|scrapped} congestion charging downtown.',
      c_zh='{A}{开征|取消}了中心城区拥堵费。',
      e_en='Private car trips into the core {fell|rebounded}.',
      e_zh='进入核心区的小汽车出行随之{减少|回升}。',
      m_en='Pricing the road discourages marginal car trips.',
      m_zh='道路定价抑制边际驾车出行。'),
 dict(id='S27', cls='transport', a_en=['ride-hailing subsidies'], a_zh=['网约车补贴'],
      c_en='{A} {expanded|were withdrawn}.',
      c_zh='{A}{扩大|退出}了。',
      e_en='Taxi ridership {shifted away|partially returned}.',
      e_zh='出租车客流随之{流失|部分回流}。',
      m_en='Cheaper substitutes pull demand from incumbents.',
      m_zh='更便宜的替代品会分流既有需求。'),
 dict(id='S28', cls='transport', a_en=['an airport'], a_zh=['一座机场'],
      c_en='{A} {added|cut} international routes.',
      c_zh='{A}{新增|削减}了国际航线。',
      e_en='Inbound tourism in the region {grew|shrank}.',
      e_zh='该地区入境旅游随之{增长|萎缩}。',
      m_en='Direct flights lower travel costs and expand arrivals.',
      m_zh='直航降低旅行成本并扩大客源。'),
 dict(id='S29', cls='climate', a_en=['a prolonged drought'], a_zh=['持续干旱'],
      c_en='{A} {hit|lifted} the farming county.',
      c_zh='{A}{侵袭|远离}了这个农业县。',
      e_en='Crop yields {shrunk|rebounded}.',
      e_zh='农作物产量随之{下降|回升}。',
      m_en='Soil moisture deficit stunts growth and cuts yields.',
      m_zh='土壤水分亏缺抑制作物生长并降低产量。'),
 dict(id='S30', cls='climate', a_en=['river flooding'], a_zh=['河流洪涝'],
      c_en='{A} {inundated|spared} the low-lying towns.',
      c_zh='{A}{淹没|未波及}低洼城镇。',
      e_en='Property insurance claims from the area {spiked|stayed flat}.',
      e_zh='该地区财产险报案量随之{激增|平稳}。',
      m_en='Flood damage generates insured-loss claims.',
      m_zh='洪灾损失产生保险赔付。'),
 dict(id='S31', cls='climate', a_en=['a record heat wave'], a_zh=['创纪录热浪'],
      c_en='{A} {blanketed|missed} the region.',
      c_zh='{A}{笼罩|未影响}该地区。',
      e_en='Electricity demand for cooling {surged|eased}.',
      e_zh='降温用电负荷随之{激增|缓解}。',
      m_en='Cooling degree days track air-conditioning load.',
      m_zh='制冷需求与降温日数高度相关。'),
 dict(id='S32', cls='climate', a_en=['a carbon price'], a_zh=['碳价'],
      c_en='{A} {took hold|was waived} for heavy industry.',
      c_zh='{A}对重工业{正式生效|被豁免}。',
      e_en='Coal-fired generation {retreated|held}.',
      e_zh='煤电出力随之{回落|维持}。',
      m_en='Pricing emissions shifts dispatch toward cheaper low-carbon units.',
      m_zh='排放定价使调度转向更便宜的低碳电源。'),
 dict(id='S33', cls='consumption', a_en=['a food-safety scandal'], a_zh=['一起食品安全事件'],
      c_en='{A} {erupted|was quickly resolved} at the chain.',
      c_zh='{A}在这家连锁品牌{爆发|迅速澄清}。',
      e_en='Its store traffic {collapsed|stabilized}.',
      e_zh='其门店客流随之{骤降|企稳}。',
      m_en='Safety scares repel diners faster than promotions attract them.',
      m_zh='安全恐慌对客流的驱离远快于促销吸引。'),
 dict(id='S34', cls='consumption', a_en=['a popular festival week'], a_zh=['一个热门节假日周'],
      c_en='{A} {approached|passed without fanfare}.',
      c_zh='{A}{临近|平淡度过}。',
      e_en='Train and flight bookings {surged|stayed soft}.',
      e_zh='火车与机票预订随之{激增|低迷}。',
      m_en='Holiday windows concentrate leisure travel demand.',
      m_zh='假期窗口集中释放休闲出行需求。'),
 dict(id='S35', cls='consumption', a_en=['a celebrity endorsement'], a_zh=['一次明星代言'],
      c_en='{A} {launched|ended} for the sneaker line.',
      c_zh='球鞋产品线的{A}{启动|终止}了。',
      e_en='First-week sales {beat|missed} forecasts.',
      e_zh='首周销量随之{超出|不及}预期。',
      m_en='Endorsements shift attention and perceived status.',
      m_zh='代言转移注意力并赋予身份符号。'),
 dict(id='S36', cls='consumption', a_en=['the cinema chain'], a_zh=['该影院院线'],
      c_en='{A} {screened|passed on} the blockbuster premiere.',
      c_zh='{A}{放映|放弃}了大片首映。',
      e_en='Weekend ticket revenue {soared|stayed thin}.',
      e_zh='周末票房收入随之{大涨|低迷}。',
      m_en='Exclusive premieres draw audiences to venues.',
      m_zh='独家首映把观众吸引到影院。'),
 dict(id='S37', cls='policy', a_en=['the province'], a_zh=['该省'],
      c_en='{A} {tightened|relaxed} household purchase restrictions.',
      c_zh='{A}{收紧|放松}了家庭购房限制。',
      e_en='Speculative purchases {cooled|picked up}.',
      e_zh='投机性购房随之{降温|升温}。',
      m_en='Purchase limits directly cap buyer eligibility.',
      m_zh='限购直接约束购房资格。'),
 dict(id='S38', cls='policy', a_en=['a bottle-deposit scheme'], a_zh=['饮料瓶押金制度'],
      c_en='{A} {began|was abolished} nationwide.',
      c_zh='{A}在全国{开始推行|被取消}。',
      e_en='Littered beverage containers {declined|crept up}.',
      e_zh='随意丢弃的饮料容器随之{减少|增多}。',
      m_en='Refundable deposits pay consumers to return containers.',
      m_zh='可退还押金激励消费者归还容器。'),
 dict(id='S39', cls='policy', a_en=['the city'], a_zh=['该市'],
      c_en='{A} {installed|removed} speed cameras on arterial roads.',
      c_zh='{A}在主干道{加装|拆除}了测速摄像头。',
      e_en='Speeding violations on those roads {dropped|crept up}.',
      e_zh='这些道路的超速违法随之{减少|抬头}。',
      m_en='Automated enforcement raises the expected cost of speeding.',
      m_zh='自动执法提高超速的预期成本。'),
 dict(id='S40', cls='labor', a_en=['the platform economy'], a_zh=['平台经济'],
      c_en='{A} {expanded|contracted} gig courier jobs.',
      c_zh='{A}的零工快递岗位大幅{增加|减少}。',
      e_en='Standard employment contracts in delivery {thinned|grew}.',
      e_zh='快递行业的标准劳动合同随之{减少|增加}。',
      m_en='Gig growth substitutes contract work for formal employment.',
      m_zh='零工扩张以非正规就业替代正规就业。'),
 dict(id='S41', cls='safety', a_en=['street lighting in the district'], a_zh=['该区的道路照明'],
      c_en='{A} {improved|deteriorated} sharply.',
      c_zh='{A}明显{改善|恶化}。',
      e_en='Night-time pedestrian accidents {fell|rose}.',
      e_zh='夜间行人事故随之{下降|上升}。',
      m_en='Visibility reduces nighttime collision risk.',
      m_zh='可见度降低夜间碰撞风险。'),
 dict(id='S42', cls='safety', a_en=['a counterfeit-drug ring'], a_zh=['一个假药团伙'],
      c_en='{A} {was dismantled|expanded} by police.',
      c_zh='警方{捣毁|未能遏制}{A}。',
      e_en='Related poisoning cases {dropped|rose}.',
      e_zh='相关中毒案例随之{下降|上升}。',
      m_en='Removing fake medicines cuts exposure to harmful doses.',
      m_zh='清除假药减少有害暴露。'),
 dict(id='S43', cls='welfare', a_en=['the city'], a_zh=['该市'],
      c_en='{A} {extended|trimmed} unemployment benefit duration.',
      c_zh='{A}{延长|缩短}了失业救济期限。',
      e_en='Job-search intensity among the unemployed {eased|increased}.',
      e_zh='失业者的求职强度随之{下降|上升}。',
      m_en='Longer benefits lower the urgency of accepting offers.',
      m_zh='更长的救济降低接受工作的紧迫性。'),
 dict(id='S44', cls='welfare', a_en=['food-stamp eligibility'], a_zh=['食品券覆盖范围'],
      c_en='{A} {broadened|narrowed}.',
      c_zh='{A}{扩大|收缩}了。',
      e_en='Grocery spending among poor households {rose|fell}.',
      e_zh='贫困家庭食品支出随之{增加|减少}。',
      m_en='Transfers relax household budget constraints.',
      m_zh='转移支付放松家庭预算约束。'),
 dict(id='S45', cls='energy', a_en=['heating subsidies for the elderly'], a_zh=['老年人取暖补贴'],
      c_en='{A} {increased|were slashed}.',
      c_zh='{A}大幅{提高|削减}。',
      e_en='Winter hypothermia admissions {fell|rose}.',
      e_zh='冬季低温症入院随之{减少|增加}。',
      m_en='Adequate heating prevents cold-related illness.',
      m_zh='充足供暖预防低温相关疾病。'),
 dict(id='S46', cls='energy', a_en=['rooftop solar adoption'], a_zh=['屋顶光伏普及'],
      c_en='{A} {spread|stalled} in the suburb.',
      c_zh='{A}在郊区{加速铺开|陷入停滞}。',
      e_en='Household grid electricity purchases {declined|held}.',
      e_zh='家庭电网购电量随之{下降|维持}。',
      m_en='Self-generation displaces grid purchases.',
      m_zh='自发自用替代电网购电。'),
 dict(id='S47', cls='consumption', a_en=['grocery e-commerce'], a_zh=['生鲜电商'],
      c_en='{A} {gained|lost} market share in the district.',
      c_zh='{A}在该区的市场份额{上升|下降}。',
      e_en='Wet-market stalls {saw thinner|regained} footfall.',
      e_zh='菜市场的客流随之{减少|回升}。',
      m_en='Online substitutes divert routine grocery trips.',
      m_zh='线上替代分流日常买菜客流。'),
 dict(id='S48', cls='demography', a_en=['marriage registrations'], a_zh=['结婚登记数'],
      c_en='{A} {fell to a decade low|rose to a decade high}.',
      c_zh='{A}降至十年来{低点|高位}。',
      e_en='Demand for wedding services {weakened|strengthened}.',
      e_zh='婚庆服务需求随之{走弱|走强}。',
      m_en='Weddings are the direct input to wedding-services demand.',
      m_zh='结婚是婚庆服务的直接需求来源。'),
]

# --------------------------------------------------------------------------
# NEG-HARD SCENARIOS: premise X; candidates Y & Y2 are topically near but
# genuinely non-causal w.r.t. X (co-movement under common cause Z, same-period
# coincidence, after-the-fact, background stats, peer events). {N} = filler.
# --------------------------------------------------------------------------
SCEN_FIN = [
 ('Shares of {N} jumped 6% in morning trade.',
  'A software firm with a similar ticker also jumped that morning.',
  'The tech-heavy index rose about 1% the same morning.',
  '{N}的股价早盘跳涨6%。',
  '一家代码相近的软件公司股价同日早盘也大涨。',
  '科技股权重指数同日上涨约1%。',
  'common cause: a broad tech-sector rally'),
 ('{N} faced accelerating deposit outflows last week.',
  'Two other banks in the same region reported outflows the same week.',
  'The bank\'s marketing budget had risen the previous quarter.',
  '{N}上周存款流失加速。',
  '同地区另外两家银行同一周也报告存款流失。',
  '该行上一季度的营销预算有所增加。',
  'common cause: regional financial stress'),
 ('Trading volume in the futures contract tied to {N} spiked at 14:00.',
  'A finance livestream mentioned the contract that evening.',
  'The contract\'s price stayed inside its usual range that day.',
  '与{N}挂钩的期货合约成交量在14:00激增。',
  '一档财经直播当晚提到了该合约。',
  '该合约当日价格始终处于常规波动区间。',
  'after-the-fact / within-range movement'),
 ('The bond spread of {N} widened notably this week.',
  'The issuer\'s headquarters held a scheduled fire drill that week.',
  'A neighboring issuer\'s spread widened too.',
  '{N}的债券利差本周明显走阔。',
  '发行人总部当周进行了一次例行消防演习。',
  '相邻发行人的利差同样走阔。',
  'common cause: sector-wide credit concerns'),
 ('The exchange halted trading in {N} at 10:20.',
  'The stock\'s investor forum saw heavy posting traffic that morning.',
  'A similar halt had occurred for an unrelated stock last week.',
  '交易所在10:20暂停了{N}的交易。',
  '该股票的投资者论坛当天上午发帖量激增。',
  '上周另一只不相关的股票也曾被停牌。',
  'forum traffic / coincidental precedent'),
 ('{N} processed an unusual spike in insurance claims in August.',
  'A rival insurer ran heavy advertising campaigns in August.',
  'August is a peak vacation month for claim adjusters.',
  '{N}8月处理的保险理赔量异常激增。',
  '一家竞争对手保险公司8月投放了大量广告。',
  '8月是理赔审核员的休假高峰月。',
  'confounded by typhoon season (candidates unrelated)'),
 ('Short interest in {N} climbed to a two-year high this month.',
  'The stock was mentioned in a widely read newsletter the same month.',
  'Its average daily volume was unchanged this month.',
  '{N}的空头持仓本月升至两年高位。',
  '该股同月被一份广为流传的通讯提及。',
  '其日均成交量本月没有变化。',
  'mention / volume-unchanged backgrounds'),
 ('Open-market liquidity injections on Tuesday boosted the cash position of {N}.',
  'Money-market chat groups were unusually active on Tuesday.',
  'The operation was widely anticipated beforehand.',
  '央行周二通过公开市场操作注入流动性。',
  '货币市场讨论群组周二异常活跃。',
  '该操作此前已被市场广泛预期。',
  'chat activity / anticipation backgrounds'),
 ('Goldman-style prime brokerage of {N} raised margin requirements on Monday.',
  'Several clients complained on social media on Monday.',
  'A peer brokerage had raised margins the prior month.',
  '{N}的主经纪商部门周一上调了保证金要求。',
  '数家客户周一在社交媒体上抱怨。',
  '一家同行经纪商上月已上调保证金。',
  'complaints / prior-month peer background'),
 ('The IPO of {N} priced at the bottom of its range on Friday.',
  'The lead underwriter published a sector note the same Friday.',
  'Two tech IPOs priced the week before.',
  '{N}的IPO周五以区间下限定价。',
  '主承销商同周五发布了一份行业报告。',
  '此前一周有两只科技股IPO定价。',
  'sector note / IPO-calendar background'),
 ('Foreign holdings of {N} government bonds fell for a third month.',
  'The currency slipped about 2% over the same period.',
  'A rival market attracted headline inflows that quarter.',
  '{N}政府债券的外资持有量连续第三个月下降。',
  '同期本币贬值约2%。',
  '同期另一市场出现引人注目的资金流入。',
  'currency co-movement under shared macro drivers'),
 ('A supermarket chain, {N}, recalled one salad line on Wednesday.',
  'Its loyalty-program sign-ups rose 3% that month.',
  'Two rival chains extended promotions the same week.',
  '连锁超市{N}周三召回一款沙拉产品。',
  '其会员注册数当月上升3%。',
  '两家竞争对手连锁同周延长促销。',
  'loyalty stats / rival promos backgrounds'),
 ('Two-year yields on {N} sovereign bonds fell further on Thursday.',
  'A popular podcast discussed recessions on Thursday.',
  'Equity volumes were below average on Thursday.',
  '收益率曲线周四进一步倒挂。',
  '一档热门播客周四讨论了衰退话题。',
  '周四股市成交量低于均值。',
  'media discussion / volume background'),
]
SCEN_SOC = [
 ('Night buses in {N} were unusually crowded last Friday.',
  'The bus operator repainted much of its fleet earlier that month.',
  'A stadium in another district hosted a daytime match that Friday.',
  '{N}的夜班公交上周五异常拥挤。',
  '公交运营方当月早些时候重新喷涂了大部分车辆。',
  '另一区的一座体育场当周五举办了一场日场比赛。',
  'fleet maintenance / unrelated-district daytime event'),
 ('The metro station at {N} recorded record exits at 09:10.',
  'A nearby office tower held a fire drill at 09:30.',
  'Station retail kiosks reported strong morning sales.',
  '{N}地铁站09:10录得创纪录出站量。',
  '附近一栋写字楼09:30举行消防演习。',
  '站内零售亭报告早间销售旺盛。',
  'drill timing / kiosk sales backgrounds'),
 ('Air quality readings in {N} deteriorated sharply on Monday.',
  'An outdoor market reported lower footfall on Monday.',
  'The city planted street trees along another avenue on Monday.',
  '{N}的空气质量读数周一大幅恶化。',
  '一家露天集市周一客流偏低。',
  '该市周一在另一条大街种植行道树。',
  'market footfall / tree-planting backgrounds'),
 ('Emergency calls about fallen trees spiked in {N} during the storm night.',
  'Local takeout delivery times lengthened the same night.',
  'A hardware chain sold out of flashlights that week.',
  '暴雨夜{N}的树木倒伏报警激增。',
  '同夜本地外卖配送时长拉长。',
  '当周一家五金连锁的手电筒售罄。',
  'co-occurrence under storm, but takeout slowdown is policy-driven; pre-registered non-causal to tree calls'),
 ('Vaccination queue times at {N} clinics doubled on Saturday.',
  'A pharmacy chain discounted vitamins that weekend.',
  'The clinics\' parking lot was resurfaced that month.',
  '{N}各接种点周六的排队时长翻倍。',
  '一家连锁药房当周末对维生素打折。',
  '这些诊所的停车场当月重新铺装。',
  'pharmacy promo / resurfacing backgrounds'),
 ('Subway ridership to the tech park in {N} fell 12% this quarter.',
  'The park\'s cafeteria changed its lunch supplier this quarter.',
  'A rival tech park offered free shuttles this quarter.',
  '{N}科技园的地铁客流本季度下降12%。',
  '园区食堂本季度更换了午餐供应商。',
  '另一家科技园本季度推出免费班车。',
  'cafeteria change / rival shuttles backgrounds'),
 ('Water pressure complaints in {N}\'s old town tripled on Tuesday.',
  'A bakery on the main street closed for renovation on Tuesday.',
  'The utility\'s annual report was released on Wednesday.',
  '{N}老城区的水压投诉周二增至三倍。',
  '主街一家面包店周二停业装修。',
  '水务公司年报周三发布。',
  'bakery closure / report release backgrounds'),
 ('Gym attendance in {N} dropped sharply after the holiday.',
  'A smoothie kiosk near the gym closed after the holiday.',
  'The gym\'s app was updated after the holiday.',
  '{N}健身房出勤在假期后骤降。',
  '健身房旁的果汁亭假期后关闭。',
  '健身房的应用假期后更新。',
  'kiosk closure / app update backgrounds'),
 ('Sightings of wild boars on {N}\'s ring road rose this month.',
  'A new bakery opened near the ring road this month.',
  'Two jogging groups rescheduled their routes this month.',
  '{N}环路上野猪出没本月增多。',
  '环路边一家新面包店本月开业。',
  '两个跑团本月调整了路线。',
  'bakery / jogging-route backgrounds'),
 ('The city library in {N} extended hours on a trial basis.',
  'A coffee chain opened beside the library that week.',
  'The library\'s fines policy was unchanged that year.',
  '{N}市图书馆试点延长开放时间。',
  '一家咖啡连锁当周在图书馆旁开业。',
  '图书馆的罚款政策当年未变。',
  'coffee opening / unchanged policy backgrounds'),
 ('Local honey sales at {N}\'s market doubled in spring.',
  'A beekeeping documentary aired on regional TV in spring.',
  'The market\'s parking fee rose in spring.',
  '{N}市场的本地蜂蜜销量春季翻倍。',
  '一档养蜂纪录片春季在地方台播出。',
  '市场停车费春季上调。',
  'documentary / parking-fee backgrounds'),
 ('Food-delivery orders in {N} surged during the cold snap.',
  'A hotpot chain launched gift cards during the cold snap.',
  'Bus heating worked normally during the cold snap.',
  '寒潮期间{N}的外卖订单激增。',
  '一家火锅连锁寒潮期间发行礼品卡。',
  '寒潮期间公交车供暖正常。',
  'gift cards / normal heating backgrounds'),
 ('Complaints about scooter parking clutter rose in {N} in June.',
  'The operator repainted its scooters in June.',
  'A nightclub district extended hours in June.',
  '{N}对共享滑板车乱停放的投诉6月上升。',
  '运营方6月为滑板车重新喷漆。',
  '一个夜店聚集区6月延长营业时间。',
  'repaint / district-hours backgrounds'),
 ('Kindergarten applications in {N} exceeded places this year.',
  'A new residential tower topped out this year.',
  'The district\'s library budget was flat this year.',
  '{N}的幼儿园报名数今年超出学位数。',
  '一栋新住宅楼今年封顶。',
  '该区图书馆预算今年持平。',
  'tower completion / flat budget backgrounds'),
]

# --------------------------------------------------------------------------
# GENERATION ENGINE
# --------------------------------------------------------------------------
import json, random, re, sys, hashlib
from collections import Counter
from pathlib import Path

FLIP = re.compile(r'\{([^{}|]+)\|([^{}|]+)\}')
ROOT = Path(__file__).resolve().parent.parent
SEED = 20261012
TIME_EN = ['Last quarter', 'Recently', 'In the past month', 'Earlier this year', 'During the latest reporting period', 'In recent weeks']
TIME_ZH = ['上季度', '近期', '过去一个月里', '今年早些时候', '最新报告期内', '最近几周']
PREM_TMPL = [('t', 1), ('t', -1), ('bare', 1), ('bare', -1)]
# ('t', v): with time marker, valence v(+1/-1); ('bare', v): no time marker

def flip(s):   # + -> - valence
    return FLIP.sub(lambda g: g.group(2), s)
def plus(s):
    return FLIP.sub(lambda g: g.group(1), s)
def sent(s):   # capitalize first letter (en)
    return s[0].upper() + s[1:] if s else s
def fill(s, actor):
    return s.replace('{A}', actor)

def make_real():
    """All real instantiations (en+zh pairs share construction index)."""
    rng = random.Random(SEED)
    out = []
    for mech in FIN + SOC:
        dom = 'fin' if mech['id'].startswith('F') else 'soc'
        actors = list(zip(mech['a_en'], mech['a_zh']))
        combos = [(ai, t, tpl) for ai in range(len(actors)) for t in range(len(TIME_EN)) for tpl in PREM_TMPL
                  if tpl[0] == 't' or t == 0]  # bare template once per actor
        rng.shuffle(combos)
        seen_pre, used_n = set(), 0
        for (ai, t, (tpl, val)) in combos:
            if used_n >= 8:
                break
            a_en, a_zh = actors[ai]
            # clauses at premise valence; anti = opposite valence
            c_txt_en = (plus(mech['c_en']) if val == 1 else flip(mech['c_en'])).rstrip('.')
            c_txt_zh = (plus(mech['c_zh']) if val == 1 else flip(mech['c_zh'])).rstrip('。')
            e_txt_en = (plus(mech['e_en']) if val == 1 else flip(mech['e_en'])).rstrip('.')
            e_txt_zh = (plus(mech['e_zh']) if val == 1 else flip(mech['e_zh'])).rstrip('。')
            a_e_en = (flip(mech['e_en']) if val == 1 else plus(mech['e_en'])).rstrip('.')
            a_e_zh = (flip(mech['e_zh']) if val == 1 else plus(mech['e_zh'])).rstrip('。')
            a_c_en = (flip(mech['c_en']) if val == 1 else plus(mech['c_en'])).rstrip('.')
            a_c_zh = (flip(mech['c_zh']) if val == 1 else plus(mech['c_zh'])).rstrip('。')
            ask = 'effect' if used_n % 2 == 0 else 'cause'
            if tpl[0] == 't':
                pre_en = f'{TIME_EN[t]}, {fill(c_txt_en if ask == "effect" else e_txt_en, a_en)}'
                pre_zh = f'{TIME_ZH[t]}，{fill(c_txt_zh if ask == "effect" else e_txt_zh, a_zh)}。'
            else:
                pre_en = sent(fill(c_txt_en if ask == 'effect' else e_txt_en, a_en))
                pre_zh = fill(c_txt_zh if ask == 'effect' else e_txt_zh, a_zh) + '。'
            if pre_en.lower() in seen_pre:
                continue
            seen_pre.add(pre_en.lower()); used_n += 1
            if ask == 'effect':
                cor_en, cor_zh = sent(fill(e_txt_en, a_en)), fill(e_txt_zh, a_zh) + '。'
                dis_en, dis_zh = sent(fill(a_e_en, a_en)), fill(a_e_zh, a_zh) + '。'
            else:
                cor_en, cor_zh = sent(fill(c_txt_en, a_en)), fill(c_txt_zh, a_zh) + '。'
                dis_en, dis_zh = sent(fill(a_c_en, a_en)), fill(a_c_zh, a_zh) + '。'
            out.append(dict(dom=dom, mech=mech['id'], ask=ask, val=val, tpl=tpl,
                            pre_en=pre_en, pre_zh=pre_zh, cor_en=cor_en, cor_zh=cor_zh,
                            dis_en=dis_en, dis_zh=dis_zh,
                            m_en=mech['m_en'], m_zh=mech['m_zh']))
    rng.shuffle(out)
    return out


def make_neg_easy(n_target, used_real_keys):
    """Cross-domain candidates: premise from one domain, candidates from the other."""
    rng = random.Random(SEED + 1)
    out, guard = [], 0
    allm = FIN + SOC
    while len(out) < n_target and guard < n_target * 60:
        guard += 1
        m1 = rng.choice(allm)
        d1 = 'fin' if m1['id'].startswith('F') else 'soc'
        cand_pool = [m for m in allm if (('fin' if m['id'].startswith('F') else 'soc') != d1)]
        m2, m3 = rng.sample(cand_pool, 2)
        val1 = rng.choice([1, -1]); ask = rng.choice(['cause', 'effect'])
        ai1 = rng.randrange(min(len(m1['a_en']), len(m1['a_zh'])))
        a1, a1z = m1['a_en'][ai1], m1['a_zh'][ai1]
        t = rng.randrange(len(TIME_EN))
        if ask == 'effect':
            pre = fill(plus(m1['c_en']) if val1 == 1 else flip(m1['c_en']), a1)
            prez = fill(plus(m1['c_zh']) if val1 == 1 else flip(m1['c_zh']), a1z)
        else:
            pre = fill(plus(m1['e_en']) if val1 == 1 else flip(m1['e_en']), a1)
            prez = fill(plus(m1['e_zh']) if val1 == 1 else flip(m1['e_zh']), a1z)
        pre_en = f'{TIME_EN[t]}, {pre.rstrip(".")}'; pre_zh = f'{TIME_ZH[t]}，{prez.rstrip("。")}。'
        key = (pre_en[:70], pre_zh[:45])
        if key in used_real_keys:
            continue
        c2 = plus(m2['e_en'] if rng.random() < .5 else m2['c_en'])
        c2z = plus(m2['e_zh'] if rng.random() < .5 else m2['c_zh'])
        ai2 = rng.randrange(min(len(m2['a_en']), len(m2['a_zh'])))
        a2, a2z = m2['a_en'][ai2], m2['a_zh'][ai2]
        c3 = plus(m3['e_en'] if rng.random() < .5 else m3['c_en'])
        c3z = plus(m3['e_zh'] if rng.random() < .5 else m3['c_zh'])
        ai3 = rng.randrange(min(len(m3['a_en']), len(m3['a_zh'])))
        a3, a3z = m3['a_en'][ai3], m3['a_zh'][ai3]
        c2_en, c2_zh = sent(c2.rstrip('.').replace('{A}', a2)), c2z.rstrip('。').replace('{A}', a2z) + '。'
        c3_en, c3_zh = sent(c3.rstrip('.').replace('{A}', a3)), c3z.rstrip('。').replace('{A}', a3z) + '。'
        if c2_en == c3_en:
            continue
        used_real_keys.add(key)
        out.append(dict(dom=d1, mech=m1['id'], ask=ask, kind='neg-easy',
                        pre_en=pre_en, pre_zh=pre_zh, c2_en=c2_en, c2_zh=c2_zh,
                        c3_en=c3_en, c3_zh=c3_zh))
    return out


def make_neg_hard(n_target):
    rng = random.Random(SEED + 2)
    out = []
    per = (n_target + len(SCEN_FIN) + len(SCEN_SOC) - 1) // (len(SCEN_FIN) + len(SCEN_SOC))
    names_en = ['Meridian Foods', 'Kestrel Motors', 'Blueharbor Bank', 'NovaText Media', 'Pinewood Labs', 'Crestline Energy', 'Foxglove Retail', 'Summit Logistics', 'Riverbend City', 'Larkspur County', 'Ironvale District', 'Cobalt Bay']
    names_zh = ['美瀚食品','隼驰汽车','蓝港银行','新语传媒','松石实验室','峰线能源','狐尾零售','巅顶物流','河湾市','雀翎县','铁谷区','钴蓝湾']
    for scen_list, dom in ((SCEN_FIN, 'fin'), (SCEN_SOC, 'soc')):
        for si, (x_en, y_en, y2_en, x_zh, y_zh, y2_zh, note) in enumerate(scen_list):
            for k in range(per):
                if len(out) >= n_target and dom == 'soc': break
                ni = (si * 7 + k) % len(names_en)
                n_en, n_zh = names_en[ni], names_zh[ni]
                item = dict(dom=dom, mech=f'SC{si}', ask=rng.choice(['cause', 'effect']), kind='neg-hard',
                            pre_en=x_en.replace('{N}', n_en), pre_zh=x_zh.replace('{N}', n_zh),
                            c2_en=y_en.replace('{N}', n_en), c2_zh=y_zh.replace('{N}', n_zh),
                            c3_en=y2_en.replace('{N}', n_en), c3_zh=y2_zh.replace('{N}', n_zh),
                            note=note)
                out.append(item)
    return out[:n_target]

def assemble():
    reals = make_real()
    used_keys = {(r['pre_en'][:70], r['pre_zh'][:45]) for r in reals}
    neg_easy = make_neg_easy(240, used_keys)
    neg_hard = make_neg_hard(240)
    rng = random.Random(SEED + 3)
    # cal: stratified 64/18/18
    cal_reals, test_reals = reals[:64], reals[64:64+640]
    cal_ne, test_ne = neg_easy[:18], neg_easy[18:18+200]
    cal_nh, test_nh = neg_hard[:18], neg_hard[18:18+200]
    def emit(items, prefix):
        rows_en, rows_zh = [], []
        pos = Counter()
        for i, it in enumerate(items):
            g = rng.random()
            if it.get('kind') in ('neg-easy', 'neg-hard'):
                h1, h2 = (it['c2_en'], it['c3_en']) if g < .5 else (it['c3_en'], it['c2_en'])
                z1, z2 = (it['c2_zh'], it['c3_zh']) if g < .5 else (it['c3_zh'], it['c2_zh'])
                gold = '3'; typ = 'negative' if it['kind'] == 'neg-easy' else 'neg-hard'
            else:
                h1, h2 = (it['cor_en'], it['dis_en']) if g < .5 else (it['dis_en'], it['cor_en'])
                z1, z2 = (it['cor_zh'], it['dis_zh']) if g < .5 else (it['dis_zh'], it['cor_zh'])
                gold = '1' if g < .5 else '2'; typ = 'real'
            idx = f'{prefix}-{i:04d}'
            base = dict(idx=idx, type=typ, premise=it['pre_en'], ask_for=it['ask'], h1=h1, h2=h2, gold=gold,
                        mech_id=it.get('mech'), dom=it['dom'],
                        explanation=it.get('m_en') or it.get('note', ''))
            base_zh = dict(base); base_zh.update(premise=it['pre_zh'].replace('随之', ''), h1=z1, h2=z2, explanation=it.get('m_zh') or it.get('note', ''))
            rows_en.append(base); rows_zh.append(base_zh)
            pos[(typ, gold)] += 1
        return rows_en, rows_zh, pos
    cal_en, cal_zh, pos_cal = emit(cal_reals + cal_ne + cal_nh, 'finsoc-cal')
    test_en, test_zh, pos_test = emit(test_reals + test_ne + test_nh, 'fs')
    return cal_en, cal_zh, test_en, test_zh, pos_cal, pos_test

def validate(cal_en, cal_zh, test_en, test_zh):
    rep = {}
    allt = test_en + cal_en
    rep['counts'] = dict(cal=len(cal_en), test=len(test_en), total=len(cal_en) + len(test_en))
    rep['type_gold'] = {f'{k[0]}|{k[1]}': v for k, v in Counter((r['type'], r['gold']) for r in allt).items()}
    rep['ask_for'] = dict(Counter(r['ask_for'] for r in allt if r['type'] == 'real'))
    rep['domain'] = dict(Counter(r['dom'] for r in allt))
    pre = [r['premise'].lower() for r in allt]
    rep['premise_unique'] = len(set(pre)) == len(pre)
    rep['h_distinct'] = all(r['h1'] != r['h2'] for r in allt)
    rep['no_empty'] = all(r['premise'] and r['h1'] and r['h2'] for r in allt)
    # zh pairing integrity
    zmap = {r['idx']: r for r in cal_zh + test_zh}
    rep['zh_pair_ok'] = all(zmap[r['idx']]['gold'] == r['gold'] and zmap[r['idx']]['type'] == r['type'] and zmap[r['idx']]['ask_for'] == r['ask_for'] for r in allt) and len(zmap) == len(allt)
    # leakage vs existing datasets (normalized containment)
    leak_src = []
    for p in ['tmp/ecare_dev.jsonl', 'tmp/exp_items_v2.jsonl', 'tmp/cal_items_v3.jsonl', 'tmp/COPA/train.jsonl']:
        fp = ROOT / p
        if fp.exists():
            for line in open(fp):
                try:
                    o = json.loads(line)
                    leak_src += [o.get('premise', ''), o.get('hypothesis1', ''), o.get('hypothesis2', ''), o.get('h1', ''), o.get('h2', '')]
                except Exception:
                    pass
    leak_src = {s.strip().lower() for s in leak_src if len(s) > 20}
    rep['leak_vs_existing'] = sum(1 for r in allt if r['premise'].strip().lower() in leak_src)
    # premise<->correct-candidate lexical overlap (copy-shortcut audit, real items only)
    def content(s):
        return {w for w in re.findall(r'[a-z]{4,}', s.lower())} - {'that', 'this', 'with', 'from', 'have', 'been', 'were', 'their', 'which', 'about', 'after', 'over', 'more', 'than'}
    ov = []
    for r in test_en:
        if r['type'] != 'real': continue
        cor = r['h1'] if r['gold'] == '1' else r['h2']
        a, b = content(r['premise']), content(cor)
        if a and b: ov.append(len(a & b) / len(a | b))
    rep['overlap_mean'] = round(sum(ov) / max(len(ov), 1), 3)
    rep['overlap_gt60'] = sum(1 for x in ov if x > .6)
    rep['sha_en_test'] = hashlib.sha256(json.dumps(test_en, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:16]
    return rep

if __name__ == '__main__':
    cal_en, cal_zh, test_en, test_zh, pos_cal, pos_test = assemble()
    (ROOT / 'tmp').mkdir(exist_ok=True)
    for name, rows in [('finsoc_en_cal_v1.jsonl', cal_en), ('finsoc_zh_cal_v1.jsonl', cal_zh),
                       ('finsoc_en_test_v1.jsonl', test_en), ('finsoc_zh_test_v1.jsonl', test_zh)]:
        with open(ROOT / 'tmp' / name, 'w', encoding='utf-8') as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + '\n')
    rep = validate(cal_en, cal_zh, test_en, test_zh)
    (ROOT / 'tmp' / 'finsoc_validation_v1.json').write_text(json.dumps(rep, ensure_ascii=False, indent=1))
    print(json.dumps(rep, ensure_ascii=False, indent=1)[:1400])
    print('\n样例(real):'); s = next(r for r in test_en if r['type'] == 'real')
    print(' ', s['premise'], '| gold', s['gold'], '|', s['h1'], '||', s['h2'])
    szh = next(r for r in test_zh if r['type'] == 'real')
    print(' ', szh['premise'], '| gold', szh['gold'], '|', szh['h1'], '||', szh['h2'])
    s = next(r for r in test_en if r['type'] == 'neg-hard')
    print('  neg-hard:', s['premise'], '|', s['h1'], '||', s['h2'])
