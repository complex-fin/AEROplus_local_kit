@echo off
REM =============================================================================
REM AERO+ v4 supervisor -- Windows version of supervisor_v4.sh
REM Daemon-style resumable collection: loops until all result files complete
REM (>= 5220 total rows) or 600 rounds. 429-quota windows are tolerated by the
REM collectors' internal retry; this driver simply re-invokes them each round.
REM NOTE: unlike the bash version (timeout 100 per attempt), cmd has no process
REM timeout -- the collectors' own retry/abort logic is relied upon instead.
REM Usage: scripts\supervisor_v4.bat
REM Log:   tmp\supervisor_v4.log
REM =============================================================================
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0.."

set "PY=python"
where python >nul 2>nul || set "PY=py -3"
where node >nul 2>nul || (echo [ERROR] node not found in PATH & exit /b 1)

if not exist tmp mkdir tmp
echo %date% %time% supervisor_v4 start >> tmp\supervisor_v4.log

for /l %%R in (1,1,600) do (
  call :round
  if "!ALLDONE!"=="1" goto :alldone
)
goto :end

:alldone
echo %time% ALL DONE >> tmp\supervisor_v4.log
echo [supervisor] ALL DONE
exit /b 0

:end
echo [supervisor] round limit reached; re-run to continue (resumable)
exit /b 0

REM ---------------------------------------------------------------------------
REM one round: for every incomplete target, invoke its collector once.
:round
set "ALLDONE=0"

REM P1 e-CARE 450: AERO+ (main system)
call :need tmp\results_aero_exp.jsonl 450
if not errorlevel 1 node scripts\collect_v3.mjs --system aeroplus --input tmp\exp_items_v2.jsonl --output tmp\results_aero_exp.jsonl --conc 4
REM P2 e-CARE 450: cf_cot
call :need tmp\results_cfcot_exp.jsonl 450
if not errorlevel 1 node scripts\collect_v3.mjs --system cf_cot --input tmp\exp_items_v2.jsonl --output tmp\results_cfcot_exp.jsonl --conc 4
REM P2b e-CARE 450: cot + zeroshot
call :need tmp\results_cot_exp.jsonl 450
if not errorlevel 1 node scripts\run_exp.mjs --system cot --input tmp\exp_items_v2.jsonl --output tmp\results_cot_exp.jsonl --conc 4
call :need tmp\results_zeroshot_exp.jsonl 450
if not errorlevel 1 node scripts\run_exp.mjs --system zeroshot --input tmp\exp_items_v2.jsonl --output tmp\results_zeroshot_exp.jsonl --conc 4
REM P2c e-CARE: newer baselines + selfcons (test 450 + cal 60)
for %%S in (selfcons pnps sn_cot g2) do (
  call :need tmp\results_%%S_exp.jsonl 450
  if not errorlevel 1 node scripts\run_exp.mjs --system %%S --input tmp\exp_items_v2.jsonl --output tmp\results_%%S_exp.jsonl --conc 4
  call :need tmp\results_%%S_cal_v3.jsonl 60
  if not errorlevel 1 node scripts\run_exp.mjs --system %%S --input tmp\cal_items_v3.jsonl --output tmp\results_%%S_cal_v3.jsonl --conc 4
)
REM P3 XCOPA per language: aero cal + aero test, then cot, then cfcot
for %%L in (zh vi th sw) do (
  call :need tmp\results_aero_xc%%L_cal.jsonl 30
  if not errorlevel 1 node scripts\collect_v3.mjs --system aeroplus --input tmp\xcopa_%%L_cal.jsonl --output tmp\results_aero_xc%%L_cal.jsonl --conc 4
  call :need tmp\results_aero_xc%%L.jsonl 100
  if not errorlevel 1 node scripts\collect_v3.mjs --system aeroplus --input tmp\xcopa_%%L_test.jsonl --output tmp\results_aero_xc%%L.jsonl --conc 4
)
for %%L in (zh vi th sw) do (
  call :need tmp\results_cot_xc%%L.jsonl 100
  if not errorlevel 1 node scripts\run_exp.mjs --system cot --input tmp\xcopa_%%L_test.jsonl --output tmp\results_cot_xc%%L.jsonl --conc 4
)
for %%L in (zh vi th sw) do (
  call :need tmp\results_cfcot_xc%%L.jsonl 100
  if not errorlevel 1 node scripts\collect_v3.mjs --system cf_cot --input tmp\xcopa_%%L_test.jsonl --output tmp\results_cfcot_xc%%L.jsonl --conc 4
)

REM heartbeat
echo %time% round >> tmp\supervisor_v4.log

REM all-done check (>= 5220 rows)
set /a TOTAL=0
for %%F in (tmp\results_aero_exp.jsonl tmp\results_cfcot_exp.jsonl tmp\results_cot_exp.jsonl tmp\results_zeroshot_exp.jsonl tmp\results_selfcons_exp.jsonl tmp\results_pnps_exp.jsonl tmp\results_sn_cot_exp.jsonl tmp\results_g2_exp.jsonl) do (
  if exist %%F for /f %%C in ('type %%F ^| find /c /v ""') do set /a TOTAL+=%%C
)
for %%F in (tmp\results_aero_xczh.jsonl tmp\results_aero_xcvi.jsonl tmp\results_aero_xcth.jsonl tmp\results_aero_xcsw.jsonl tmp\results_cot_xczh.jsonl tmp\results_cot_xcvi.jsonl tmp\results_cot_xcth.jsonl tmp\results_cot_xcsw.jsonl tmp\results_cfcot_xczh.jsonl tmp\results_cfcot_xcvi.jsonl tmp\results_cfcot_xcth.jsonl tmp\results_cfcot_xcsw.jsonl) do (
  if exist %%F for /f %%C in ('type %%F ^| find /c /v ""') do set /a TOTAL+=%%C
)
echo %time% total rows so far: !TOTAL! >> tmp\supervisor_v4.log
if !TOTAL! GEQ 5220 set "ALLDONE=1"
exit /b 0

REM ---------------------------------------------------------------------------
REM :need <file> <target-rows>  -> errorlevel 0 = file incomplete (needs work)
:need
set "CNT=0"
if exist %~1 for /f %%C in ('type %~1 ^| find /c /v ""') do set "CNT=%%C"
if %CNT% LSS %~2 (exit /b 0) else (exit /b 1)
