#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Hybrid system: AERO+ probes as a VERIFIER on top of CoT answers.

Motivation (v4 results, 2026-10-13): probe signals detect CoT errors with
AUC 0.93 (H5) but the standalone fusion answer is at parity with CoT
(0.764 vs 0.760, n.s.). The information is in the probes; the standalone
decision layer wastes it. This script tests the complementary composition:

    final(item) = CoT answer        if P(CoT correct | probes, conf) >= tau
                = AERO+ (plainds)   otherwise

Fit: L2 logistic verifier on the CALIBRATION split only (same discipline as
the Mondrian layer -- no peeking). Eval: TEST split, McNemar vs CoT and vs
optional reference systems (selfcons etc.).

Also reports: rule-based gate (no learning), tau grid, oracle upper bound.

Usage:
  python3 scripts/aeroplus/hybrid_verifier.py --tag ecare-v4 \
      --aero-cal tmp/results_aeroplus_cal_v3.jsonl \
      --aero-test tmp/results_aero_exp.jsonl \
      --cot-cal  tmp/results_cot_cal_v3.jsonl \
      --cot-test tmp/results_cot_exp.jsonl \
      [--ref name=path ...] [--alpha-s 1.5]
Writes tmp/hybrid_<tag>.json
"""
import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
import fusion
from stats_tests import mcnemar_exact

TMP = None  # set in main

FEATS = ['cot_conf', 'agree', 'betp_cot', 'betp_max', 'betp_margin',
         'N_gap', 'S_gap', 'f_gap', 'K']


def load(path):
    if not os.path.exists(path):
        raise SystemExit(f'[missing] {path}')
    out = []
    for l in open(path, encoding='utf-8'):
        l = l.strip()
        if l:
            try:
                out.append(json.loads(l))
            except json.JSONDecodeError:
                pass
    return out


def pred_int(r):
    """CoT/baseline pred '1'/'2'/'3' -> class 1/2/0 (3 = neither -> C0)."""
    try:
        p = int(r.get('pred'))
    except (TypeError, ValueError):
        return None
    return 0 if p == 3 else p


def gold_int(r):
    g = int(r['gold'])
    return 0 if g == 3 else g


def feats_one(aero_rec, cot_rec, alpha_s):
    """Feature vector for 'is the CoT answer correct?' (see FEATS)."""
    src = fusion.extract_sources(aero_rec, alpha_s)
    f = fusion.fuse(aero_rec, 'plainds', None, alpha_s)
    betp = f['betp']
    k = pred_int(cot_rec)
    if k is None:
        return None
    conf = float(cot_rec.get('conf') or 0.5)
    conf = min(1.0, max(0.0, conf))
    aero_pred = max(betp, key=betp.get)
    N1, N2 = src['N'].get(1, 0.5), src['N'].get(2, 0.5)
    S1, S2 = src['S'].get(1, 0.5), src['S'].get(2, 0.5)
    f1, f2 = src['f'].get(1, 0.5), src['f'].get(2, 0.5)
    # for cot answer k: support of the chosen candidate vs the other
    if k in (1, 2):
        n_gap = (N1 if k == 1 else N2) - (N2 if k == 1 else N1)
        s_gap = (S1 if k == 1 else S2) - (S2 if k == 1 else S1)
        f_gap = (f1 if k == 1 else f2) - (f2 if k == 1 else f1)
    else:  # k == 0 (CoT said 'neither'): support = how weak BOTH candidates are
        n_gap, s_gap, f_gap = -max(N1, N2), -max(S1, S2), -max(f1, f2)
    betp_max = max(betp.values())
    return [conf,
            1.0 if aero_pred == k else 0.0,
            betp.get(k, 0.0),
            betp_max,
            betp_max - betp.get(k, 0.0),
            n_gap, s_gap, f_gap,
            f['K']], aero_pred, k


def fit_logistic(X, y, l2=1.0, iters=50):
    """Newton-IRLS L2 logistic; X standardized outside."""
    n, d = X.shape
    w = np.zeros(d)
    b = 0.0
    for _ in range(iters):
        z = X @ w + b
        p = 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
        g_w = X.T @ (p - y) / n + (l2 / n) * w   # normalized consistently with H
        g_b = np.mean(p - y)
        W = np.clip(p * (1 - p), 1e-6, None)
        H = (X.T * W) @ X / n + (l2 / n) * np.eye(d)
        try:
            dw = np.linalg.solve(H, g_w)
        except np.linalg.LinAlgError:
            break
        w -= dw
        b -= g_b / max(np.mean(W), 1e-6)
        if np.max(np.abs(dw)) < 1e-8:
            break
    return w, b


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def acc(rows):
    return sum(1 for r in rows if r['hyb_correct']) / max(len(rows), 1)


def mcnemar(a, b):
    """a, b: lists of bool (correct?) over the SAME items."""
    bb = sum(1 for x, y in zip(a, b) if x and not y)
    cc = sum(1 for x, y in zip(a, b) if y and not x)
    return bb, cc, mcnemar_exact(bb, cc)


def main():
    global TMP
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', default='ecare-v4')
    ap.add_argument('--aero-cal', required=True)
    ap.add_argument('--aero-test', required=True)
    ap.add_argument('--cot-cal', required=True)
    ap.add_argument('--cot-test', required=True)
    ap.add_argument('--refs', nargs='*', default=[],
                    help="extra baselines name=path (e.g. selfcons=tmp/results_selfcons_exp.jsonl)")
    ap.add_argument('--alpha-s', type=float, default=1.5)
    ap.add_argument('--l2', type=float, default=1.0)
    args = ap.parse_args()

    TMP = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), 'tmp')

    def build(cot_rows, aero_rows):
        amap = {r['idx']: r for r in aero_rows}
        out = []
        for c in cot_rows:
            a = amap.get(c['idx'])
            if a is None:
                continue
            fk = feats_one(a, c, args.alpha_s)
            if fk is None:
                continue
            (x, aero_pred, k) = fk
            out.append({'idx': c['idx'], 'x': x, 'k': k, 'aero_pred': aero_pred,
                        'gold': gold_int(a),
                        'cot_correct': k == gold_int(a),
                        'aero_correct': aero_pred == gold_int(a)})
        return out

    cal = build(load(args.cot_cal), load(args.aero_cal))
    test = build(load(args.cot_test), load(args.aero_test))
    if len(cal) < 20:
        raise SystemExit(f'[cal too small] {len(cal)} items -- need >= 20')
    if len(test) < 30:
        raise SystemExit(f'[test too small] {len(test)} items')

    Xc = np.array([r['x'] for r in cal])
    yc = np.array([1.0 if r['cot_correct'] else 0.0 for r in cal])
    mu, sd = Xc.mean(0), Xc.std(0) + 1e-9
    w, b = fit_logistic((Xc - mu) / sd, yc, l2=args.l2)

    Xt = np.array([r['x'] for r in test])
    p_hat = sigmoid(((Xt - mu) / sd) @ w + b)
    for r, p in zip(test, p_hat):
        r['p_cot'] = float(p)

    # --- evaluate tau grid -------------------------------------------------
    grid = {}
    for tau in (0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65):
        for r in test:
            use_cot = r['p_cot'] >= tau
            r['hy_pred'] = r['k'] if use_cot else r['aero_pred']
            r['hyb_correct'] = r['hy_pred'] == r['gold']
        flips = sum(1 for r in test if r['hy_pred'] != r['k'])
        good = sum(1 for r in test if r['hy_pred'] != r['k'] and r['hyb_correct'])
        bad = flips - good
        cot_c = [r['cot_correct'] for r in test]
        hyb_c = [r['hyb_correct'] for r in test]
        bb, cc, pv = mcnemar(hyb_c, cot_c)
        grid[tau] = {'acc_hybrid': round(acc(test), 4), 'flips': flips,
                     'good_flips': good, 'bad_flips': bad,
                     'vs_cot_mcnemar_p': round(pv, 5) if pv is not None else None}
    tau_star = max(grid, key=lambda t: grid[t]['acc_hybrid'])

    for r in test:  # final operating point
        use_cot = r['p_cot'] >= tau_star
        r['hy_pred'] = r['k'] if use_cot else r['aero_pred']
        r['hyb_correct'] = r['hy_pred'] == r['gold']

    # --- references --------------------------------------------------------
    refs = {}
    for spec in args.refs:
        name, path = spec.split('=', 1)
        rows = load(path)
        rmap = {r['idx']: pred_int(r) for r in rows}
        preds = [rmap.get(r['idx']) for r in test]
        if any(p is None for p in preds):
            print(f'[warn] {name}: incomplete overlap, skipped')
            continue
        corr = [p == r['gold'] for p, r in zip(preds, test)]
        refs[name] = {'acc': round(sum(corr) / len(corr), 4)}
        bb, cc, pv = mcnemar([r['hyb_correct'] for r in test], corr)
        refs[name].update({'discordant': [bb, cc],
                           'mcnemar_p': round(pv, 5) if pv is not None else None})

    # rule gate (no learning): flip when disagree AND betp_max > cot conf
    cot_conf = [r['x'][0] for r in test]
    rule_correct = []
    for r, cf in zip(test, cot_conf):
        f = fusion.fuse  # noqa (features already contain what we need)
        betp_max = r['x'][3]
        agree = r['x'][1]
        rule_correct.append(r['cot_correct'] or (not agree and betp_max > cf and r['aero_correct']))
    rule_acc = sum(rule_correct) / len(rule_correct)

    oracle = sum(1 for r in test if r['cot_correct'] or r['aero_correct']) / len(test)

    out = {
        'tag': args.tag, 'n_cal': len(cal), 'n_test': len(test),
        'feats': FEATS, 'l2': args.l2,
        'acc_cot': round(sum(r['cot_correct'] for r in test) / len(test), 4),
        'acc_aero_plains': round(sum(r['aero_correct'] for r in test) / len(test), 4),
        'acc_hybrid_tau_star': round(acc(test), 4), 'tau_star': tau_star,
        'acc_rule_gate': round(rule_acc, 4),
        'oracle_upper_bound': round(oracle, 4),
        'tau_grid': grid, 'refs': refs,
    }
    dest = os.path.join(TMP, f'hybrid_{args.tag}.json')
    with open(dest, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    print(f"n(cal/test) = {len(cal)}/{len(test)}   tau* = {tau_star}")
    print(f"CoT {out['acc_cot']:.3f}  AERO+(plainds) {out['acc_aero_plains']:.3f}  "
          f"HYBRID {out['acc_hybrid_tau_star']:.3f}  rule-gate {rule_acc:.3f}  "
          f"oracle {out['oracle_upper_bound']:.3f}")
    g = grid[tau_star]
    print(f"flips: {g['flips']} (good {g['good_flips']} / bad {g['bad_flips']}), "
          f"McNemar vs CoT p={g['vs_cot_mcnemar_p']}")
    for name, r in refs.items():
        print(f"vs {name}: acc {r['acc']:.3f}, McNemar p={r['mcnemar_p']}")
    print('[written]', dest)


if __name__ == '__main__':
    main()
