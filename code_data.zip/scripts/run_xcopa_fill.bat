@echo off
REM XCOPA 补采（仅 zh，与 run_xcopa_fill.sh 等价）
cd /d "%~dp0.."
if not exist tmp\xcopa_zh_test.jsonl python scripts\aeroplus\make_xcopa_items.py

echo == XCOPA zh: baseline + cot-cal ==
for %%S in (selfcons pnps sn_cot g2 zeroshot) do (
  node scripts\run_exp.mjs --system %%S --input tmp\xcopa_zh_test.jsonl --output tmp\results_%%S_xczh.jsonl --conc 4
)
node scripts\run_exp.mjs --system cot --input tmp\xcopa_zh_cal.jsonl --output tmp\results_cot_xczh_cal.jsonl --conc 4

echo done,then: scripts\run_local_v4.bat analyze
