#!/bin/bash
# =============================================================================
# FINSOC 域外检验集执行入口（社会/金融事件因果推理，en 主集 1040 + zh 镜像）
# 用法：
#   bash scripts/run_finsoc.sh verify   # 每系统 2 条冒烟（en+zh）
#   bash scripts/run_finsoc.sh collect  # 全量采集：en 1040 + zh 1040（断点续采）
#   bash scripts/run_finsoc.sh analyze  # 离线分析（零 API 调用）
# 依赖：make_finsoc_dataset.py 已生成 tmp/finsoc_{en,zh}_{cal,test}_v1.jsonl
#       （套件内已冻结；勿手工改动）
# 产物：
#   tmp/aeroplus_analysis_finsoc-en/report.md   en 主报告
#   tmp/aeroplus_analysis_finsoc-zh/report.md   zh 镜像报告
#   tmp/finsoc_stats.json                       en/zh 与 e-CARE 的迁移对比汇总
# =============================================================================
set -e
cd "$(dirname "$0")/.."
MODE="${1:-verify}"
LIMIT=""; [ "$MODE" = "verify" ] && LIMIT="--limit 2"
TAGS="en zh"

collect() {
  for L in $TAGS; do
    # 主系统 AERO+（test + cal，cal 供阈值拟合）
    [ -f tmp/results_aero_finsoc${L}_cal.jsonl ] || \
      node scripts/collect_v3.mjs --system aeroplus \
        --input tmp/finsoc_${L}_cal_v1.jsonl --output tmp/results_aero_finsoc${L}_cal.jsonl --conc 4 $LIMIT
    node scripts/collect_v3.mjs --system aeroplus \
      --input tmp/finsoc_${L}_test_v1.jsonl --output tmp/results_aero_finsoc${L}.jsonl --conc 4 $LIMIT
    # 基线：CoT、CF-CoT、zero-shot
    node scripts/run_exp.mjs --system cot \
      --input tmp/finsoc_${L}_test_v1.jsonl --output tmp/results_cot_finsoc${L}.jsonl --conc 4 $LIMIT
    node scripts/collect_v3.mjs --system cf_cot \
      --input tmp/finsoc_${L}_test_v1.jsonl --output tmp/results_cfcot_finsoc${L}.jsonl --conc 4 $LIMIT
    node scripts/run_exp.mjs --system zeroshot \
      --input tmp/finsoc_${L}_test_v1.jsonl --output tmp/results_zeroshot_finsoc${L}.jsonl --conc 4 $LIMIT
  done
}

analyze() {
  for L in $TAGS; do
    python3 scripts/aeroplus/run_offline.py --dataset finsoc \
      --raw tmp/results_aero_finsoc${L}.jsonl --cal tmp/results_aero_finsoc${L}_cal.jsonl \
      --tag finsoc-${L}
    # 选择性基线（风险-覆盖对比）
    python3 scripts/aeroplus/selective_baselines.py --tag finsoc-${L} \
      --cot-cal tmp/results_cot_finsoc${L}_cal.jsonl --cot-test tmp/results_cot_finsoc${L}.jsonl
    # AERO+ vs CoT 的 McNemar + bootstrap（共享 helper，.bat 同源）
    python3 scripts/aeroplus/finsoc_stats.py ${L} || exit 1
  done
}

case "$MODE" in
  verify)  collect ;;
  collect) collect ;;
  analyze) analyze ;;
  *) echo "用法: run_finsoc.sh verify|collect|analyze"; exit 1 ;;
esac
echo "[finsoc] $MODE 完成"
