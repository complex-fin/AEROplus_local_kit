#!/bin/bash
# AERO+ v3 supervisor: layered-collector (collect_v3.mjs), dataset-agnostic.
# P0 e-CARE calibration -> P1 e-CARE test -> P2 CF-CoT -> P2.5 baselines top-up
#   -> P3 COPA multi-dataset pilot (cal 30 + test 60, with KG scores merged)
# Waits out API quota windows; resumable by idx.
cd "$(dirname "$0")/.."
LOG=tmp/supervisor_v3.log

need() { n=$(wc -l < "$1" 2>/dev/null || echo 0); [ "$n" -lt "$2" ]; }

echo "$(date +%F' '%H:%M:%S) supervisor_v3 start" >> $LOG
for round in $(seq 1 300); do
  need tmp/results_aeroplus_cal.jsonl 40 && \
    timeout 100 node scripts/collect_v3.mjs --system aeroplus --input tmp/cal_items_v2.jsonl --output tmp/results_aeroplus_cal.jsonl --conc 4 2>/dev/null
  need tmp/results_aeroplus.jsonl 80 && \
    timeout 100 node scripts/collect_v3.mjs --system aeroplus --input tmp/exp_items_full.jsonl --output tmp/results_aeroplus.jsonl --conc 4 2>/dev/null
  need tmp/results_cfcot.jsonl 80 && \
    timeout 100 node scripts/collect_v3.mjs --system cf_cot --input tmp/exp_items_full.jsonl --output tmp/results_cfcot.jsonl --conc 4 2>/dev/null
  # baselines top-up (v1 files, same core schema)
  need tmp/results_aero_nocf.jsonl 60 && \
    timeout 100 node scripts/run_exp.mjs --system aero_nocf --input tmp/exp_items.jsonl --output tmp/results_aero_nocf.jsonl --conc 4 2>/dev/null
  need tmp/results_cot.jsonl 60 && \
    timeout 100 node scripts/run_exp.mjs --system cot --input tmp/exp_items.jsonl --output tmp/results_cot.jsonl --conc 4 2>/dev/null
  need tmp/results_zeroshot.jsonl 60 && \
    timeout 100 node scripts/run_exp.mjs --system zeroshot --input tmp/exp_items.jsonl --output tmp/results_zeroshot.jsonl --conc 4 2>/dev/null
  # P3: COPA pilot (multi-dataset readiness) -- with KG scores merged
  if [ "$(wc -l < tmp/results_aeroplus_cal.jsonl 2>/dev/null || echo 0)" -ge 40 ] \
     && [ "$(wc -l < tmp/results_aeroplus.jsonl 2>/dev/null || echo 0)" -ge 80 ]; then
    [ -f tmp/kg_copa.jsonl ] || python3 scripts/aeroplus/kg_scores.py --input tmp/copa_cal.jsonl --out tmp/kg_copa_cal.jsonl >> $LOG 2>&1
    [ -f tmp/kg_copa_test.jsonl ] || python3 scripts/aeroplus/kg_scores.py --input tmp/copa_test.jsonl --out tmp/kg_copa_test.jsonl >> $LOG 2>&1
    need tmp/results_copa_cal.jsonl 30 && \
      timeout 100 node scripts/collect_v3.mjs --system aeroplus --input tmp/copa_cal.jsonl --output tmp/results_copa_cal.jsonl --kg tmp/kg_copa_cal.jsonl --conc 4 2>/dev/null
    need tmp/results_copa.jsonl 60 && \
      timeout 100 node scripts/collect_v3.mjs --system aeroplus --input tmp/copa_test.jsonl --output tmp/results_copa.jsonl --kg tmp/kg_copa_test.jsonl --conc 4 2>/dev/null
  fi
  n_cal=$(wc -l < tmp/results_aeroplus_cal.jsonl 2>/dev/null || echo 0)
  n_tst=$(wc -l < tmp/results_aeroplus.jsonl 2>/dev/null || echo 0)
  n_copa=$(wc -l < tmp/results_copa.jsonl 2>/dev/null || echo 0)
  echo "$(date +%H:%M:%S) round $round cal=$n_cal/40 test=$n_tst/80 copa=$n_copa/60" >> $LOG
  if [ "$n_copa" -ge 60 ]; then
    echo "$(date +%H:%M:%S) ALL COLLECTION COMPLETE" >> $LOG
    break
  fi
  sleep 20
done
python3 scripts/aeroplus/run_offline.py >> tmp/supervisor_v3.log 2>&1
echo "$(date +%H:%M:%S) supervisor_v3 exit" >> $LOG
