#!/bin/bash
# =============================================================================
# FINSOC v2 补采入口·小规模版（r2：test 零采集）
#
# 更新（2026-10-17）：test 全集 sc3 采集（6240 调用）已取消——离线分析证明
# FinSoC 上 conf-only 触发已足够（检测 AUC en 0.896 / zh 0.860），v2 的全部
# test 数字可由已有数据零成本算出。本脚本只剩两项小采集：
#
# 任务①（必采，200 次）  cal 集 CoT（en/zh 各 100）→ 有原则地选定歧义默认方向
# 任务②（可选，600 次）  cal 集 k=3 一致性（en/zh 各 100×3）→ 冻结规则全流程
#                        在 cal 上的域内复演 + 票触发机制检查
#
# 用法：
#   bash scripts/run_finsoc_v2fill.sh verify        # 每任务 2 条冒烟（~15 次调用）
#   bash scripts/run_finsoc_v2fill.sh collect       # 任务①+② 全量（800 次，断点续采）
#   bash scripts/run_finsoc_v2fill.sh collect-min   # 仅任务①（200 次）
#   bash scripts/run_finsoc_v2fill.sh analyze       # 离线终评（零 API）
#
# 依赖：tmp/finsoc_{en,zh}_cal_v1.jsonl（冻结 item 文件）
#       tmp/results_aero_finsoc{en,zh}[_cal].jsonl、tmp/results_cot_finsoc{en,zh}.jsonl（已有）
# 产物：tmp/results_cot_finsoc{en,zh}_cal.jsonl        ← 任务①
#       tmp/results_selfcons3_finsoc{en,zh}_cal.jsonl  ← 任务②
#       tmp/finsoc_v2_finsoc-{en,zh}/report.md         ← analyze 产物
# =============================================================================
set -e
cd "$(dirname "$0")/.."
MODE="${1:-verify}"
LIMIT=""; [ "$MODE" = "verify" ] && LIMIT="--limit 2"
TAGS="en zh"

collect_cal_cot() {   # 任务①
  for L in $TAGS; do
    node scripts/run_exp.mjs --system cot \
      --input tmp/finsoc_${L}_cal_v1.jsonl \
      --output tmp/results_cot_finsoc${L}_cal.jsonl ${LIMIT}
  done
}

collect_cal_sc3() {   # 任务②（可选）
  for L in $TAGS; do
    node scripts/collect_consistency.mjs \
      --input tmp/finsoc_${L}_cal_v1.jsonl \
      --output tmp/results_selfcons3_finsoc${L}_cal.jsonl \
      --k 3 --conc 4 ${LIMIT}
  done
}

analyze() {
  for L in $TAGS; do
    python3 scripts/aeroplus/finsoc_v2_arbitrate.py --lang ${L} || exit 1
  done
}

case "$MODE" in
  verify)      collect_cal_cot; collect_cal_sc3 ;;
  collect)     collect_cal_cot; collect_cal_sc3 ;;
  collect-min) collect_cal_cot ;;
  analyze)     analyze ;;
  *) echo "用法: run_finsoc_v2fill.sh verify|collect|collect-min|analyze"; exit 1 ;;
esac
echo "[finsoc-v2fill] $MODE 完成"
