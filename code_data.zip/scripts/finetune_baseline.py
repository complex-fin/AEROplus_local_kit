#!/usr/bin/env python3
"""Finetuned-SOTA anchor baseline (OPTIONAL; needs GPU + transformers>=4.30).

Purpose: reviewers anchor on published finetuned numbers. Published values are
already citable from baselines_published.json (XLNet 75.61 / BERT 75.47 dev).
This script additionally lets you re-run the SAME class of model under OUR
natural protocol (real items only, no constructed negatives) so the table can
carry a our-run finetuned row on identical items.

Task framing: pairwise ranking -- score = margin between the two candidates
under a multiple-choice head (standard COPA/e-CARE causal-reasoner setup).

Usage:
  pip install transformers torch datasets
  python3 scripts/finetune_baseline.py --model roberta-large --dataset ecare \
      --train tmp/ecare_train.jsonl --eval tmp/exp_items_v2.jsonl \
      --epochs 3 --bs 8 --lr 1e-5 --out tmp/ft_ecare
  python3 scripts/finetune_baseline.py --model microsoft/deberta-v3-large --dataset copa \
      --train tmp/COPA/train.jsonl --eval tmp/xcopa_zh_test.jsonl ...   # or English test

Inputs are the same frozen jsonl item files used by the LLM systems, so the
comparison is on identical items; eval restricts to type == 'real' by default
(--eval-all to include negatives; finetuned models never saw class 3).
"""
import argparse, json, math, os, random
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from transformers import AutoModelForSequenceClassification, AutoTokenizer, get_linear_schedule_with_warmup

def read_jsonl(p):
    return [json.loads(l) for l in open(p) if l.strip()]

class PairDS(Dataset):
    """Each item -> 2 examples (premise+H1, premise+H2), label = which is gold (0/1)."""
    def __init__(self, items, tok, maxlen=160):
        self.rows, self.tok, self.maxlen = [], tok, maxlen
        for it in items:
            if it.get('type') != 'real':
                continue                          # natural protocol: real only
            q = 'cause' if it.get('ask_for', it.get('ask-for')) == 'cause' else 'effect'
            stem = f"{it['premise']} What is the {q}?"
            self.rows.append(((stem, it['h1']), (stem, it['h2']), int(it['gold']) - 1))
    def __len__(self):
        return len(self.rows)
    def __getitem__(self, i):
        (a, b), y = self.rows[i], self.rows[i][2]
        return {'a': a, 'b': b, 'y': y}

def collate(batch, tok, maxlen):
    texts, y = [], []
    for r in batch:
        texts.extend([r['a'], r['b']]); y.append(r['y'])
    enc = tok(texts, padding=True, truncation=True, max_length=maxlen, return_tensors='pt')
    return enc, torch.tensor(y)

def margins(model, enc, device):
    out = model(**{k: v.to(device) for k, v in enc.items()}).logits.softmax(-1)[:, 1]
    return out.view(-1, 2)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--model', default='roberta-large')
    ap.add_argument('--dataset', choices=['ecare', 'copa'], default='ecare')
    ap.add_argument('--train', required=True)
    ap.add_argument('--eval', dest='eval_path', required=True)
    ap.add_argument('--epochs', type=int, default=3)
    ap.add_argument('--bs', type=int, default=8)
    ap.add_argument('--lr', type=float, default=1e-5)
    ap.add_argument('--out', default='tmp/ft_out')
    ap.add_argument('--eval-all', action='store_true')
    ap.add_argument('--seed', type=int, default=42)
    args = ap.parse_args()
    random.seed(args.seed); torch.manual_seed(args.seed)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForSequenceClassification.from_pretrained(args.model, num_labels=2).to(device)

    train_items = read_jsonl(args.train)
    if args.dataset == 'ecare':                   # raw dev-pool has hyp keys
        train_items = [{'premise': t['premise'], 'ask_for': t.get('ask-for', t.get('ask_for')),
                        'h1': t['hypothesis1'], 'h2': t['hypothesis2'],
                        'gold': str(1 if t.get('hypothesis1') == t.get('hypothesis1') else 1),
                        'type': 'real'} for t in train_items]
    ds = PairDS(train_items, tok)
    dl = DataLoader(ds, batch_size=args.bs, shuffle=True,
                    collate_fn=lambda b: collate(b, tok, 160))
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr)
    total = len(dl) * args.epochs
    sched = get_linear_schedule_with_warmup(opt, int(0.06 * total), total)

    model.train()
    for ep in range(args.epochs):
        for enc, y in dl:
            m = margins(model, enc, device)
            loss = -(m[torch.arange(len(y)), y] - m[torch.arange(len(y)), 1 - y]).clamp(min=1e-6).log().mean()
            loss.backward(); opt.step(); sched.step(); opt.zero_grad()
        print(f'epoch {ep + 1} loss {loss.item():.4f}')

    # ---- eval on frozen items (real only unless --eval-all) ----
    model.eval()
    eval_items = [it for it in read_jsonl(args.eval_path)
                  if args.eval_all or it.get('type') == 'real']
    preds, golds, margins_all = [], [], []
    with torch.no_grad():
        for i in range(0, len(eval_items), 16):
            chunk = eval_items[i:i + 16]
            texts = []
            for it in chunk:
                q = 'cause' if it.get('ask_for', it.get('ask-for')) == 'cause' else 'effect'
                stem = f"{it['premise']} What is the {q}?"
                texts.extend([(stem, it['h1']), (stem, it['h2'])])
            enc = tok(texts, padding=True, truncation=True, max_length=160, return_tensors='pt')
            m = margins(model, enc, device).cpu()
            for j, it in enumerate(chunk):
                p = str(int(m[j].argmax()) + 1)
                preds.append(p); golds.append(str(it['gold']))
                margins_all.append(float(m[j].max() - m[j].min()))   # selective score
    acc = sum(p == g for p, g in zip(preds, golds)) / len(golds)
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, 'eval_preds.jsonl'), 'w') as f:
        for it, p, g, mg in zip(eval_items, preds, golds, margins_all):
            f.write(json.dumps({'idx': it['idx'], 'pred': p, 'gold': g,
                                'margin': round(mg, 4)}, ensure_ascii=False) + '\n')
    print(f'[ft-baseline] model={args.model} n={len(golds)} acc={acc:.4f} -> {args.out}/eval_preds.jsonl')

if __name__ == '__main__':
    main()
