#!/usr/bin/env node
/**
 * AERO validation experiment on e-CARE Causal_Reasoning (dev).
 *
 * Systems:
 *   zeroshot  – direct 3-way choice + confidence (1 call)
 *   cot       – step-by-step reasoning then answer + confidence (1 call)
 *   selfcons  – k=5 sampled CoT rollouts, majority vote; stores all samples
 *               for offline semantic/answer-entropy selective baselines (5 calls)
 *   pnps      – Gonzalez & Nori (NeurIPS 2024) style PN/PS direct elicitation:
 *               raw probabilities-of-causation probing WITHOUT our L1/L2/L3
 *               stack (1 call) -- isolates the fusion architecture's value
 *   sn_cot    – Yu et al. (NeurIPS 2025) style sufficiency-necessity CoT:
 *               draft steps -> PS/PN self-check -> add missing / prune
 *               redundant -> final answer (2 calls)
 *   g2        – Chi et al. (NeurIPS 2024) G2-Reasoner, implemented from paper
 *               (no public repo found): general-knowledge elicitation +
 *               goal-oriented prompting (2 calls)
 *   aero      – L1/L2 probabilistic parsing + multiple imputation (M=3),
 *               L4 necessity & sufficiency counterfactual probes,
 *               L3 Dempster-Shafer fusion + L5 margin-based abstention (3 calls)
 *   aero_nocf – ablation: no counterfactual probes, fusion on text evidence only (1 call)
 *
 * Task: premise P, direction d (cause|effect), candidates H1/H2, plus option "3"
 *       = neither candidate has a causal link with P.
 *
 * Resumable: results appended to JSONL, existing idx are skipped.
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';

// ---- three-channel backend (aligned with collect_v3.mjs v3.2.2) ----
// 1. env LLM_BASE_URL + LLM_API_KEY (+ optional LLM_MODEL, LLM_MAX_TOKENS)
// 2. llm_config.json next to this script ({baseUrl, apiKey, model, thinking?})
// 3. z-ai SDK fallback (.z-ai-config)
let FETCH_CFG = null;
let BACKEND = 'unknown';

function envMaxTokens(v) {
  if (v === undefined || v === '') return 8192;
  const n = Number(v);
  return Number.isFinite(n) ? n : 8192;
}

function resolveBackend() {
  if (process.env.LLM_BASE_URL && process.env.LLM_API_KEY) {
    FETCH_CFG = { baseUrl: process.env.LLM_BASE_URL.replace(/\/+$/, ''),
                  apiKey: process.env.LLM_API_KEY, model: process.env.LLM_MODEL || '',
                  maxTokens: envMaxTokens(process.env.LLM_MAX_TOKENS) };
    BACKEND = 'env-fetch';
    return;
  }
  const cfgPath = path.join(path.dirname(new URL(import.meta.url).pathname), 'llm_config.json');
  try {
    const cfg = JSON.parse(fs.readFileSync('llm_config.json', 'utf-8'));
    if (cfg.baseUrl && cfg.apiKey) {
      FETCH_CFG = { baseUrl: String(cfg.baseUrl).replace(/\/+$/, ''),
                    apiKey: String(cfg.apiKey), model: String(cfg.model || ''),
                    maxTokens: envMaxTokens(cfg.maxTokens),
                    headers: cfg.headers || {},
                    thinking: cfg.thinking || null };
      BACKEND = 'file-fetch';
      return;
    }
  } catch { /* not present */ }
  BACKEND = 'zai-sdk';
}
resolveBackend();

const args = Object.fromEntries(process.argv.slice(2).reduce((a, v, i, arr) => {
  if (v.startsWith('--')) a.push([v.slice(2), arr[i + 1]]);
  return a;
}, []));

const SYSTEM = args.system || 'zeroshot';
const INPUT = args.input || 'tmp/exp_items.jsonl';
const OUTPUT = args.output || `tmp/results_${SYSTEM}.jsonl`;
const CONCURRENCY = parseInt(args.conc || '3', 10);
const LIMIT = args.limit ? parseInt(args.limit, 10) : null;

const items = fs.readFileSync(INPUT, 'utf-8').trim().split('\n').map(JSON.parse);
const done = new Set(fs.existsSync(OUTPUT)
  ? fs.readFileSync(OUTPUT, 'utf-8').trim().split('\n').filter(Boolean).map(l => { try { return JSON.parse(l).idx; } catch { return null; } })
  : []);
const todo = items.filter(it => !done.has(it.idx)).slice(0, LIMIT || undefined);
console.log(`[${SYSTEM}] run_exp v1.1 | total=${items.length} done=${done.size} todo=${todo.length}`);
console.log(`[${SYSTEM}] backend=${BACKEND}` + (FETCH_CFG ? ` model=${FETCH_CFG.model || '(unset)'}` : ''));

let zai = null;
let callCount = 0;

const BACKOFFS = [2000, 5000, 10000];

async function llmFetch(messages, temp) {
  const body = { model: FETCH_CFG.model, messages, temperature: temp };
  if (FETCH_CFG.maxTokens) body.max_tokens = FETCH_CFG.maxTokens;
  if (FETCH_CFG.thinking) body.thinking = FETCH_CFG.thinking;
  if (!body.model) throw new Error('LLM_MODEL required for fetch backend (env or llm_config.json)');
  const res = await fetch(`${FETCH_CFG.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${FETCH_CFG.apiKey}`,
               ...(FETCH_CFG.headers || {}) },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => '');
    throw new Error(`HTTP ${res.status} ${t.slice(0, 120)}`);
  }
  const j = await res.json();
  const m = j.choices?.[0]?.message;
  if (m?.content && m.content.trim()) return m.content.trim();
  if (m?.reasoning_content) return String(m.reasoning_content).trim();
  console.error(`  [empty-content] no message.content. Response head: ${JSON.stringify(j).slice(0, 200)}`);
  throw new Error('empty response');
}

async function llm(messages, { temp = 0, retries = 3 } = {}) {
  for (let a = 1; a <= retries; a++) {
    try {
      callCount++;
      if (FETCH_CFG) return await llmFetch(messages, temp);
      const completion = await zai.chat.completions.create({
        messages,
        thinking: { type: 'disabled' },
        temperature: temp,
      });
      const content = completion.choices?.[0]?.message?.content;
      if (!content || !content.trim()) throw new Error('empty response');
      return content.trim();
    } catch (e) {
      const msg = String(e.message || e);
      const retriable = /429|500|502|503|504|timeout|empty/i.test(msg);
      if (!retriable || a === retries) throw e;
      await new Promise(r => setTimeout(r, BACKOFFS[Math.min(a - 1, BACKOFFS.length - 1)] + Math.random() * 2000));
    }
  }
}

function parseJSON(text) {
  let t = text.trim();
  t = t.replace(/```json/g, '').replace(/```/g, '');
  const s = t.indexOf('{'), e = t.lastIndexOf('}');
  if (s >= 0 && e > s) t = t.slice(s, e + 1);
  return JSON.parse(t);
}

async function llmJSON(messages, opts = {}) {
  const txt = await llm(messages, opts);
  try { return parseJSON(txt); } catch {
    // one repair attempt
    const txt2 = await llm([...messages,
      { role: 'user', content: 'Your previous output was not valid JSON. Return ONLY the valid JSON object, no other text.' }],
      { temp: 0 });
    try { return parseJSON(txt2); } catch { return null; }
  }
}

const num = (v, lo = 0, hi = 1) => {
  const x = typeof v === 'number' ? v : parseFloat(v);
  if (Number.isNaN(x)) return null;
  return Math.min(hi, Math.max(lo, x));
};

// ---------------- task formatting ----------------
const DIRTXT = { cause: 'possible CAUSES of the premise event', effect: 'possible EFFECTS of the premise event' };
const fmt = it => `Premise: ${it.premise}\nWe are looking for ${DIRTXT[it.ask_for]}.\nCandidate 1: ${it.h1}\nCandidate 2: ${it.h2}`;

// ---------------- baselines ----------------
async function runBaseline(it, cot) {
  const instr = cot
    ? 'Think step by step about whether each candidate is a genuine causal counterpart of the premise event, then decide.'
    : 'Answer directly.';
  const sys = 'You are an expert in event-level causal reasoning. Answer with a single JSON object only.';
  const res = await llmJSON([
    { role: 'system', content: sys },
    { role: 'user', content: `${fmt(it)}\n\nOptions: "1" = Candidate 1 is the ${it.ask_for}, "2" = Candidate 2 is the ${it.ask_for}, "3" = NEITHER candidate has a genuine causal link with the premise.\n${instr}\nReturn JSON: {"answer": "1"|"2"|"3", "confidence": <0-1>}` },
  ]);
  if (!res) return { pred: null, conf: 0.5, abstain: false, error: 'parse' };
  let pred = String(res.answer);
  if (!['1', '2', '3'].includes(pred)) pred = null;
  const conf = num(res.confidence) ?? 0.5;
  return { pred, conf, abstain: false, raw: res };
}

// ---- self-consistency (k sampled CoT rollouts; majority vote; stores all
// samples so semantic/answer entropy can be computed offline). Reviewer-
// requested strong prompting baseline (Wang et al. 2023 style).
async function runSelfCons(it, k = 5) {
  const sys = 'You are an expert in event-level causal reasoning. Answer with a single JSON object only.';
  const user = `${fmt(it)}\n\nOptions: "1" = Candidate 1 is the ${it.ask_for}, "2" = Candidate 2 is the ${it.ask_for}, "3" = NEITHER candidate has a genuine causal link with the premise.\nThink step by step, then decide.\nReturn JSON: {"answer": "1"|"2"|"3", "confidence": <0-1>}`;
  const samples = [];
  for (let i = 0; i < k; i++) {
    const res = await llmJSON([
      { role: 'system', content: sys },
      { role: 'user', content: user },
    ], { temp: 0.8 });
    let a = res ? String(res.answer) : null;
    if (!['1', '2', '3'].includes(a)) a = null;
    samples.push({ answer: a, conf: res ? (num(res.confidence) ?? 0.5) : null });
  }
  const counts = {};
  for (const s of samples) if (s.answer) counts[s.answer] = (counts[s.answer] || 0) + 1;
  const pred = Object.keys(counts).length
    ? Object.entries(counts).sort((x, y) => y[1] - x[1])[0][0]
    : null;
  const votes = Object.values(counts).reduce((a, b) => a + b, 0) || 1;
  const conf = pred ? counts[pred] / votes : 0.34;   // vote share = calibrated-ish confidence
  return { pred, conf, abstain: false, samples, votes: counts };
}

// ---- PN/PS direct elicitation (Gonzalez & Nori, NeurIPS 2024 style).
// Isolates our L1/L2/L3 stack from raw probability-of-causation probing:
// one call, ask PN & PS per candidate directly, decide by combined score.
async function runPnps(it) {
  const sys = 'You are an expert in causal analysis. Answer with a single JSON object only.';
  const user = `${fmt(it)}

For EACH candidate, estimate the probabilities of causation (Gonzalez-Nori framework):
- PS (probability of sufficiency): if we make ONLY this candidate happen (and nothing else changes), the probability that the ${it.ask_for === 'cause' ? 'premise event' : 'asked-for event'} follows.
- PN (probability of necessity): the probability that without this candidate, the ${it.ask_for === 'cause' ? 'premise event' : 'asked-for event'} would NOT happen.

Both are counterfactual probabilities in [0,1]. Candidate "3" (neither) is chosen when BOTH candidates have low PS and PN.

Return JSON: {"h1": {"ps": 0.x, "pn": 0.x}, "h2": {"ps": 0.x, "pn": 0.x}, "reason": "one sentence"}`;
  const res = await llmJSON([
    { role: 'system', content: sys },
    { role: 'user', content: user },
  ]);
  if (!res || !res.h1 || !res.h2) return { pred: null, conf: 0.5, abstain: false, error: 'parse' };
  const s1 = Math.max(num(res.h1.ps) ?? 0, num(res.h1.pn) ?? 0);
  const s2 = Math.max(num(res.h2.ps) ?? 0, num(res.h2.pn) ?? 0);
  let pred, conf;
  if (s1 < 0.35 && s2 < 0.35) { pred = '3'; conf = 1 - Math.max(s1, s2); }
  else if (s1 >= s2)          { pred = '1'; conf = s1; }
  else                        { pred = '2'; conf = s2; }
  return { pred, conf, abstain: false,
           scores: { h1: { ps: num(res.h1.ps), pn: num(res.h1.pn) },
                     h2: { ps: num(res.h2.ps), pn: num(res.h2.pn) } }, raw: res };
}

// ---- Sufficiency-Necessity CoT (Yu et al., NeurIPS 2025 style proxy).
// Generate steps -> self-assess each step's PS/PN -> add missing / prune
// redundant -> final answer. Two calls (draft, then revised).
async function runSnCot(it) {
  const sys = 'You are an expert in causal reasoning. Answer with a single JSON object only.';
  const draft = await llmJSON([
    { role: 'system', content: sys },
    { role: 'user', content: `${fmt(it)}\n\nOptions: "1" = Candidate 1 is the ${it.ask_for}, "2" = Candidate 2 is the ${it.ask_for}, "3" = NEITHER has a genuine causal link.\nWrite your chain of reasoning as a list of steps.\nReturn JSON: {"steps": ["...", "...], "answer": "1"|"2"|"3", "confidence": <0-1>}` },
  ]);
  const steps = (draft && Array.isArray(draft.steps)) ? draft.steps : [];
  const revise = await llmJSON([
    { role: 'system', content: sys },
    { role: 'user', content: `${fmt(it)}\n\nOptions: "1" = Candidate 1 is the ${it.ask_for}, "2" = Candidate 2 is the ${it.ask_for}, "3" = NEITHER has a genuine causal link.\n\nDraft reasoning steps:\n${steps.map((s, i) => `${i + 1}. ${s}`).join('\n')}\n\nNow apply causal sufficiency & necessity analysis (Yu et al. 2025):\n- SUFFICIENCY check: do the steps comprehensively substantiate the conclusion? ADD any missing indispensable step.\n- NECESSITY check: which steps are truly necessary? PRUNE redundant ones.\nThen give your final answer.\nReturn JSON: {"added": ["..."], "pruned": [0,1,...], "final_steps": ["..."], "answer": "1"|"2"|"3", "confidence": <0-1>}` },
  ]);
  let pred = revise ? String(revise.answer ?? draft?.answer) : (draft ? String(draft.answer) : null);
  if (!['1', '2', '3'].includes(pred)) pred = null;
  const conf = (revise && num(revise.confidence) != null) ? num(revise.confidence)
             : ((draft && num(draft.confidence)) ?? 0.5);
  return { pred, conf, abstain: false, draft_answer: draft ? String(draft.answer) : null,
           n_steps_draft: steps.length,
           n_steps_final: (revise && Array.isArray(revise.final_steps)) ? revise.final_steps.length : null,
           raw: { draft, revise } };
}

// ---- G2-Reasoner (Chi et al., NeurIPS 2024, "Unveiling Causal Reasoning in
// LLMs: Reality or Mirage?"). Implemented from the paper (no public repo
// located at time of writing). Two components, faithfully:
//   (1) general-knowledge assistance: elicit relevant general/world knowledge
//       for the premise & candidates before reasoning;
//   (2) goal-oriented prompting: explicitly state the goal of the causal
//       question, then reason toward it. Two calls.
async function runG2(it) {
  const sysK = 'You are a helpful assistant with broad world knowledge. Answer with a single JSON object only.';
  const know = await llmJSON([
    { role: 'system', content: sysK },
    { role: 'user', content: `${fmt(it)}\n\nWhat general world knowledge (about the events, their typical causes/effects, and the domain) is relevant to judging the causal connection here? List 3-5 concise knowledge points.\nReturn JSON: {"knowledge": ["...", "..."]}` },
  ]);
  const kpts = (know && Array.isArray(know.knowledge)) ? know.knowledge : [];
  const sysG = 'You are an expert in causal reasoning. First identify the GOAL of the question, then reason toward it. Answer with a single JSON object only.';
  const res = await llmJSON([
    { role: 'system', content: sysG },
    { role: 'user', content: `${fmt(it)}\n\nOptions: "1" = Candidate 1 is the ${it.ask_for}, "2" = Candidate 2 is the ${it.ask_for}, "3" = NEITHER has a genuine causal link with the premise.\n\nRelevant general knowledge:\n${kpts.map((k, i) => `- ${k}`).join('\n') || '(none)'}\n\nGOAL: determine which candidate is the genuine ${it.ask_for} of the premise event (or neither), by pursuing this goal step by step.\nReturn JSON: {"goal": "one sentence", "reasoning": "...", "answer": "1"|"2"|"3", "confidence": <0-1>}` },
  ]);
  let pred = res ? String(res.answer) : null;
  if (!['1', '2', '3'].includes(pred)) pred = null;
  return { pred, conf: (res && num(res.confidence)) ?? 0.5, abstain: false,
           goal: res ? res.goal : null, knowledge: kpts, raw: res };
}

// ---------------- AERO ----------------
async function runAero(it, { useCF = true, fusion = 'ds' } = {}) {
  // ---- Call A: L1 probabilistic parsing + L2 multiple imputation (M=3) ----
  const callA = await llmJSON([
    { role: 'system', content: 'You are an expert in event understanding and causal analysis in the open world, where event elements are often incomplete and event expressions ambiguous. You answer with a single JSON object only.' },
    { role: 'user', content: `${fmt(it)}\n\nStep 1: briefly note what key elements (agent/time/place/manner) are missing or ambiguous in each candidate and the premise.\nStep 2: for EACH candidate, invent 3 plausible completions of the missing elements (different readings), list possible UNOBSERVED events (hidden common causes, mediators) that could explain the premise-candidate co-occurrence without a direct causal link, and rate:\n- "plausibility": how likely this candidate is a genuine ${it.ask_for} of the premise (0-1)\n- "confounder": how likely the observed link is instead explained by a hidden event (0-1)\n- "ambiguity": how ambiguous the event interpretation is (0-1)\n\nReturn JSON:\n{"h1":{"missing":"...","completions":["...","...","..."],"hidden":"...","plausibility":0.x,"confounder":0.x,"ambiguity":0.x},"h2":{...}}` },
  ], { temp: 0.7 });
  if (!callA) return { pred: null, conf: 0.5, abstain: false, error: 'parseA' };

  const ctx = h => `Missing/ambiguous: ${h.missing || 'n/a'}; readings: ${(h.completions || []).join(' | ')}; possible hidden events: ${h.hidden || 'n/a'}`;
  let N = {}, S = {};
  if (useCF) {
    // ---- Call B: merged counterfactual probes (necessity + sufficiency) ----
    const necQ = it.ask_for === 'cause'
      ? `NECESSITY: if candidate X had NOT occurred, would the premise event still occur anyway? (still=1 means yes, so X is NOT necessary)`
      : `NECESSITY: if the premise event had NOT occurred, would candidate X still occur anyway? (still=1 means yes, so X does not depend on the premise)`;
    const sufQ = it.ask_for === 'cause'
      ? `SUFFICIENCY: in a comparable situation where ONLY candidate X occurs, how likely does the premise event follow?`
      : `SUFFICIENCY: given the premise event occurs, how likely does candidate X follow?`;
    const callB = await llmJSON([
      { role: 'system', content: 'You are an expert in counterfactual and interventional causal analysis. Answer with a single JSON object only.' },
      { role: 'user', content: `${fmt(it)}\nContext from open-world analysis:\nCandidate 1: ${ctx(callA.h1 || {})}\nCandidate 2: ${ctx(callA.h2 || {})}\n\nFor EACH candidate, judge both probes:\n${necQ.replace(/X/g, 'the candidate')}\n${sufQ.replace(/X/g, 'the candidate')}\n\nReturn JSON: {"h1":{"still":0.x,"likely":0.x,"reason":"one sentence"},"h2":{"still":0.x,"likely":0.x,"reason":"one sentence"}}` },
    ]);
    if (callB) {
      N.h1 = 1 - (num(callB.h1?.still) ?? 0.5);
      N.h2 = 1 - (num(callB.h2?.still) ?? 0.5);
      S.h1 = num(callB.h1?.likely) ?? 0.5;
      S.h2 = num(callB.h2?.likely) ?? 0.5;
    }
  }

  // ---- L3 Dempster-Shafer fusion + L5 abstention (in code) ----
  // Each source yields masses over frame {Causal, NotCausal}:
  //   text source:   b=plausibility, u=ambiguity, d=residual
  //   necessity:     b=N, d=1-N, u=0
  //   sufficiency:   b=S, d=1-S, u=0
  // Standard Dempster combination; conflict K recorded per candidate.
  function dsCombine(masses) {
    let T = masses[0].b, F = masses[0].d, U = masses[0].u, K = 0;
    for (let i = 1; i < masses.length; i++) {
      const { b, d, u } = masses[i];
      const k = T * d + F * b;
      if (k >= 0.999) { K = Math.max(K, 0.999); return { T: 0.34, F: 0.33, U: 0.33, K: 0.999 }; }
      const Tn = (T * b + T * u + U * b) / (1 - k);
      const Fn = (F * d + F * u + U * d) / (1 - k);
      const Un = (U * u) / (1 - k);
      T = Tn; F = Fn; U = Un; K = Math.max(K, k);
    }
    return { T, F, U, K };
  }
  const sc = {};
  for (const k of ['h1', 'h2']) {
    const h = callA[k] || {};
    const plaus = num(h.plausibility) ?? 0.5;
    const amb = Math.min(num(h.ambiguity) ?? 0.2, 0.5);
    if (fusion === 'avg') {
      // Discriminating ablation (review round-3 §6): same probes, NO Dempster
      // fusion -- simple average of the three source scores, mirroring the
      // "consistency + confidence fusion" used by CF-CoT / MuTQA style work.
      // This isolates the contribution of the DS fusion operator itself.
      const srcs = [plaus];
      if (useCF) { srcs.push(N[k] ?? 0.5); srcs.push(S[k] ?? 0.5); }
      const b = srcs.reduce((a, x) => a + x, 0) / srcs.length;
      sc[k] = { B: b, F: 1 - b, U: 0, K: 0, conf: num(h.confounder) ?? 0, amb };
    } else {
      const masses = [{ b: plaus, d: Math.max(0, 1 - plaus - amb), u: amb }];
      if (useCF) {
        masses.push({ b: N[k] ?? 0.5, d: 1 - (N[k] ?? 0.5), u: 0 });
        masses.push({ b: S[k] ?? 0.5, d: 1 - (S[k] ?? 0.5), u: 0 });
      }
      const r = dsCombine(masses);
      sc[k] = { B: r.T, F: r.F, U: r.U, K: r.K, conf: num(h.confounder) ?? 0, amb };
    }
  }
  let s1 = sc.h1.B, s2 = sc.h2.B;
  let s3 = Math.max(1 - Math.max(s1, s2), (sc.h1.conf + sc.h2.conf) / 2);
  const sum = s1 + s2 + s3 || 1;
  const p = { 1: s1 / sum, 2: s2 / sum, 3: s3 / sum };
  const ranked = Object.entries(p).sort((a, b) => b[1] - a[1]);
  const margin = ranked[0][1] - ranked[1][1];
  const conflict = Math.max(sc.h1.K, sc.h2.K);
  return {
    pred: ranked[0][0], conf: ranked[0][1], abstain: false, margin, conflict,
    p, scores: sc, callA, N, S, useCF,
  };
}

// ---------------- worker pool ----------------
const tau = (() => {
  if (SYSTEM !== 'aero' && SYSTEM !== 'aero_nods') return null;
  try { return JSON.parse(fs.readFileSync('tmp/tau.json', 'utf-8')).tau; } catch { return 0; }
})();
console.log(`[${SYSTEM}] abstention tau = ${tau}`);

async function processItem(it) {
  // Fault-tolerant: only successful items are written; each item gets up to
  // 2 in-run attempts (with a cool-down) so temporary API failures can be
  // recovered by re-running the same command (output is resumable).
  let out = null;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const r = { idx: it.idx, type: it.type, gold: it.gold, system: SYSTEM };
      if (SYSTEM === 'zeroshot') Object.assign(r, await runBaseline(it, false));
      else if (SYSTEM === 'cot') Object.assign(r, await runBaseline(it, true));
      else if (SYSTEM === 'selfcons') Object.assign(r, await runSelfCons(it, 5));
      else if (SYSTEM === 'pnps') Object.assign(r, await runPnps(it));
      else if (SYSTEM === 'sn_cot') Object.assign(r, await runSnCot(it));
      else if (SYSTEM === 'g2') Object.assign(r, await runG2(it));
      else if (SYSTEM === 'aero') {
        const a = await runAero(it, { useCF: true });
        Object.assign(r, a);
        if (tau > 0 && a.margin !== undefined && a.margin < tau) r.abstain = true;
      } else if (SYSTEM === 'aero_nocf') {
        Object.assign(r, await runAero(it, { useCF: false }));
      } else if (SYSTEM === 'aero_nods') {
        // probes + simple-average fusion (no Dempster): isolates the DS operator
        const a = await runAero(it, { useCF: true, fusion: 'avg' });
        Object.assign(r, a);
        if (tau > 0 && a.margin !== undefined && a.margin < tau) r.abstain = true;
      }
      if (!r.pred) throw new Error('no prediction produced');
      out = r;
      break;
    } catch (e) {
      console.log(`[${SYSTEM}] item ${it.idx} attempt ${attempt} failed: ${String(e.message || e).slice(0, 120)}`);
      if (attempt < 2) await new Promise(r2 => setTimeout(r2, 30000));
    }
  }
  if (out) fs.appendFileSync(OUTPUT, JSON.stringify(out) + '\n');
  return out;
}

async function main() {
  if (!FETCH_CFG) zai = await ZAI.create();;
  let i = 0, ok = 0, err = 0;
  async function worker() {
    while (i < todo.length) {
      const it = todo[i++];
      const r = await processItem(it);
      r ? ok++ : err++;
      if ((ok + err) % 10 === 0) console.log(`[${SYSTEM}] progress ${ok + err}/${todo.length} err=${err}`);
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  console.log(`[${SYSTEM}] DONE ok=${ok} err=${err} calls=${callCount}`);
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
