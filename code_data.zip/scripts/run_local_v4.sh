#!/bin/bash
# =============================================================================
# AERO+ v4 本地全量执行入口（e-CARE 扩容 450 + XCOPA 四语种）
# 用法：
#   bash scripts/run_local_v4.sh verify   # 仅验证：每系统只采 2 条，跑通全链路
#   bash scripts/run_local_v4.sh collect  # 全量采集（可反复执行，断点续采）
#   bash scripts/run_local_v4.sh analyze  # 全部采完后：离线分析 + 统计检验
# 前置：
#   1) cp scripts/llm_config.example.json scripts/llm_config.json 并填入你的 API 配置
#   2) pip install -r scripts/requirements.txt
#   3) node >= 18（采集器为 .mjs）
# 输入（已冻结，勿改动）：
#   tmp/exp_items_v2.jsonl              e-CARE 扩容测试集 450 题（种子 20261011）
#   tmp/results_aeroplus_cal_v3.jsonl   e-CARE 校准 60 条原始记录（已采好，直接复用）
#   tmp/xcopa_{zh,vi,th,sw}_test.jsonl  XCOPA 测试条目（若缺失，见步骤 0 生成）
#   tmp/xcopa_{L}_cal.jsonl             XCOPA 校准条目（30/语种）
# 输出：
#   tmp/results_{aero,cfcot,cot,zeroshot}_exp.jsonl      e-CARE 扩容原始记录
#   tmp/results_aero_xc{L}.jsonl  等                      XCOPA 原始记录
#   tmp/aeroplus_analysis_ecare-v4/report.md             e-CARE 主分析报告
#   tmp/aeroplus_analysis_xc{L}/report.md                XCOPA 各语种报告
#   tmp/stats_v4.json                                   McNemar/bootstrap/功效结果
# =============================================================================
set -e
cd "$(dirname "$0")/.."
MODE="${1:-verify}"

# ---- 步骤 0：XCOPA 条目生成（幂等；需要 pyarrow）--------------------------
gen_xcopa() {
  if [ ! -f tmp/xcopa_zh_test.jsonl ]; then
    echo "[0] 生成 XCOPA 条目（zh/vi/th/sw）..."
    python3 scripts/aeroplus/make_xcopa_items.py
  fi
}

# ---- 步骤 1：采集（每系统逐个跑，断点续采）--------------------------------
collect() {
  LIMIT="$1"   # verify 传 2，collect 传空（=全量）
  gen_xcopa
  for SYS in aeroplus cf_cot; do
    # 输出名对齐 stats_v4/supervisor：aeroplus->aero, cf_cot->cfcot
    OUT="results_${SYS/aeroplus/aero}_exp.jsonl"; OUT="${OUT/cf_cot/cfcot}"
    echo "[1] e-CARE 450 | $SYS -> tmp/$OUT"
    node scripts/collect_v3.mjs --system $SYS \
      --input tmp/exp_items_v2.jsonl --output tmp/$OUT --conc 4 $LIMIT
  done
  for SYS in cot selfcons zeroshot pnps sn_cot g2; do
    echo "[1] e-CARE 450 | $SYS"
    node scripts/run_exp.mjs --system $SYS \
      --input tmp/exp_items_v2.jsonl --output tmp/results_${SYS}_exp.jsonl \
      --conc 4 $LIMIT
  done
  # 基线校准：cot/selfcons/pnps/sn_cot 在 cal v3 条目上的预测（拟合分位数/保形阈值用，60 条一次性）
  for SYS in cot selfcons pnps sn_cot g2; do
    echo "[1] e-CARE cal-60 | $SYS（基线阈值拟合）"
    node scripts/run_exp.mjs --system $SYS \
      --input tmp/cal_items_v3.jsonl --output tmp/results_${SYS}_cal_v3.jsonl --conc 4
  done
  for L in zh vi th sw; do
    echo "[1] XCOPA $L | aeroplus + cot + cf_cot"
    node scripts/collect_v3.mjs --system aeroplus \
      --input tmp/xcopa_${L}_test.jsonl --output tmp/results_aero_xc${L}.jsonl --conc 4 $LIMIT
    node scripts/run_exp.mjs --system cot \
      --input tmp/xcopa_${L}_test.jsonl --output tmp/results_cot_xc${L}.jsonl --conc 4 $LIMIT
    node scripts/collect_v3.mjs --system cf_cot \
      --input tmp/xcopa_${L}_test.jsonl --output tmp/results_cfcot_xc${L}.jsonl --conc 4 $LIMIT
    # 校准条目也要采（每语种 30 条，一次性）
    node scripts/collect_v3.mjs --system aeroplus \
      --input tmp/xcopa_${L}_cal.jsonl --output tmp/results_aero_xc${L}_cal.jsonl --conc 4
  done
}

# ---- 步骤 2：离线分析 ------------------------------------------------------
analyze() {
  echo "[2] e-CARE v4 主分析（校准=cal_v3，冻结）..."
  python3 scripts/aeroplus/run_offline.py --dataset ecare \
    --raw tmp/results_aero_exp.jsonl --cal tmp/results_aeroplus_cal_v3.jsonl --tag ecare-v4
  for L in zh vi th sw; do
    echo "[2] XCOPA $L 分析（校准=本语种 cal）..."
    python3 scripts/aeroplus/run_offline.py --dataset copa \
      --raw tmp/results_aero_xc${L}.jsonl --cal tmp/results_aero_xc${L}_cal.jsonl --tag xc${L}
  done
  echo "[2] 统计检验（McNemar / bootstrap / 功效）..."
  python3 scripts/aeroplus/stats_v4.py
  echo "[2] 选择性预测基线（conf分位数 / softmax保形 / 答案熵弃权 / selfcons / pnps / sn_cot）..."
  python3 scripts/aeroplus/selective_baselines.py --tag ecare-v4 \
    --cot-cal tmp/results_cot_cal_v3.jsonl --cot-test tmp/results_cot_exp.jsonl \
    --sc-cal  tmp/results_selfcons_cal_v3.jsonl --sc-test tmp/results_selfcons_exp.jsonl \
    --pnps-cal tmp/results_pnps_cal_v3.jsonl --pnps-test tmp/results_pnps_exp.jsonl \
    --sncot-cal tmp/results_sn_cot_cal_v3.jsonl --sncot-test tmp/results_sn_cot_exp.jsonl \
    --g2-cal tmp/results_g2_cal_v3.jsonl --g2-test tmp/results_g2_exp.jsonl
}

case "$MODE" in
  verify)  collect "--limit 2"; analyze ;;
  collect) collect ""        ;;
  analyze) analyze           ;;
  *) echo "用法: bash scripts/run_local_v4.sh {verify|collect|analyze}"; exit 1 ;;
esac
