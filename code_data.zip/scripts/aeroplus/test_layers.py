#!/usr/bin/env python3
"""Unit tests for the refactored layers / datasets / graph modules."""
import sys, os, json
sys.path.insert(0, os.path.dirname(__file__))
import layers.l1 as L1, layers.l2 as L2
import fusion, config as C

# ---------- L1 normalization ----------
raw = {'h1': {'missing': 'who/where', 'readings': [{'completion': 'r1', 'plausibility': 0.8},
                                                   {'completion': 'r2', 'plausibility': 0.6},
                                                   {'completion': 'r3', 'plausibility': 0.7}],
              'hidden': 'weather', 'confounder': 0.3, 'plausibility': 0.7, 'ambiguity': 0.4},
       'h2': {}}
A = L1.normalize(raw)
assert len(A['h1'].readings) == 3 and A['h1'].confounder == 0.3
assert L1.is_reading_sampled(A['h1']) and not L1.is_reading_sampled(A['h2'])
# malformed values never crash
A2 = L1.normalize({'h1': {'readings': [{'plausibility': 'bad'}], 'plausibility': None}})
assert A2['h1'].readings == [] and A2['h1'].plausibility is None
print('L1 ok')

# ---------- L2: marginal belief + corrected variance ----------
bel, u, rs = L2.belief_and_u(A['h1'], alpha_s=1.0)
assert abs(bel - 0.7) < 1e-12 and rs
# readings [0.8,0.6,0.7]: W = 0.01, u = min(1*sqrt(0.01*(1+1/3)), 0.8) = 0.11547
assert abs(u - (0.01 * (1 + 1 / 3)) ** 0.5) < 1e-12, u
# cap respected
bel_c, u_c, _ = L2.belief_and_u(L1.CandidateParse(
    readings=[L1.Reading('', 0.0), L1.Reading('', 1.0)]), alpha_s=5.0)
assert u_c == 0.8
# legacy fallback
leg = L1.CandidateParse(plausibility=0.6, ambiguity=0.9)
bel_l, u_l, rs_l = L2.belief_and_u(leg)
assert bel_l == 0.6 and u_l == 0.5 and not rs_l   # ambiguity capped at 0.5
print('L2 ok')

# ---------- fusion delegates to layers + optional KG ----------
rec = {'callA': raw, 'N': {'h1': 0.9, 'h2': 0.2}, 'S': {'h1': 0.8, 'h2': 0.3}}
f0 = fusion.fuse(rec, variant='full')
assert abs(sum(f0['betp'].values()) - 1) < 1e-9
rec_kg = dict(rec, kg={'h1': 0.7, 'h2': 0.1})
f1 = fusion.fuse(rec_kg, variant='full', gammas={'kg': 1.0, 'text': 0.9, 'N': 0.9, 'S': 0.9, 'f': 0.9})
assert abs(sum(f1['betp'].values()) - 1) < 1e-9 and f1['betp'][1] != f0['betp'][1]
# KG absent in 'plainds' only when field missing
fp = fusion.fuse(rec, variant='plainds')
assert abs(sum(fp['betp'].values()) - 1) < 1e-9
print('fusion+KG ok  (no-kg BetP1=%.3f  with-kg BetP1=%.3f)' % (f0['betp'][1], f1['betp'][1]))

# gamma estimation sees the kg source when present
g1, rho1 = fusion.estimate_gammas([rec_kg, dict(rec, kg={'h1': 0.2, 'h2': 0.6})], beta=0.5)
assert 'kg' in g1 and all(0 < v <= 1 for v in g1.values())
g0, _ = fusion.estimate_gammas([rec], beta=0.5)
assert 'kg' not in g0
print('gammas ok', {k: round(v, 3) for k, v in g1.items()})

# ---------- graph: event frames + lexical KG ----------
from graph import event_frames, kg_source
fr = event_frames.extract('The doctor did not diagnose the prolapse.')
assert fr['polarity'] == 'neg' and 'doctor' in fr['words']
it = {'premise': 'The man broke the window.', 'ask_for': 'cause',
      'h1': 'He broke the lock with force.', 'h2': 'The sun rose.', 'gold': '1', 'idx': 't', 'type': 'real'}
frames = event_frames.item_frames(it)
s = kg_source.score_item(it)
assert 0 <= s['h1'] <= 1 and 0 <= s['h2'] <= 1
assert s['h1'] > s['h2']    # 'broke/lock' shares a word with premise
try:
    kg_source.ASERAdapter().causal_support({}, {})
    raise AssertionError('should raise')
except NotImplementedError:
    pass
print('graph ok  kg(h1)=%.3f > kg(h2)=%.3f' % (s['h1'], s['h2']))

# ---------- datasets: registry + ecare wrap + copa build ----------
from datasets import REGISTRY, get
assert set(REGISTRY) >= {'ecare', 'copa'}
cal, test = get('ecare').build()
assert len(cal) == 40 and len(test) == 80
assert {x['gold'] for x in test} == {'1', '2', '3'}
ccal, ctest = get('copa').build()
assert len(ctest) == 60 and len(ccal) == 30
assert {x['gold'] for x in ctest} <= {'1', '2'}
assert any(x['gold'] == '3' for x in ccal)     # constructed negatives in cal only
assert {x['ask_for'] for x in ctest} == {'cause', 'effect'}
print('datasets ok  ecare cal/test=%d/%d  copa cal/test=%d/%d' % (len(cal), len(test), len(ccal), len(ctest)))

# ---------- sota loader ----------
import sota
tbl = sota.render([{'dataset': 'e-CARE', 'system': 'AERO+ full', 'value': 0.90}])
assert 'pending citation' in tbl and 'our-run' in tbl
print('sota ok')

print('\nALL LAYER TESTS PASSED')
