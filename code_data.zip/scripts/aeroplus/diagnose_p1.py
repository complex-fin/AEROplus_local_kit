"""P1 post-confirmation diagnostics (analysis of the ALREADY-LOCKED preset).

Purpose: answer the three questions confirm_p1_ecare-p1.json raises, WITHOUT
touching the locked preset and WITHOUT any new model selection:

  Q1  gain shrinkage: exploratory P2 (cal-60 fit) showed +5.3pt / 44 flips on
      the same test-450; the confirmed P1 gate (cal-178 fit) shows +2.2pt /
      17 flips (good 12 / bad 2 / neutral 3). Where did the good flips go?
        -> deferral-rate & deferred-subset analysis + a threshold sweep
           (DIAGNOSTIC ONLY; clearly labeled; the locked preset is NOT
           re-tuned and the sweep never feeds back into any config).
  Q2  cal->test shift: cal CoT acc .8146 vs test .7600. Is the cot_conf
      DISTRIBUTION itself shifted (gate mis-calibration), or just accuracy?
        -> quantiles + two-sample KS + cot/probe acc by conf bin.
      This feeds the pre-E5 design decision: frozen e-CARE coefficients vs
      per-domain refit on FinSoC cal (run_finsoc.sh already collects cal and
      fits every baseline score per-domain, so refit = same treatment).
  Q2b drop audit: 178/180 cal items entered the fit; identify the 2 missing
      (missing cot record / missing aero record / parse failure) to rule out
      systematic collection loss.

Usage:
  python scripts/aeroplus/diagnose_p1.py --tag ecare-p1 \
    --preset tmp/preset_p1_ecare-p1.json --items tmp/cal_items_p1.jsonl \
    --aero-cal tmp/results_aeroplus_cal_p1.jsonl --aero-test tmp/results_aero_exp.jsonl \
    --cot-cal  tmp/results_cot_cal_p1.jsonl      --cot-test  tmp/results_cot_exp.jsonl
Writes tmp/diag_p1_<tag>.json (overwrite allowed: pure diagnostics, no lock).
"""
import argparse
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ablation_diag import stratum                      # noqa: E402
from hybrid_verifier import feats_one, gold_int, load  # noqa: E402

SWEEP = [0.50, 0.60, 0.65, 0.6963, 0.75, 0.80, 0.85, 0.90]


def clamp_conf(rec):
    conf = float(rec.get('conf') or 0.5)
    return min(1.0, max(0.0, conf))


def build(cot_rows, amap, alpha_s):
    """Per-item rows: conf / CoT ans k / probe ans / gold / stratum."""
    out, skipped = [], []
    for c in cot_rows:
        a = amap.get(c['idx'])
        if a is None:
            skipped.append({'idx': c['idx'], 'stage': 'missing_aero_record'})
            continue
        fk = feats_one(a, c, alpha_s)
        if fk is None:
            skipped.append({'idx': c['idx'], 'stage': 'parse_fail'})
            continue
        _, aero_pred, k = fk
        out.append({'idx': c['idx'], 'conf': clamp_conf(c), 'k': k,
                    'aero_pred': aero_pred, 'gold': gold_int(a),
                    'cot_correct': k == gold_int(a),
                    'st': stratum(c['idx'])})
    return out, skipped


def audit_drops(items, cot_rows, amap):
    cot_idx = {c['idx'] for c in cot_rows}
    drops = [{'idx': it['idx'], 'stage': 'missing_cot_record'}
             for it in items if it['idx'] not in cot_idx]
    return drops


def acc_of(rows, key):
    return round(sum(1 for r in rows if key(r)) / len(rows), 4) if rows else None


def gate_stats(rows, thr):
    """Final-answer stats when trusting CoT iff conf >= thr."""
    defer = [r for r in rows if r['conf'] < thr]
    keep = [r for r in rows if r['conf'] >= thr]

    def final_ok(r):
        return (r['k'] == r['gold']) if r['conf'] >= thr \
            else (r['aero_pred'] == r['gold'])

    return {
        'thr': round(thr, 4), 'n': len(rows),
        'n_defer': len(defer), 'defer_rate': round(len(defer) / len(rows), 4),
        'cot_acc_deferred': acc_of(defer, lambda r: r['cot_correct']),
        'probe_acc_deferred': acc_of(defer, lambda r: r['aero_pred'] == r['gold']),
        'cot_acc_kept': acc_of(keep, lambda r: r['cot_correct']),
        'final_acc': acc_of(rows, final_ok),
        'cot_acc_all': acc_of(rows, lambda r: r['cot_correct']),
    }


def flip_detail(rows, thr):
    """Per-item flip ledger vs CoT (good/bad/neutral) at the locked gate."""
    out = []
    for r in rows:
        final = r['k'] if r['conf'] >= thr else r['aero_pred']
        if final == r['k']:
            continue
        kind = ('good' if final == r['gold']
                else 'bad' if r['cot_correct'] else 'neutral')
        out.append({'idx': r['idx'], 'st': r['st'], 'conf': round(r['conf'], 3),
                    'cot': r['k'], 'probe': r['aero_pred'], 'gold': r['gold'],
                    'final': final, 'kind': kind})
    return out


def quantiles(xs):
    q = np.percentile(np.asarray(xs), [0, 10, 25, 50, 75, 90, 100])
    return [round(float(v), 4) for v in q]


def ks2(a, b):
    a, b = np.sort(a), np.sort(b)
    allv = np.concatenate([a, b])
    c1 = np.searchsorted(a, allv, side='right') / len(a)
    c2 = np.searchsorted(b, allv, side='right') / len(b)
    return round(float(np.max(np.abs(c1 - c2))), 4)


def conf_bins(rows, thr):
    bins = [(0.0, 0.5), (0.5, thr), (thr, 0.8), (0.8, 0.9), (0.9, 1.01)]
    out = []
    for lo, hi in bins:
        sel = [r for r in rows if lo <= r['conf'] < hi]
        out.append({'bin': f'[{lo:.2f},{hi:.2f})', 'n': len(sel),
                    'cot_acc': acc_of(sel, lambda r: r['cot_correct']),
                    'probe_acc': acc_of(sel, lambda r: r['aero_pred'] == r['gold'])})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', default='ecare-p1')
    ap.add_argument('--preset', required=True)
    ap.add_argument('--items', required=True)
    ap.add_argument('--aero-cal', required=True)
    ap.add_argument('--aero-test', required=True)
    ap.add_argument('--cot-cal', required=True)
    ap.add_argument('--cot-test', required=True)
    args = ap.parse_args()

    TMP = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), 'tmp')

    p = json.load(open(args.preset, encoding='utf-8'))
    assert p['feats'] == ['cot_conf'], 'diagnostic assumes conf_only preset'
    b = p['b'][0] if isinstance(p['b'], list) else p['b']
    logit_tau = math.log(p['tau'] / (1.0 - p['tau']))
    # sigmoid(((conf - mu)/sd) w + b) >= tau  <=>  conf >= thr  (1 feature, w>0)
    thr = p['mu'][0] + (logit_tau - b) * p['sd'][0] / p['w'][0]

    items = load(args.items)
    cal_cot, test_cot = load(args.cot_cal), load(args.cot_test)
    cal_a = {r['idx']: r for r in load(args.aero_cal)}
    test_a = {r['idx']: r for r in load(args.aero_test)}

    cal, cal_skip = build(cal_cot, cal_a, p['alpha_s'])
    test, test_skip = build(test_cot, test_a, p['alpha_s'])
    drops = audit_drops(items, cal_cot, cal_a) + cal_skip + test_skip

    out = {
        'tag': args.tag, 'locked_thr': round(thr, 4), 'tau': p['tau'],
        'n_cal': len(cal), 'n_test': len(test), 'drops': drops,
        # Q1 -- gate behavior at the locked threshold
        'gate_cal_insample': gate_stats(cal, thr),
        'gate_test': gate_stats(test, thr),
        'flips_test': flip_detail(test, thr),
        'defer_by_stratum_test': {
            st: {'n': len(g), 'n_defer': sum(1 for r in g if r['conf'] < thr)}
            for st, g in sorted(_group(test).items())},
        # Q2 -- conf distribution shift cal vs test
        'conf_quantiles_cal': quantiles([r['conf'] for r in cal]),
        'conf_quantiles_test': quantiles([r['conf'] for r in test]),
        'conf_ks_cal_vs_test': ks2([r['conf'] for r in cal],
                                   [r['conf'] for r in test]),
        'conf_bins_test': conf_bins(test, thr),
        # Q1b -- threshold sweep, DIAGNOSTIC ONLY (never a config input)
        'threshold_sweep_test': {
            'note': 'diagnostic only; locked preset (0.6963) is NOT re-tuned',
            'rows': [gate_stats(test, t) for t in SWEEP]},
    }

    dest = os.path.join(TMP, f'diag_p1_{args.tag}.json')
    with open(dest, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    g = out['gate_test']
    print(f"diag [{args.tag}]  locked thr={thr:.4f}  "
          f"cal {len(cal)} / test {len(test)}  drops {len(drops)}")
    for d in drops:
        print('  drop:', d['idx'], d['stage'])
    print(f"defer rate: cal {out['gate_cal_insample']['defer_rate']:.3f} | "
          f"test {g['defer_rate']:.3f}")
    print(f"deferred subset (test): cot {g['cot_acc_deferred']} vs probe "
          f"{g['probe_acc_deferred']}  (probe must beat cot here for the gate to pay)")
    print(f"conf KS(cal,test)={out['conf_ks_cal_vs_test']}  "
          f"med cal {out['conf_quantiles_cal'][3]} / test {out['conf_quantiles_test'][3]}")
    print('threshold sweep (DIAGNOSTIC ONLY):')
    for r in out['threshold_sweep_test']['rows']:
        mark = '  <- locked' if abs(r['thr'] - thr) < 1e-3 else ''
        print(f"  thr {r['thr']:.4f}  defer {r['n_defer']:3d}  "
              f"final {r['final_acc']:.4f} (cot {r['cot_acc_all']:.4f}){mark}")
    print('[written]', dest)


def _group(rows):
    g = {}
    for r in rows:
        g.setdefault(r['st'], []).append(r)
    return g


if __name__ == '__main__':
    main()
