"""L3.5 calibration: c(x,k) = sigma(a * logit(BetP_k) + b * log(1-K) [+ b3 * 1{k=0} * log(1-K)] + c0)

Fit on calibration items: one (features -> label 1{gold==k}) row per class k.
The sign of b is learned from data (spec fix: conflict's information sign is
class-dependent and must not be fixed a priori).
"""
import math
import numpy as np

def logit(p, eps=1e-4):
    p = min(max(p, eps), 1 - eps)
    return math.log(p / (1 - p))

def design_row(betp, K, k, b3_enabled):
    z1 = logit(betp[k])
    z2 = math.log(max(1.0 - min(K, 0.999), 1e-4))
    feats = [z1, z2, 1.0]
    if b3_enabled:
        feats.append(z2 if k == 0 else 0.0)
    return feats

def fit(betps_ks, l2pen=1e-3, max_iter=200):
    """betps_ks: list of (betp dict, K, gold class). Returns theta (+ history)."""
    X, y = [], []
    for betp, K, gold in betps_ks:
        for k in (1, 2, 0):
            X.append(design_row(betp, K, k, True))
            y.append(1.0 if int(gold) == k else 0.0)
    X = np.array(X); y = np.array(y)
    n, d = X.shape
    theta = np.zeros(d)
    for _ in range(max_iter):
        z = X @ theta
        p = 1 / (1 + np.exp(-z))
        W = np.clip(p * (1 - p), 1e-6, None)
        grad = X.T @ (p - y) + l2pen * theta
        H = (X * W[:, None]).T @ X + l2pen * np.eye(d)
        try:
            step = np.linalg.solve(H, grad)
        except np.linalg.LinAlgError:
            break
        theta -= step
        if np.max(np.abs(step)) < 1e-8:
            break
    return theta

def nll(X, y, theta, l2pen=1e-3):
    z = X @ theta
    p = 1 / (1 + np.exp(-z))
    p = np.clip(p, 1e-12, 1 - 1e-12)
    return -float(np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))) + 0.5 * l2pen * float(theta @ theta)

def h7_lr_test(betps_ks, l2pen=1e-3):
    """Nested LR test for the class-3 conflict term b3 (H7).
    model0: (z1, z2, c0); model1: + b3. Returns (chi2, df=1, p approx)."""
    X0, X1, y = [], [], []
    for betp, K, gold in betps_ks:
        for k in (1, 2, 0):
            r = design_row(betp, K, k, True)
            X1.append(r); X0.append(r[:3]); y.append(1.0 if int(gold) == k else 0.0)
    X0, X1, y = np.array(X0), np.array(X1), np.array(y)
    def fit_fixed(X):
        theta = np.zeros(X.shape[1])
        for _ in range(200):
            p = 1 / (1 + np.exp(-(X @ theta)))
            W = np.clip(p * (1 - p), 1e-6, None)
            grad = X.T @ (p - y) + l2pen * theta
            H = (X * W[:, None]).T @ X + l2pen * np.eye(X.shape[1])
            try:
                step = np.linalg.solve(H, grad)
            except np.linalg.LinAlgError:
                break
            theta -= step
            if np.max(np.abs(step)) < 1e-8:
                break
        return theta
    th0, th1 = fit_fixed(X0), fit_fixed(X1)
    l0 = nll(X0, y, th0, 0.0) * len(y)
    l1 = nll(X1, y, th1, 0.0) * len(y)
    chi2 = max(0.0, 2 * (l0 - l1))
    # chi2_1 p-value via survival function approx
    from math import erfc, sqrt
    p = erfc(sqrt(chi2 / 2))
    return chi2, 1, p, th0, th1

def predict(theta, betp, K, k, b3_used=True):
    feats = design_row(betp, K, k, True)
    if not b3_used:
        feats = feats[:3]
    if len(feats) != len(theta):
        feats = feats[:len(theta)]
    z = sum(t * f for t, f in zip(theta, feats))
    return 1 / (1 + math.exp(-z))
