#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""FINSOC paired statistics: AERO+ vs CoT per language + summary.

Extracted from run_finsoc.sh so both bash and Windows .bat drivers share it.
Usage: python scripts/aeroplus/finsoc_stats.py [en zh]
Outputs: tmp/finsoc_stats_{en,zh}.json + tmp/finsoc_stats.json
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
from stats_tests import mcnemar_exact, boot_ci_delta  # noqa: E402


def load(p):
    fp = ROOT / p
    if not fp.exists():
        raise SystemExit(f'[missing] {p} -- run the collect step first')
    return [json.loads(l) for l in open(fp, encoding='utf-8')]


def one_lang(lang):
    # AERO+ side: fused per-item predictions written by run_offline.py
    # (tmp/preds_finsoc-<lang>.jsonl). The raw collection files only contain
    # probes -- reading them for 'pred' yields acc=0 (bug fixed 2026-10-17).
    # Semantics (single-source, same as stats_v4): abstain on a negative is a
    # correct rejection; abstain on a real item is a miss; else pred == gold.
    # CoT side: raw run_exp records, correct = pred == gold (no abstention).
    a = load(f'tmp/preds_finsoc-{lang}.jsonl')
    b = load(f'tmp/results_cot_finsoc{lang}.jsonl')
    acorr = {r['idx']: bool(r['correct']) for r in a}
    bcorr = {r['idx']: int(str(r['pred'])) == int(r['gold'])
             for r in b if str(r.get('pred')) in ('1', '2', '3')}
    common = sorted(set(acorr) & set(bcorr))
    if len(common) < 10:
        raise SystemExit(f'[finsoc-{lang}] only {len(common)} paired items -- '
                         f'run scripts\\run_finsoc.bat analyze first (preds file missing?)')
    va = [1 if acorr[i] else 0 for i in common]
    vb = [1 if bcorr[i] else 0 for i in common]
    b_ = sum(1 for x, y in zip(va, vb) if x and not y)   # aero right, cot wrong
    c_ = sum(1 for x, y in zip(va, vb) if y and not x)   # cot right, aero wrong
    p_ = mcnemar_exact(b_, c_)
    pt, lo, hi = boot_ci_delta(va, vb)
    out = {'n': len(common),
           'acc_aero': round(sum(va) / len(common), 4),
           'acc_cot': round(sum(vb) / len(common), 4),
           'discordant': [b_, c_], 'mcnemar_p': p_,
           'acc_diff_ci': [round(pt, 4), round(lo, 4), round(hi, 4)]}
    (ROOT / f'tmp/finsoc_stats_{lang}.json').write_text(json.dumps(out, indent=1))
    print(f'finsoc-{lang}:', out)
    return out


def main():
    langs = sys.argv[1:] or ['en', 'zh']
    per = {lang: one_lang(lang) for lang in langs}
    summary = {'note': 'domain transfer from e-CARE to constructed social/finance benchmark'}
    summary.update(per)
    (ROOT / 'tmp/finsoc_stats.json').write_text(json.dumps(summary, indent=1))
    print('summary -> tmp/finsoc_stats.json')


if __name__ == '__main__':
    main()
