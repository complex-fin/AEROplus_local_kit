#!/usr/bin/env python3
"""Optional re-download of datasets (code ships with data already included).

- COPA (SuperGLUE): verified URL, downloads to tmp/COPA/
- e-CARE Causal_Reasoning dev: already shipped as data/ecare_dev.jsonl
  (official source: the e-CARE GitHub repo / EMNLP 2022 paper; if you need a
  fresh copy, download Causal_Reasoning/dev.jsonl from the official release
  and place it at data/ecare_dev.jsonl -- we do not hardcode an unverified URL)
"""
import os, sys, urllib.request, zipfile, subprocess
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config as C

COPA_URL = 'https://dl.fbaipublicfiles.com/glue/superglue/data/v2/COPA.zip'

def fetch_copa():
    z = C.TMP / 'copa.zip'
    if not (C.TMP / 'COPA' / 'train.jsonl').exists():
        print(f'[fetch] downloading {COPA_URL}')
        urllib.request.urlretrieve(COPA_URL, z)
        with zipfile.ZipFile(z) as zf:
            zf.extractall(C.TMP)
    print('[fetch] COPA ok ->', C.TMP / 'COPA')

def rebuild_all():
    subprocess.run([sys.executable, os.path.join(os.path.dirname(__file__), 'data_prep.py')], check=True)
    from datasets import get
    import json
    for name, (cal, test) in {
        'copa': get('copa').build(),
    }.items():
        for kind, items in (('cal', cal), ('test', test)):
            p = C.TMP / (f'{name}_{kind}.jsonl')
            with open(p, 'w') as f:
                for it in items:
                    f.write(json.dumps(it, ensure_ascii=False) + '\n')
            print('[rebuild]', p, len(items))

if __name__ == '__main__':
    fetch_copa()
    rebuild_all()
