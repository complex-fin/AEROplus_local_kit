#!/usr/bin/env python3
"""Build XCOPA multilingual items (zh, vi, th, sw) for AERO+ v4 collection.

Protocol (per language, mirrors the e-CARE/COPA v2 recipes):
 - test : full 100 items of the XCOPA test split  -> idx xc{L}-t{i}
 - cal  : 20 real (validation split, seeded) + 10 constructed neg-easy
          (donors = other validation items of the SAME language) -> idx
          xc{L}-c{i} / xc{L}-e{i}   (gold '3' negatives, needed to fit C0)
All item records share the frozen collector schema:
 {idx, type, premise, ask_for, h1, h2, gold}
Run:  python3 scripts/aeroplus/make_xcopa_items.py
"""
import json, random, sys, os
import pandas as pd
from pathlib import Path

HERE = Path(__file__).resolve().parent
TMP = HERE.parent.parent / 'tmp'
LANGS = ['zh', 'vi', 'th', 'sw']
SEED = 20261010          # frozen; log in paper as XCOPA split seed

def conv(df):
    """XCOPA raw -> item dicts (ask_for in {cause,effect}, gold '1'/'2')."""
    out = []
    for _, r in df.iterrows():
        out.append({'premise': r['premise'], 'ask_for': str(r['question']),
                    'h1': r['choice1'], 'h2': r['choice2'], 'gold': str(int(r['label']) + 1)})
    return out

def main():
    stats = {}
    for L in LANGS:
        test = conv(pd.read_parquet(TMP / 'XCOPA' / f'{L}-test.parquet'))
        val = conv(pd.read_parquet(TMP / 'XCOPA' / f'{L}-validation.parquet'))
        rng = random.Random(SEED + hash(L) % 10007)

        test_items = [{'idx': f'xc{L}-t{i}', 'type': 'real', **t}
                      for i, t in enumerate(test)]
        order = list(range(len(val)))
        rng.shuffle(order)
        cal_real = [{'idx': f'xc{L}-c{i}', 'type': 'real', 'premise': val[j]['premise'],
                     'ask_for': val[j]['ask_for'], 'h1': val[j]['h1'], 'h2': val[j]['h2'],
                     'gold': val[j]['gold']} for i, j in enumerate(order[:20])]
        donors = [val[j] for j in order[20:]]          # remaining val items
        cal_neg = []
        for i in range(10):
            while True:
                d0, d1, d2 = rng.sample(donors, 3)
                if len({d0['premise'], d1['premise'], d2['premise']}) == 3:
                    break
            cal_neg.append({'idx': f'xc{L}-e{i}', 'type': 'neg-easy',
                            'premise': d0['premise'], 'ask_for': d0['ask_for'],
                            'h1': d1['h1'], 'h2': d2['h1'], 'gold': '3'})
        # neg recipe (same as COPA adapter): premise of one donor, both
        # candidates are hyp-1 texts of two OTHER donors => no causal edge.

        with open(TMP / f'xcopa_{L}_test.jsonl', 'w',encoding="UTF8") as f:
            for it in test_items:
                f.write(json.dumps(it, ensure_ascii=False) + '\n')
        with open(TMP / f'xcopa_{L}_cal.jsonl', 'w',encoding="UTF8") as f:
            for it in cal_real + cal_neg:
                f.write(json.dumps(it, ensure_ascii=False) + '\n')

        from collections import Counter
        stats[L] = (len(test_items), Counter(x['type'] for x in cal_real + cal_neg))
        # sanity: no premise overlap between test and cal within a language
        assert not ({t['premise'] for t in test_items} &
                    {c['premise'] for c in cal_real + cal_neg}), f'{L}: premise leak'
    for L, (n, c) in stats.items():
        print(f'{L}: test {n} | cal {dict(c)}')
    ex = json.loads(open(TMP / 'xcopa_zh_test.jsonl').readline())
    print('\nzh test example:', json.dumps(ex, ensure_ascii=False)[:220])

if __name__ == '__main__':
    main()
