"""Event frames: the bridge between AERO+ L1 and external event knowledge graphs.

An EventFrame is the canonical unit exchanged with any KG (ASER, ATOMIC,
EventStoryLine, proprietary graphs):

  frame = {
    'text'   : surface string,
    'words'  : content words (linking keys for KG nodes),
    'verb'   : main verb if detectable (else ''),
    'args'   : {subject, object} if detectable (else ''),
    'polarity': negated or not,
  }

extract() is deliberately DETERMINISTIC and dependency-free (regex/heuristic).
It is a *baseline* frame extractor: swapping in a real semantic parser
(SRL/ODP) only requires returning the same dict shape -- no other layer
changes. Honesty note: no claim of linguistic accuracy beyond content words.
"""
import re

_NEG = re.compile(r"\b(not|no|never|n't|without|cannot)\b", re.I)
_STOP = set('''a an the of in on at to for with by from into over under is are was were be been being
and or but so if then than as this that these those it its his her their our your my we they he she i you
not no do does did done have has had having will would can could shall should may might must very just'''.split())

def content_words(s):
    return [w for w in re.findall(r"[a-z']+", (s or '').lower()) if w not in _STOP and len(w) > 1]

def extract(text):
    words = content_words(text)
    verbs = [w for w in words if w.endswith(('ate', 'ify', 'ize', 'ise'))]
    neg = bool(_NEG.search(text or ''))
    return {
        'text': text,
        'words': words,
        'verb': verbs[0] if verbs else '',
        'args': {'subject': words[0] if words else '', 'object': words[-1] if len(words) > 1 else ''},
        'polarity': 'neg' if neg else 'pos',
    }

def item_frames(item):
    """core item -> {'premise': frame, 'h1': frame, 'h2': frame}"""
    return {'premise': extract(item['premise']),
            'h1': extract(item['h1']), 'h2': extract(item['h2'])}
