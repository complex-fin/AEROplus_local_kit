"""Pluggable event-KG evidence source for L3 fusion.

Contract (KGAdapter):
    causal_support(premise_frame, hyp_frame, ask_for) -> float in [0,1]
    P(H has a causal edge with P) as judged by the graph.

Integration with AERO+ (no pipeline surgery):
  1. kg_scores.py materializes scores for a whole item file (offline, any
     adapter implementing the contract);
  2. collect_v3.mjs merges them into raw records as rec['kg'];
  3. fusion.extract_sources turns rec['kg'] into an extra DS source with its
     own gamma; absent field = source simply not present (e-CARE core runs
     unaffected).

Shipped adapters:
  LexicalKG  -- deterministic lexical-overlap prior (STAND-IN, not a KG;
               keeps the interface exercised end-to-end)
  ASERAdapter -- real hookup placeholder (k-NN event retrieval over ASER
               edges; NotImplementedError until data+index are provisioned)
"""
import math
from .event_frames import extract

class LexicalKG:
    """Stand-in scorer: Jaccard overlap of content words, softened toward 0.5.

    Clearly NOT a knowledge graph -- it exists so that the KG->fusion path is
    testable and benchmarked end-to-end before a real graph is attached."""
    name = 'lexical-standin'

    def causal_support(self, premise_frame, hyp_frame, ask_for='cause'):
        a, b = set(premise_frame['words']), set(hyp_frame['words'])
        if not a or not b:
            return 0.5
        j = len(a & b) / len(a | b)
        return 0.5 + 0.5 * math.tanh(3.0 * j)     # smooth, bounded [0.5, 1)

class ASERAdapter:
    """Real event-KG adapter (ASER / ATOMIC / EventStoryLine).

    Implementation sketch once data is provisioned:
      - index ASER hypernym nodes by content-word keys;
      - retrieve k-NN premise node & hypothesis node (PPDB-style edge weights);
      - support = normalized frequency of (premise --cause/effect--> hyp) edge,
        direction chosen by ask_for, back off to hypernym edges;
      - cache per (premise, hyp) pair (deterministic given an index snapshot).
    """
    name = 'aser'

    def __init__(self, endpoint_or_index=None):
        self.endpoint_or_index = endpoint_or_index

    def causal_support(self, premise_frame, hyp_frame, ask_for='cause'):
        raise NotImplementedError('provision ASER index/endpoint first '
                                  '(see class docstring for the retrieval design)')

DEFAULT = LexicalKG()

def score_item(item, adapter=None):
    kg = adapter or DEFAULT
    pf = extract(item['premise'])
    return {'h1': kg.causal_support(pf, extract(item['h1']), item.get('ask_for', 'cause')),
            'h2': kg.causal_support(pf, extract(item['h2']), item.get('ask_for', 'cause'))}
