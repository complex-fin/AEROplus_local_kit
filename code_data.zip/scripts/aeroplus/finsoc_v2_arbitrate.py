#!/usr/bin/env python3
"""FINSOC v2 arbitrate (r2: 小规模版，test 零采集).

背景：test 集 sc3 采集（6240 调用）已取消——离线分析证明 FinSoC 上 conf-only 触发
已足够（AUC 0.896/0.860；conf<0.8 触发率 0.20/0.18，CoT 错误召回 0.67/0.62）。
v2 在 FinSoC test 上的全部数字可由已有数据（探针 + CoT + v1 官方 preds）离线算出。

补采（run_finsoc_v2fill.sh）：
  ① tmp/results_cot_finsoc{L}_cal.jsonl      cal 集 CoT（必采，en/zh 各 100 次）
     → cal 分歧项上"探针 vs CoT"谁对 → 有原则地选定歧义默认方向
  ② tmp/results_selfcons3_finsoc{L}_cal.jsonl cal 集 k=3 一致性（可选，各 300 次）
     → 冻结规则全流程在 cal 上的域内复演 + 票触发机制检查
已 有：results_aero_finsoc{L}[_cal].jsonl、results_cot_finsoc{L}.jsonl、preds_finsoc-{L}.jsonl

评测（零拟合：所有参数 e-CARE dev 冻结）：
  Step1  cal 默认方向选择（二项符号检验，平局按 cal 全集 acc 破平）
  Step2a [若②已采] 冻结规则全流程在 cal 复演（触发+仲裁，n=100/语言）
  Step2b test（n=1040）：v2_sel(conf-only 触发, 冻结 tc=0.8, Step1 默认方向)
         参照 CoT/plainds/v1 官方 + McNemar + bootstrap CI + 触发统计
         敏感性行（非冻结，仅供审稿对照）：默认反向、tc 网格、[若存在 test sc3]全冻结触发

用法：python3 finsoc_v2_arbitrate.py --lang en [--tag finsoc-en]
产物：tmp/finsoc_v2_{tag}/report.md + metrics.json + preds_v2.jsonl（UTF-8）
"""
import argparse, json, math, os, sys
from collections import Counter
from pathlib import Path
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import fusion as F

PM_TAU = 0.3      # frozen on e-CARE dev
TRIG_TCONF = 0.8  # frozen on e-CARE dev
K_VOTES = 3       # frozen on e-CARE dev


def load_jsonl(path):
    if not os.path.exists(path):
        return None
    return [json.loads(l) for l in open(path, encoding='utf-8') if l.strip()]


def gi(g):
    return int(g) if g != '3' else 0


def mcnemar_exact(b, c):
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    p = sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n
    return min(1.0, 2 * p)


def binom_sign(k, n):
    """two-sided sign-test p for k successes in n (k <= n/2 assumed caller sorts)"""
    if n == 0:
        return 1.0
    tail = sum(math.comb(n, i) for i in range(min(k, n - k) + 1)) / 2 ** n
    return min(1.0, 2 * tail)


def boot_ci(deltas, n=10000, seed=7):
    arr = np.asarray(deltas, dtype=float)
    if not len(arr):
        return (float('nan'), float('nan'))
    rng = np.random.default_rng(seed)
    means = arr[rng.integers(0, len(arr), (n, len(arr)))].mean(axis=1)
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--lang', required=True, choices=['en', 'zh'])
    ap.add_argument('--tag', default=None)
    ap.add_argument('--outdir-root', default=None, help='默认 <kit>/tmp')
    A = ap.parse_args()
    tag = A.tag or f'finsoc-{A.lang}'
    L = A.lang

    # 所有路径相对套件根（本文件位于 <kit>/scripts/aeroplus/）
    KIT = Path(__file__).resolve().parents[2]
    T = KIT / (A.outdir_root or 'tmp')
    paths = {
        'aero_test': T / f'results_aero_finsoc{L}.jsonl',
        'aero_cal':  T / f'results_aero_finsoc{L}_cal.jsonl',
        'cot_cal':   T / f'results_cot_finsoc{L}_cal.jsonl',           # 任务①（必采）
        'cot_test':  T / f'results_cot_finsoc{L}.jsonl',
        'sc3_cal':   T / f'results_selfcons3_finsoc{L}_cal.jsonl',     # 任务②（可选）
        'sc3_test':  T / f'results_selfcons3_finsoc{L}.jsonl',         # 兼容：若曾全量采过
        'v1_preds':  T / f'preds_finsoc-{L}.jsonl',
    }
    data, missing = {}, []
    for k, p in paths.items():
        rows = load_jsonl(p)
        if rows is None and k in ('aero_test', 'aero_cal', 'cot_cal', 'cot_test'):
            missing.append(f'{k} ({p})')
        data[k] = {r['idx']: r for r in rows} if rows else {}
    if missing:
        print(f'[finsoc_v2] 缺少必需输入：{", ".join(missing)}')
        print('  先运行：bash scripts/run_finsoc_v2fill.sh collect')
        sys.exit(1)

    out_dir = T / f'finsoc_v2_{tag}'
    os.makedirs(out_dir, exist_ok=True)
    R = []  # report lines

    def w(s=''):
        R.append(s)

    def acc_of(ids, pred, gold):
        if not ids:
            return float('nan')
        return float(np.mean([pred(i) == gold(i) for i in ids]))

    w(f'# FinSoC-{L} v2 仲裁评测·小规模版（tag={tag}）')
    w(f'冻结参数：PM_TAU={PM_TAU}, TRIG_TCONF={TRIG_TCONF}, K_VOTES={K_VOTES}（e-CARE dev 冻结，零重拟合）')
    w()
    w('## 0. 数据齐全性')
    w(f"- aero_test={len(data['aero_test'])}  aero_cal={len(data['aero_cal'])}  "
      f"cot_cal={len(data['cot_cal'])}  cot_test={len(data['cot_test'])}  "
      f"sc3_cal={len(data['sc3_cal']) or '未采(可选)'}  v1_preds={len(data['v1_preds']) or '缺(可选)'}")

    # ---------- 公共函数 ----------
    def fuse_pl(rec):
        return F.fuse(rec, 'plainds')

    def sc3_majority(rec):
        v = rec.get('votes') or {}
        if not v:
            return None
        return max(v, key=v.get)

    def votes_margin(rec, k=K_VOTES):
        smp = [s for s in (rec.get('samples') or [])[:k] if s.get('answer')]
        if not smp:
            return 0.0  # 全无效 → 视作不一致（触发）
        c = Counter(s['answer'] for s in smp)
        return max(c.values()) / len(smp)

    # ---------- Step 1: cal 默认方向选择 ----------
    w()
    w('## 1. Step① 产物：cal 上选定歧义默认方向（零 API，纯离线）')
    cP = {i: fuse_pl(r) for i, r in data['aero_cal'].items()}
    cal_common = [i for i in cP if i in data['cot_cal']]

    def cal_g(i): return gi(data['aero_cal'][i]['gold'])
    def cal_cot(i): return gi(data['cot_cal'][i]['pred'])
    def cal_probe(i): return gi(str(cP[i]['pred']))

    dis_cal = [i for i in cal_common if cal_probe(i) != cal_cot(i)]
    pr = sum(cal_probe(i) == cal_g(i) for i in dis_cal)
    cr = sum(cal_cot(i) == cal_g(i) for i in dis_cal)
    both0 = sum(cal_probe(i) != cal_g(i) and cal_cot(i) != cal_g(i) for i in dis_cal)
    sign_p = binom_sign(min(pr, cr), pr + cr) if pr + cr else 1.0
    acc_probe_cal = acc_of(cal_common, cal_probe, cal_g)
    acc_cot_cal = acc_of(cal_common, cal_cot, cal_g)
    if pr != cr:
        default = 'probe' if pr > cr else 'cot'
    else:
        default = 'probe' if acc_probe_cal >= acc_cot_cal else 'cot'
    w(f'- cal 分歧项 n={len(dis_cal)}：探针对 {pr}，CoT 对 {cr}（二项符号检验 p={sign_p:.3f}；'
      f'双方皆错 {both0}）')
    w(f'- cal 全集：plainds {acc_probe_cal:.3f} vs CoT {acc_cot_cal:.3f}')
    w(f'**选定歧义默认方向 = {default}**')

    # ---------- Step 2a: 冻结规则全流程在 cal 复演（若任务②已采）----------
    sc3c = data['sc3_cal']
    cal_v2_stats = None
    if sc3c:
        w()
        w('## 2. Step② 产物：冻结规则全流程在 cal 复演（机制检查，非调参）')
        cal_ids = [i for i in cal_common if i in sc3c]

        def cal_sc(i): return gi(sc3_majority(sc3c[i])) if sc3_majority(sc3c[i]) else None

        def cal_trig(i):
            return votes_margin(sc3c[i]) < 1.0 or data['cot_cal'][i]['conf'] < TRIG_TCONF

        def cal_arb(i):
            ca, pa = cal_cot(i), cal_probe(i)
            if pa == ca:
                return ca
            sa = cal_sc(i)
            b = cP[i]['betp']
            if sa == pa:
                return pa
            if (b[pa] - b[ca]) > PM_TAU:
                return pa
            return pa if default == 'probe' else ca

        def cal_v2(i):
            return cal_cot(i) if not cal_trig(i) else cal_arb(i)

        n = len(cal_ids)
        trig = [i for i in cal_ids if cal_trig(i)]
        errs = [i for i in cal_ids if cal_cot(i) != cal_g(i)]
        # 票触发 vs conf 触发 的机制对照
        vote_only = [i for i in cal_ids if votes_margin(sc3c[i]) < 1.0]
        conf_only = [i for i in cal_ids if data['cot_cal'][i]['conf'] < TRIG_TCONF]
        cal_v2_stats = {
            'n': n,
            'frozen_rule_acc': acc_of(cal_ids, cal_v2, cal_g),
            'plainds_acc': acc_of(cal_ids, cal_probe, cal_g),
            'cot_acc': acc_of(cal_ids, cal_cot, cal_g),
            'trigger_rate': len(trig) / max(n, 1),
            'cot_err_recall': sum(1 for i in errs if i in trig) / max(len(errs), 1),
            'vote_only_rate': len(vote_only) / max(n, 1),
            'vote_only_recall': sum(1 for i in errs if i in vote_only) / max(len(errs), 1),
            'conf_only_rate': len(conf_only) / max(n, 1),
            'conf_only_recall': sum(1 for i in errs if i in conf_only) / max(len(errs), 1),
        }
        w(f"- 冻结规则全流程 acc = {cal_v2_stats['frozen_rule_acc']:.3f}（参照 cal：plainds "
          f"{cal_v2_stats['plainds_acc']:.3f} / CoT {cal_v2_stats['cot_acc']:.3f}，n={n}）")
        w(f"- 触发率 {cal_v2_stats['trigger_rate']:.2f}，CoT 错误（n={len(errs)}）召回 "
          f"{cal_v2_stats['cot_err_recall']:.2f}")
        w(f"- 机制对照：票不一致单独触发率 {cal_v2_stats['vote_only_rate']:.2f}/召回 "
          f"{cal_v2_stats['vote_only_recall']:.2f}；conf<0.8 单独触发率 "
          f"{cal_v2_stats['conf_only_rate']:.2f}/召回 {cal_v2_stats['conf_only_recall']:.2f}")

    # ---------- Step 2b: test 评测（conf-only 触发，零新增采集）----------
    pT = {i: fuse_pl(r) for i, r in data['aero_test'].items()}
    common = [i for i in pT if i in data['cot_test']]
    tC = data['cot_test']

    def gT(i): return gi(data['aero_test'][i]['gold'])
    def cT(i): return gi(tC[i]['pred'])
    def pT_(i): return gi(str(pT[i]['pred']))
    def confT(i): return tC[i]['conf']
    def trigT(i, tc=TRIG_TCONF): return confT(i) < tc

    def arbT(i, dflt):
        ca, pa = cT(i), pT_(i)
        if pa == ca:
            return ca
        b = pT[i]['betp']
        if (b[pa] - b[ca]) > PM_TAU:
            return pa
        return pa if dflt == 'probe' else ca

    def v2_confonly(i, tc=TRIG_TCONF, dflt=default):
        return cT(i) if not trigT(i, tc) else arbT(i, dflt)

    # 兼容：若历史上采过 test sc3，补充"全冻结触发"行
    sc3t = data['sc3_test']

    def v2_frozen(i):
        if not sc3t or i not in sc3t:
            return None
        vm = votes_margin(sc3t[i])
        if vm >= 1.0 and confT(i) >= TRIG_TCONF:
            return cT(i)
        sa = sc3_majority(sc3t[i])
        sa = gi(sa) if sa else None
        ca, pa = cT(i), pT_(i)
        if pa == ca:
            return ca
        b = pT[i]['betp']
        if sa == pa:
            return pa
        if (b[pa] - b[ca]) > PM_TAU:
            return pa
        return pa if default == 'probe' else ca

    w()
    w(f'## {"3" if sc3c else "2"}. test 终评（n={len(common)}，conf-only 触发 + 冻结仲裁默认={default}，零新增采集）')
    flip = 'cot' if default == 'probe' else 'probe'
    rows = {
        'CoT': acc_of(common, cT, gT),
        'plainds（证据层）': acc_of(common, pT_, gT),
        'v2_selective(conf触发)': acc_of(common, v2_confonly, gT),
        f'敏感：默认反向({flip})':
            acc_of(common, lambda i: v2_confonly(i, dflt=flip), gT),
    }
    if data['v1_preds']:
        def v1T(i):
            p = int(data['v1_preds'][i]['pred'])
            return p if p != 3 else 0
        rows['v1 AERO+ full（官方）'] = acc_of(common, v1T, gT)
    frozen_ids = [i for i in common if v2_frozen(i) is not None] if sc3t else []
    if frozen_ids:
        rows['v2_selective(全冻结触发,子集)'] = acc_of(frozen_ids, v2_frozen, lambda i: gT(i))
    w('| 系统 | acc |')
    w('|---|---|')
    for k, v in rows.items():
        w(f'| {k} | {v:.3f} |')

    # 敏感：tc 网格（非冻结，仅供对照）
    w()
    w('敏感性行（tc 网格，非冻结参数，不用于主张）：')
    for tc in (0.7, 0.85, 0.9):
        a = acc_of(common, lambda i: v2_confonly(i, tc=tc), gT)
        w(f'- tc={tc}: acc={a:.3f}')

    # 配对检验
    w()
    w('### 配对检验（McNemar 精确 + bootstrap 95% CI）')
    for ref_nm, ref_fn in [('CoT', cT), ('plainds', pT_)] + \
            ([('v1_official', v1T)] if data['v1_preds'] else []):
        b = sum(1 for i in common if v2_confonly(i) == gT(i) and ref_fn(i) != gT(i))
        c = sum(1 for i in common if v2_confonly(i) != gT(i) and ref_fn(i) == gT(i))
        deltas = [(v2_confonly(i) == gT(i)) - (ref_fn(i) == gT(i)) for i in common]
        lo, hi = boot_ci(deltas)
        w(f'- v2_confonly vs {ref_nm}: Δ={rows["v2_selective(conf触发)"] - acc_of(common, ref_fn, gT):+.3f} '
          f'[{lo:+.3f},{hi:+.3f}]  b/c={b}/{c}  p={mcnemar_exact(b, c):.4f}')

    # 触发统计
    w()
    w('### 触发与检测统计')
    tr = [i for i in common if trigT(i)]
    errs = [i for i in common if cT(i) != gT(i)]
    w(f'- 触发率 {len(tr)/len(common):.3f}；CoT 错误（n={len(errs)}）召回 '
      f'{sum(1 for i in errs if i in tr)/max(len(errs),1):.3f}；触发精度 '
      f'{sum(1 for i in tr if cT(i) != gT(i))/max(len(tr),1):.3f}')
    w(f'- 未触发子集上 CoT acc = {acc_of([i for i in common if i not in tr], cT, gT):.3f}')
    w(f'- cot~plainds 一致率 {sum(pT_(i) == cT(i) for i in common)/len(common):.3f}；'
      f'分歧项上 plainds 对 = {acc_of([i for i in common if pT_(i) != cT(i)], pT_, gT):.3f}')

    report = '\n'.join(R)
    with open(out_dir / 'report.md', 'w', encoding='utf-8') as f:
        f.write(report)
    metrics = {
        'frozen': {'PM_TAU': PM_TAU, 'TRIG_TCONF': TRIG_TCONF, 'K_VOTES': K_VOTES},
        'default': default,
        'cal_default_selection': {'disagree_n': len(dis_cal), 'probe_right': pr,
                                  'cot_right': cr, 'sign_p': sign_p},
        'cal_frozen_rule_replication': cal_v2_stats,
        'test_n': len(common),
        'systems': {k: a for k, a in rows.items()},
        'trigger': {'rate': len(tr)/len(common),
                    'cot_err_recall': sum(1 for i in errs if i in tr)/max(len(errs), 1),
                    'precision': sum(1 for i in tr if cT(i) != gT(i))/max(len(tr), 1)},
    }
    with open(out_dir / 'metrics.json', 'w', encoding='utf-8') as f:
        json.dump(metrics, f, ensure_ascii=False, indent=1)
    with open(out_dir / 'preds_v2.jsonl', 'w', encoding='utf-8') as f:
        for i in common:
            f.write(json.dumps({'idx': i, 'gold': data['aero_test'][i]['gold'], 'cot': cT(i),
                                'probe': pT_(i), 'conf': confT(i),
                                'v2_sel': v2_confonly(i), 'triggered': bool(trigT(i))},
                               ensure_ascii=False) + '\n')
    print(report)
    print(f'\n[written] {out_dir}/report.md  metrics.json  preds_v2.jsonl')

if __name__ == '__main__':
    main()
