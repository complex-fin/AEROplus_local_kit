"""L4: probe validity (H5) and belief-edge consistency (H6) AUC protocol."""
import math, random

def edge_labels(recs):
    """Candidate-level (score_fn, label) rows: gold candidate of a 'real' item
    is a true edge (1); all other candidates are non-edges (0)."""
    def rows(fn):
        X, y, item_of = [], [], []
        for r in recs:
            g = str(r['gold'])
            for k, hk in ((1, 'h1'), (2, 'h2')):
                X.append(fn(r, k, hk)); y.append(1 if (r['type'] == 'real' and g == str(k)) else 0)
                item_of.append(r['idx'])
        return X, y, item_of
    return rows

def auc(X, y):
    pos = [x for x, t in zip(X, y) if t == 1]
    neg = [x for x, t in zip(X, y) if t == 0]
    if not pos or not neg:
        return None
    order = sorted(range(len(X)), key=lambda i: X[i])
    ranks = [0.0] * len(X); i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and X[order[j + 1]] == X[order[i]]:
            j += 1
        mid = (i + j) / 2 + 1
        for t in range(i, j + 1):
            ranks[order[t]] = mid
        i = j + 1
    rp = sum(ranks[i] for i in range(len(X)) if y[i] == 1)
    return (rp - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))

def exact_perm_pvalue(X, y, exact_cap=100_000, mc_draws=20_000, seed=13):
    """Mann-Whitney permutation p.
    Exact enumeration if C(n+m, n) <= exact_cap, else Monte-Carlo permutation
    (fixed seed). Index-based relabeling preserves value multiplicity."""
    from math import comb
    pos = [x for x, t in zip(X, y) if t == 1]
    neg = [x for x, t in zip(X, y) if t == 0]
    n, m = len(pos), len(neg)
    if n == 0 or m == 0:
        return None
    n_comb = comb(n + m, n)
    obs = auc(X, y)
    if obs is None:
        return None
    pool = pos + neg
    if n_comb <= exact_cap:
        import itertools
        ge = tot = 0
        for comb_ in itertools.combinations(range(n + m), n):
            labels = [1 if i in set(comb_) else 0 for i in range(n + m)]
            a = auc(pool, labels)
            tot += 1
            if a is not None and a >= obs - 1e-12:
                ge += 1
        return ge / tot
    rng = random.Random(seed)
    ge = tot = 0
    for _ in range(mc_draws):
        idx = set(rng.sample(range(n + m), n))
        labels = [1 if i in idx else 0 for i in range(n + m)]
        a = auc(pool, labels)
        tot += 1
        if a is not None and a >= obs - 1e-12:
            ge += 1
    return ge / tot

def cluster_bootstrap_ci(recs, fn, B=5000, seed=7):
    """Item-level clustered bootstrap percentile CI (candidates share context)."""
    def item_scores():
        out = []
        for r in recs:
            g = str(r['gold'])
            out.append([(fn(r, k, hk), 1 if (r['type'] == 'real' and g == str(k)) else 0)
                        for k, hk in ((1, 'h1'), (2, 'h2'))])
        return out
    items = item_scores()
    X = [s for it in items for s, _ in it]; y = [l for it in items for _, l in it]
    a0 = auc(X, y)
    rng = random.Random(seed); aucs = []; tries = 0
    while len(aucs) < B and tries < B * 20:
        tries += 1
        samp = [rng.choice(items) for _ in items]
        Xs = [s for it in samp for s, _ in it]; ys = [l for it in samp for _, l in it]
        a = auc(Xs, ys)
        if a is not None:
            aucs.append(a)
    aucs.sort()
    if not aucs:
        return a0, None, None            # degenerate resamples; report point est. only
    lo = aucs[int(0.025 * len(aucs))]; hi = aucs[int(0.975 * len(aucs))]
    return a0, lo, hi

def paired_bootstrap_diff(recs, fn1, fn2, B=5000, seed=11):
    """Bootstrap CI for AUC(fn1) - AUC(fn2) on the same candidates (H6)."""
    def item_scores(fn):
        out = []
        for r in recs:
            g = str(r['gold'])
            out.append([(fn(r, k, hk), 1 if (r['type'] == 'real' and g == str(k)) else 0)
                        for k, hk in ((1, 'h1'), (2, 'h2'))])
        return out
    i1, i2 = item_scores(fn1), item_scores(fn2)
    rng = random.Random(seed); diffs = []
    for _ in range(B):
        idx = [rng.randrange(len(i1)) for _ in i1]
        X1 = [s for i in idx for s, _ in i1[i]]; y = [l for i in idx for _, l in i1[i]]
        X2 = [s for i in idx for s, _ in i2[i]]
        a1, a2 = auc(X1, y), auc(X2, y)
        if a1 is not None and a2 is not None:
            diffs.append(a1 - a2)
    d0 = auc([s for it in i1 for s, _ in it], [l for it in i1 for _, l in it]) - \
         auc([s for it in i2 for s, _ in it], [l for it in i2 for _, l in it])
    diffs.sort()
    if not diffs:
        return d0, None, None
    return d0, diffs[int(0.025 * len(diffs))], diffs[int(0.975 * len(diffs))]
