"""P1 = E4 confirmation run (pre-registered; MODEL_FORMAL 4.4 lower branch).

Design frozen 2026-10-15, BEFORE any cal-180 data was seen:
  * gate preset = conf_only: logistic on ['cot_conf'] ONLY. No subset
    selection and no tuning here -- the P2 LOO pick is confirmed as-is.
  * fit on the stratified cal-180 (120r/30e/30h), evaluate ONCE on the
    frozen test-450 at the pre-registered tau=0.5.
  * primary endpoint : McNemar vs CoT (significant win expected).
  * secondary        : vs strongest baselines, reported with 95% CI on
    delta-acc (paired normal approx on discordant counts) -- NOT a
    significance claim (delta ~1.8pt < MDD 0.056).
  * writes the locked preset (coefficients + standardization + tau) for
    E5 / FinSoC consumption. Refuses to overwrite an existing result
    unless --force (single-evaluation discipline).

Usage:
  python scripts/aeroplus/confirm_p1.py --tag ecare-p1 --tau 0.5 \
    --aero-cal tmp/results_aeroplus_cal_p1.jsonl --aero-test tmp/results_aero_exp.jsonl \
    --cot-cal  tmp/results_cot_cal_p1.jsonl      --cot-test tmp/results_cot_exp.jsonl \
    [--refs selfcons=tmp/results_selfcons_exp.jsonl pnps=tmp/results_pnps_exp.jsonl]
Writes tmp/confirm_p1_<tag>.json and tmp/preset_p1_<tag>.json
"""
import argparse
import datetime
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from hybrid_verifier import (FEATS, feats_one, fit_logistic, load,         # noqa: E402
                             gold_int, mcnemar, pred_int)
from ablation_diag import loo_probs, stratum                              # noqa: E402

PRESET_FEATS = ['cot_conf']          # frozen: P2 LOO pick, deployable
assert all(f in FEATS for f in PRESET_FEATS)


def build(cot_rows, amap, alpha_s):
    out = []
    for c in cot_rows:
        a = amap.get(c['idx'])
        if a is None:
            continue
        fk = feats_one(a, c, alpha_s)
        if fk is None:
            continue
        x, aero_pred, k = fk
        out.append({'idx': c['idx'], 'x': x, 'aero_pred': aero_pred, 'k': k,
                    'gold': gold_int(a), 'cot_correct': k == gold_int(a),
                    'st': stratum(c['idx'])})
    return out


def delta_ci(correct_a, correct_b):
    """paired delta-acc + 95% normal CI from discordant counts."""
    n = len(correct_a)
    b = sum(1 for x, y in zip(correct_a, correct_b) if x and not y)
    c = sum(1 for x, y in zip(correct_a, correct_b) if y and not x)
    d = (b - c) / n
    se = math.sqrt(b + c) / n
    return d, (d - 1.96 * se, d + 1.96 * se), [b, c]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', default='ecare-p1')
    ap.add_argument('--aero-cal', required=True)
    ap.add_argument('--aero-test', required=True)
    ap.add_argument('--cot-cal', required=True)
    ap.add_argument('--cot-test', required=True)
    ap.add_argument('--refs', nargs='*', default=[])
    ap.add_argument('--tau', type=float, default=0.5)
    ap.add_argument('--alpha-s', type=float, default=1.5)
    ap.add_argument('--l2', type=float, default=1.0)
    ap.add_argument('--force', action='store_true')
    args = ap.parse_args()

    root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    TMP = os.path.join(root, 'tmp')
    dest = os.path.join(TMP, f'confirm_p1_{args.tag}.json')
    preset_path = os.path.join(TMP, f'preset_p1_{args.tag}.json')
    if os.path.exists(dest) and not args.force:
        raise SystemExit(f'[refuse] {dest} exists (single-evaluation discipline); '
                         'use --force to rerun and overwrite')

    cal = build(load(args.cot_cal), {r['idx']: r for r in load(args.aero_cal)}, args.alpha_s)
    test = build(load(args.cot_test), {r['idx']: r for r in load(args.aero_test)}, args.alpha_s)
    n_items_cal, n_items_test = len(load(args.cot_cal)), len(load(args.cot_test))
    if len(cal) < 0.95 * n_items_cal or len(test) < 0.99 * n_items_test:
        print(f'[warn] coverage cal {len(cal)}/{n_items_cal}, '
              f'test {len(test)}/{n_items_test} -- investigate before trusting')

    # --- fit preset on cal-180 (single feature; standardization on cal) ----
    j = [FEATS.index(f) for f in PRESET_FEATS]
    Xc = np.array([[r['x'][jj] for jj in j] for r in cal])
    Xt = np.array([[r['x'][jj] for jj in j] for r in test])
    yc = np.array([1.0 if r['cot_correct'] else 0.0 for r in cal])
    mu, sd = Xc.mean(0), Xc.std(0) + 1e-9
    w, b0 = fit_logistic((Xc - mu) / sd, yc, l2=args.l2)
    p = 1.0 / (1.0 + np.exp(-np.clip(((Xt - mu) / sd) @ w + b0, -30, 30)))
    preds = [r['k'] if pi >= args.tau else r['aero_pred'] for r, pi in zip(test, p)]

    ours = [x == r['gold'] for x, r in zip(preds, test)]
    acc = sum(ours) / len(test)
    cot = [r['cot_correct'] for r in test]
    bb, cc, pv = mcnemar(ours, cot)

    fl = sum(1 for x, r in zip(preds, test) if x != r['k'])
    gd = sum(1 for x, r in zip(preds, test) if x != r['k'] and x == r['gold'])
    bd = sum(1 for x, r in zip(preds, test)
             if x != r['k'] and x != r['gold'] and r['cot_correct'])
    assert (gd, bd) == (bb, cc), 'flip accounting != McNemar discordant'
    d_cot, ci_cot, _ = delta_ci(ours, cot)
    acc_cot = sum(cot) / len(cot)

    out = {
        'tag': args.tag, 'preset': 'conf_only', 'feats': PRESET_FEATS,
        'tau': args.tau, 'alpha_s': args.alpha_s, 'l2': args.l2,
        'n_cal': len(cal), 'n_test': len(test),
        'cal_strata': {s: sum(1 for r in cal if r['st'] == s) for s in 'reh'},
        'cal_cot_acc': round(float(np.mean(yc)), 4),
        'test': {
            'acc': round(acc, 4), 'acc_cot': round(acc_cot, 4),
            'primary_vs_cot': {
                'discordant': [bb, cc],
                'mcnemar_p': round(pv, 6) if pv is not None else None,
                'delta': round(d_cot, 4), 'ci95': [round(x, 4) for x in ci_cot],
                'flips': fl, 'good_flips': gd, 'bad_flips': bd,
                'neutral_flips': fl - gd - bd,
            },
        },
        'secondary_vs_refs': {},
    }

    # sanity-only diagnostics (NOT endpoints; cal-side LOO of the preset)
    p_loo = loo_probs(Xc, yc, args.l2)
    pr = [r['k'] if pi >= args.tau else r['aero_pred'] for r, pi in zip(cal, p_loo)]
    out['cal_LOO_acc_preset'] = round(
        sum(1 for a, r in zip(pr, cal) if a == r['gold']) / len(cal), 4)
    out['cal_stratum_acc_preset'] = {
        s: round(sum(1 for a, r in zip(pr, cal) if a == r['gold'] and r['st'] == s)
                 / max(1, sum(1 for r in cal if r['st'] == s)), 4) for s in 'reh'}

    for spec in args.refs:
        name, path = spec.split('=', 1)
        rows = load(path)
        rmap = {r['idx']: pred_int(r) for r in rows}
        vals = [rmap.get(r['idx']) for r in test]
        if any(v is None for v in vals):
            print(f'[warn] {name}: incomplete overlap, skipped')
            continue
        refc = [v == r['gold'] for v, r in zip(vals, test)]
        rb, rc, rp = mcnemar(ours, refc)
        d, ci, _ = delta_ci(ours, refc)
        out['secondary_vs_refs'][name] = {
            'acc_ref': round(sum(refc) / len(refc), 4),
            'discordant': [rb, rc],
            'mcnemar_p': round(rp, 5) if rp is not None else None,
            'delta': round(d, 4), 'ci95': [round(x, 4) for x in ci],
        }

    # --- preset lock (consumed verbatim by E5 / FinSoC) --------------------
    preset = {
        'tag': args.tag, 'preset': 'conf_only', 'feats': PRESET_FEATS,
        'w': [float(v) for v in w], 'b': float(b0),
        'mu': [float(v) for v in mu], 'sd': [float(v) for v in sd],
        'tau': args.tau, 'alpha_s': args.alpha_s, 'l2': args.l2,
        'n_cal': len(cal), 'fit_date': datetime.date.today().isoformat(),
        'formula': ('p_cot_correct = sigmoid(((cot_conf - mu)/sd) @ w + b); '
                    'final = CoT answer if p >= tau else probe (route-A) answer'),
    }

    with open(dest, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    with open(preset_path, 'w', encoding='utf-8') as fh:
        json.dump(preset, fh, indent=1, ensure_ascii=False)

    pc = out['test']['primary_vs_cot']
    print(f"P1 confirmation [{args.tag}]  cal {len(cal)} (strata {out['cal_strata']}) "
          f"-> test {len(test)} @ tau={args.tau}")
    print(f"  ours {acc:.4f} vs CoT {acc_cot:.4f}  "
          f"delta {pc['delta']:+.4f} CI95 [{ci_cot[0]:+.4f},{ci_cot[1]:+.4f}]")
    print(f"  McNemar [{bb},{cc}] p={pc['mcnemar_p']}  "
          f"flips {fl} = good {gd} / bad {bd} / neutral {fl - gd - bd}")
    print(f"  [sanity] calLOO {out['cal_LOO_acc_preset']}  "
          f"by-stratum {out['cal_stratum_acc_preset']}")
    for name, r in out['secondary_vs_refs'].items():
        print(f"  vs {name}: {r['acc_ref']:.4f}  delta {r['delta']:+.4f} "
              f"CI95 [{r['ci95'][0]:+.4f},{r['ci95'][1]:+.4f}]  "
              f"McNemar p={r['mcnemar_p']}")
    print('[written]', dest)
    print('[preset locked]', preset_path)


if __name__ == '__main__':
    main()
