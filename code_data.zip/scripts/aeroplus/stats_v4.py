#!/usr/bin/env python3
"""v4 cross-system statistics: McNemar exact + bootstrap CI + power analysis.

Compares systems that were collected as SEPARATE runs on the SAME frozen
items (paper headline comparisons):
  aero(full) vs cf_cot / cot / zeroshot / selfcons / pnps / sn_cot / g2
                                        on e-CARE expansion (exp_items_v2)
  aero vs cot / cf_cot                  on XCOPA per language (zh by default;
                                        vi/th/sw auto-skipped when absent)

AERO+ side reads the per-item prediction files written by run_offline.py
(tmp/preds_<tag>.jsonl) -- the raw collection files only contain probes;
the fused predictions exist only after `run_local_v4.sh analyze`.
Baseline side reads the raw run_exp.mjs / collect_v3.mjs outputs (pred field).

Correctness semantics (both sides, matched):
  baseline: pred == gold
  aero:     abstain on a negative (gold 3) counts as a correct rejection;
            abstain on a real item counts as a miss; otherwise pred == gold.

Outputs tmp/stats_v4.json with, per comparison:
  {n, acc_a, acc_b, delta, boot_ci95, discordant, mcnemar_p, detectable_delta}

Usage:  python3 scripts/aeroplus/stats_v4.py [--langs zh vi ...]
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from stats_tests import mcnemar_exact, boot_ci_delta, detectable_delta  # noqa: E402

HERE = Path(__file__).resolve().parent
TMP = HERE.parent.parent / 'tmp'

# aero side tags: e-CARE expansion analyzed with --tag ecare-v4; XCOPA per lang
AERO_E = 'preds_ecare-v4.jsonl'
XC_LANGS = ['zh']          # default: zh only (vi/th/sw supported, auto-skipped)
# English arm = COPA (copa-v2 tag); auto-skipped when baseline files absent
COPA_BASE = [('cot', 'preds_copa-v2.jsonl', 'results_cot_copa.jsonl'),
             ('cf_cot', 'preds_copa-v2.jsonl', 'results_cfcot_copa.jsonl')]

BASE_E = [
    ('cf_cot', 'results_cfcot_exp.jsonl'),
    ('cot', 'results_cot_exp.jsonl'),
    ('zeroshot', 'results_zeroshot_exp.jsonl'),
    ('selfcons', 'results_selfcons_exp.jsonl'),
    ('pnps', 'results_pnps_exp.jsonl'),
    ('sn_cot', 'results_sn_cot_exp.jsonl'),
    ('g2', 'results_g2_exp.jsonl'),
]
XC_BASE = [('cot', 'results_cot_xc{L}.jsonl'),
           ('cf_cot', 'results_cfcot_xc{L}.jsonl')]


def load_aero(path):
    """preds file: idx -> correct (bool). Uses the precomputed 'correct'
    field so the abstain semantics decided in run_offline stay single-source."""
    out = {}
    p = TMP / path
    if not p.exists():
        return out
    for line in p.read_text(encoding='utf-8').splitlines():
        if line.strip():
            r = json.loads(line)
            out[r['idx']] = bool(r['correct'])
    return out


def load_base(path):
    """raw baseline file: idx -> correct (pred == gold); invalid pred skipped."""
    out = {}
    p = TMP / path
    if not p.exists():
        return out
    for line in p.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        r = json.loads(line)
        if r.get('pred') in (1, 2, 3, '1', '2', '3'):
            out[r['idx']] = int(str(r['pred'])) == int(r['gold'])
    return out


def compare(label, aero, base):
    common = sorted(set(aero) & set(base))
    if len(common) < 10:
        return {'n': len(common), 'status': 'insufficient (collect more)'}
    b = sum(1 for i in common if aero[i] and not base[i])   # aero right, base wrong
    c = sum(1 for i in common if base[i] and not aero[i])
    acc_a = sum(aero[i] for i in common) / len(common)
    acc_b = sum(base[i] for i in common) / len(common)
    va = [1 if aero[i] else 0 for i in common]
    vb = [1 if base[i] else 0 for i in common]
    _, lo, hi = boot_ci_delta(va, vb)
    return {
        'n': len(common), 'acc_a': round(acc_a, 4), 'acc_b': round(acc_b, 4),
        'delta': round(acc_a - acc_b, 4), 'boot_ci95': [round(lo, 4), round(hi, 4)],
        'discordant': [b, c], 'mcnemar_p': round(mcnemar_exact(b, c), 5),
        'detectable_delta_n': round(detectable_delta(len(common), acc_b), 4),
    }


def main():
    argv = sys.argv[1:]
    langs = XC_LANGS
    if '--langs' in argv:
        langs = argv[argv.index('--langs') + 1].split(',')

    pairs = [(f'ecare-exp: aero vs {n}', AERO_E, f) for n, f in BASE_E]
    for L in langs:
        pairs += [(f'xcopa-{L}: aero vs {n}', f'preds_xc{L}.jsonl', f.format(L=L))
                  for n, f in XC_BASE]
    pairs += [(f'copa-en: aero vs {n}', pa, pb) for n, pa, pb in COPA_BASE]

    results = {}
    for label, pa, pb in pairs:
        if not (TMP / pa).exists():
            results[label] = {'n': 0, 'status': f'skipped ({pa} missing -- run analyze first)'}
            print(f'{label:34s} skipped ({pa} missing)')
            continue
        A, B = load_aero(pa), load_base(pb)
        if not B:
            results[label] = {'n': 0, 'status': f'skipped ({pb} missing)'}
            print(f'{label:34s} skipped ({pb} missing)')
            continue
        r = results[label] = compare(label, A, B)
        if 'status' in r:
            print(f"{label:34s} n={r['n']:4d}  {r['status']}")
        else:
            print(f"{label:34s} n={r['n']:4d}  {r['acc_a']:.3f} vs {r['acc_b']:.3f} "
                  f"(Δ={r['delta']:+.3f}, CI [{r['boot_ci95'][0]:+.3f},{r['boot_ci95'][1]:+.3f}], "
                  f"p={r['mcnemar_p']:.4f}, MDD={r['detectable_delta_n']:.3f})")

    out = TMP / 'stats_v4.json'
    out.write_text(json.dumps(results, indent=1, ensure_ascii=False))
    print('[written]', out)


if __name__ == '__main__':
    main()
