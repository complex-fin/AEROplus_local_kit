"""E5 gate runner for FinSoC (consuming the P1-locked CONFIG, refit per domain).

Decision (RUNLOG 2026-10-15, from diag_p1_ecare-p1.json):
  * FROZEN  : config = conf_only gate, tau=0.5, l2=1.0, alpha_s=1.5,
              single-evaluation discipline. Identical to preset_p1_ecare-p1.
  * REFIT   : the ONE logistic coefficient is re-fit on FinSoC's own cal
              split -- same treatment every baseline score gets in
              run_finsoc.sh (fairness). Justified by the e-CARE diagnostic:
              conf DISTRIBUTION is stable (KS .0495) but CONDITIONAL accuracy
              P(cot correct | conf) shifts (cal .81 vs test .76 at identical
              quantiles), so frozen coefficients would misread domain shift.
  * REFERENCE row: frozen e-CARE threshold (thr=0.6963) applied to FinSoC
              test, reported for the transfer narrative only -- NOT the
              primary number.

Primary endpoint (pre-registered): refit gate vs CoT on FinSoC test,
McNemar + delta 95% CI. Writes tmp/finsoc_gate_<tag>.json; refuses to
overwrite without --force.

Usage (wired into scripts/run_finsoc.sh analyze):
  python3 scripts/aeroplus/finsoc_gate.py --tag finsoc-en \
    --aero-cal tmp/results_aero_finsocen_cal.jsonl --aero-test tmp/results_aero_finsocen.jsonl \
    --cot-cal  tmp/results_cot_finsocen_cal.jsonl      --cot-test  tmp/results_cot_finsocen.jsonl \
    --frozen-preset tmp/preset_p1_ecare-p1.json
"""
import argparse
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from confirm_p1 import delta_ci                                     # noqa: E402
from diagnose_p1 import build, gate_stats, flip_detail              # noqa: E402
from hybrid_verifier import fit_logistic, load, mcnemar             # noqa: E402


def threshold_from(w, b, mu, sd, tau):
    """conf >= thr  <=>  sigmoid(((conf-mu)/sd) w + b) >= tau   (w > 0)."""
    logit_tau = math.log(tau / (1.0 - tau))
    return mu + (logit_tau - b) * sd / w


def vs_cot(rows, final_of):
    ca = [final_of(r) == r['gold'] for r in rows]
    cb = [r['cot_correct'] for r in rows]
    bb, cc, pv = mcnemar(ca, cb)
    acc, acc_cot = sum(ca) / len(rows), sum(cb) / len(rows)
    d, ci, _ = delta_ci(ca, cb)
    return {'acc': round(acc, 4), 'acc_cot': round(acc_cot, 4),
            'delta': round(d, 4), 'ci95': [round(x, 4) for x in ci],
            'discordant': [bb, cc],
            'mcnemar_p': round(pv, 5) if pv is not None else None,
            'good_flips': bb, 'bad_flips': cc}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', required=True)
    ap.add_argument('--aero-cal', required=True)
    ap.add_argument('--aero-test', required=True)
    ap.add_argument('--cot-cal', required=True)
    ap.add_argument('--cot-test', required=True)
    ap.add_argument('--frozen-preset', required=True,
                    help='e-CARE preset json (config only; coefficients used '
                         'for the frozen reference row)')
    ap.add_argument('--tau', type=float, default=0.5)
    ap.add_argument('--l2', type=float, default=1.0)
    ap.add_argument('--alpha-s', type=float, default=1.5)
    ap.add_argument('--force', action='store_true')
    args = ap.parse_args()

    TMP = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), 'tmp')
    dest = os.path.join(TMP, f'finsoc_gate_{args.tag}.json')
    if os.path.exists(dest) and not args.force:
        raise SystemExit(f'[refuse] {dest} exists (single-evaluation '
                         f'discipline); use --force to overwrite')

    p = json.load(open(args.frozen_preset, encoding='utf-8'))
    assert p['feats'] == ['cot_conf'] and abs(p['tau'] - args.tau) < 1e-9
    b_frozen = p['b'][0] if isinstance(p['b'], list) else p['b']
    thr_frozen = threshold_from(p['w'][0], b_frozen, p['mu'][0],
                                p['sd'][0], p['tau'])

    cal, cal_skip = build(load(args.cot_cal),
                          {r['idx']: r for r in load(args.aero_cal)},
                          args.alpha_s)
    test, test_skip = build(load(args.cot_test),
                            {r['idx']: r for r in load(args.aero_test)},
                            args.alpha_s)
    if not cal or not test:
        raise SystemExit(f'[empty] cal {len(cal)} / test {len(test)}')

    # --- per-domain refit of the single coefficient ------------------------
    Xc = np.array([[r['conf']] for r in cal])
    yc = np.array([1.0 if r['cot_correct'] else 0.0 for r in cal])
    mu, sd = Xc.mean(0), Xc.std(0) + 1e-9
    w, b = fit_logistic((Xc - mu) / sd, yc, l2=args.l2)
    w0 = float(np.ravel(w)[0])
    thr_domain = threshold_from(w0, float(b), float(mu[0]), float(sd[0]), args.tau)

    def final_refit(r):
        return r['k'] if r['conf'] >= thr_domain else r['aero_pred']

    def final_frozen(r):
        return r['k'] if r['conf'] >= thr_frozen else r['aero_pred']

    out = {
        'tag': args.tag, 'preset': 'conf_only(refit)',
        'config': {'feats': ['cot_conf'], 'tau': args.tau, 'l2': args.l2,
                   'alpha_s': args.alpha_s},
        'n_cal': len(cal), 'n_test': len(test),
        'drops': cal_skip + test_skip,
        'cal_cot_acc': round(sum(r['cot_correct'] for r in cal) / len(cal), 4),
        'refit': {
            'thr': round(thr_domain, 4),
            'w': [w0], 'b': float(b),
            'mu': [round(float(mu[0]), 6)], 'sd': [round(float(sd[0]), 6)],
            'gate': gate_stats(test, thr_domain),
            'vs_cot': vs_cot(test, final_refit),
            'flips': flip_detail(test, thr_domain),
        },
        'frozen_ecare_reference': {
            'note': 'e-CARE coefficients transferred as-is; reference only',
            'thr': round(thr_frozen, 4),
            'gate': gate_stats(test, thr_frozen),
            'vs_cot': vs_cot(test, final_frozen),
        },
    }
    with open(dest, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    rf, fz = out['refit']['vs_cot'], out['frozen_ecare_reference']['vs_cot']
    print(f"E5 gate [{args.tag}]  cal {len(cal)} -> test {len(test)}  "
          f"(drops {len(out['drops'])})")
    print(f"  refit  thr={out['refit']['thr']:.4f}  acc {rf['acc']:.4f} vs CoT "
          f"{rf['acc_cot']:.4f}  d {rf['delta']:+.4f} CI95 "
          f"[{rf['ci95'][0]:+.4f},{rf['ci95'][1]:+.4f}]  "
          f"[{rf['discordant'][0]},{rf['discordant'][1]}] p={rf['mcnemar_p']}")
    print(f"  frozen thr={out['frozen_ecare_reference']['thr']:.4f}  acc "
          f"{fz['acc']:.4f}  d {fz['delta']:+.4f}  p={fz['mcnemar_p']}  (reference)")
    print('[written]', dest)


if __name__ == '__main__':
    main()
