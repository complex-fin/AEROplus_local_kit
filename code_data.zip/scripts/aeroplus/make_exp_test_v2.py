#!/usr/bin/env python3
"""Build the e-CARE expanded frozen test set (v2, 450 items) -- the clean
confirmation experiment for the AERO+ v4 paper.

Rationale (review feedback): the original 79-item test drove both diagnosis
(f-gate, C0 keep) and evaluation -> test-set snooping. This NEW set is drawn
from untouched dev-pool premises with a fresh frozen seed; the v2 fusion
config is re-used verbatim, no re-fitting.

Composition (matches e-CARE adapter pi_real=2/3):
 - 300 real  (x2-r0..299)
 -  75 neg-easy (random-donor negatives, x2-e0..74)
 -  75 neg-hard (DHard recipe: gold hyps of topically-closest same-direction
                 donor premises, x2-h0..74)

Excluded premises: original test (80) + cal v2 (40) + cal v3 new (20).
Excluded hyp texts (hard-neg donors): all test + cal hypotheses.

Run:   python3 scripts/aeroplus/make_exp_test_v2.py
Then collect with supervisor_v4.sh (aeroplus / cf_cot / cot / zeroshot).
"""
import json, random, re, sys, os
from pathlib import Path
from collections import Counter

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import config as C
from data_prep import content_words, jaccard, gold_hyp

def hard_negatives(dev, premise_item, n_needed, used_hyps):
    """DHard recipe (verbatim logic from make_cal_v3.py): gold hyps of the
    topically-closest same-direction donor premises."""
    cands = [d for d in dev if d['ask-for'] == premise_item['ask-for']]
    scored = sorted(cands, key=lambda d: -jaccard(premise_item['premise'], d['premise']))
    picks, taken = [], set()
    own = {premise_item['hypothesis1'], premise_item['hypothesis2']}
    for d in scored:
        if d['premise'] == premise_item['premise']:
            continue
        g = gold_hyp(d)
        if g in own or g in taken or g in used_hyps:
            continue
        taken.add(g)
        picks.append(g)
        if len(picks) == n_needed:
            break
    return picks

SEED = 20261011          # frozen expansion seed (distinct from C.SEED)

def main():
    random.seed(SEED)
    dev = [json.loads(l) for l in open(C.DEV)]
    old_test = [json.loads(l) for l in open(C.TEST_FULL)]
    cal_v2 = [json.loads(l) for l in open(C.CAL_ITEMS)]
    cal_v3 = [json.loads(l) for l in open(HERE.parent.parent / 'tmp' / 'cal_items_v3.jsonl')]

    used_premises = ({it['premise'] for it in old_test}
                     | {it['premise'] for it in cal_v2}
                     | {it['premise'] for it in cal_v3})
    used_hyps = ({it['h1'] for it in old_test} | {it['h2'] for it in old_test}
                 | {it['h1'] for it in cal_v2} | {it['h2'] for it in cal_v2}
                 | {it['h1'] for it in cal_v3} | {it['h2'] for it in cal_v3})

    free = [d for d in dev if d['premise'] not in used_premises]
    random.shuffle(free)
    assert len(free) >= 450, f'pool too small: {len(free)}'

    out = []
    # -- 300 real ----------------------------------------------------------
    for i, it in enumerate(free[:300]):
        g = '1' if it['label'] == 0 else '2'
        out.append({'idx': f'x2-r{i}', 'type': 'real', 'premise': it['premise'],
                    'ask_for': it['ask-for'], 'h1': it['hypothesis1'],
                    'h2': it['hypothesis2'], 'gold': g})

    # -- 75 neg-easy (random donors, same recipe as data_prep cal-e) --------
    pool = free[300:]
    for i, it in enumerate(pool[:75]):
        while True:
            donors = random.sample(dev, 2)
            if (all(d['premise'] != it['premise'] for d in donors)
                    and donors[0]['hypothesis1'] != donors[1]['hypothesis1']):
                break
        out.append({'idx': f'x2-e{i}', 'type': 'negative', 'premise': it['premise'],
                    'ask_for': it['ask-for'], 'h1': donors[0]['hypothesis1'],
                    'h2': donors[1]['hypothesis1'], 'gold': '3'})

    # -- 75 neg-hard (DHard recipe) -----------------------------------------
    n_ok = 0
    for it in pool[75:]:
        if n_ok >= 75:
            break
        h = hard_negatives(dev, it, 2, used_hyps)
        if len(h) == 2:
            out.append({'idx': f'x2-h{n_ok}', 'type': 'neg-hard',
                        'premise': it['premise'], 'ask_for': it['ask-for'],
                        'h1': h[0], 'h2': h[1], 'gold': '3'})
            n_ok += 1
    assert n_ok == 75, f'hard negs short: {n_ok}'

    # sanity ------------------------------------------------------------
    idxs = [it['idx'] for it in out]
    assert len(idxs) == len(set(idxs)) == 450
    assert not ({it['premise'] for it in out} & used_premises), 'premise leak'
    bad = [it['idx'] for it in out if it['type'] == 'neg-hard'
           and (it['h1'] in used_hyps or it['h2'] in used_hyps)]
    assert not bad, f'hyp leak: {bad}'

    dest = HERE.parent.parent / 'tmp' / 'exp_items_v2.jsonl'
    with open(dest, 'w') as f:
        for it in out:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')
    print('exp test v2:', Counter(it['type'] for it in out), '->', dest)
    print('gold dist:', Counter(it['gold'] for it in out))

if __name__ == '__main__':
    main()
