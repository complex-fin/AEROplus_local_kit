#!/usr/bin/env python3
"""P1 prep: expand calibration 60 -> 180, stratified to mirror the test mix.

Pre-registered design (RUNLOG 2026-10-15, MODEL_FORMAL 4.4 lower branch):
  * target mix 120r / 30e / 30h (= 4:1:1, same as test-450 300/75/75);
  * keep all 60 existing cal-v3 items (raw records re-seeded, so collectors
    only fetch the 120 NEW items -> ~700 API calls total);
  * +100 real (idx cal4-r*) : fresh dev premises, not used by test/cal;
  * +20 easy-neg (idx cal4-e*): v1 scheme (random donor hypothesis1 pairs),
    donors re-sampled if a donor hyp collides with any test hypothesis;
  * new seed stream (SEED + 2000), independent of v2/v3 draws;
  * NO new hard-negs (v3 already has 30 = target).

Run:   python3 scripts/aeroplus/make_cal_p1.py
Then:  node scripts/collect_v3.mjs --system aeroplus \
           --input tmp/cal_items_p1.jsonl --output tmp/results_aeroplus_cal_p1.jsonl --conc 4
       node scripts/run_exp.mjs --system cot \
           --input tmp/cal_items_p1.jsonl --output tmp/results_cot_cal_p1.jsonl --conc 4
       python3 scripts/aeroplus/confirm_p1.py --tag ecare-p1 \
           --aero-cal tmp/results_aeroplus_cal_p1.jsonl --aero-test tmp/results_aero_exp.jsonl \
           --cot-cal  tmp/results_cot_cal_p1.jsonl      --cot-test tmp/results_cot_exp.jsonl \
           --refs selfcons=tmp/results_selfcons_exp.jsonl pnps=tmp/results_pnps_exp.jsonl
"""
import json, random, sys, os
from collections import Counter
sys.path.insert(0, os.path.dirname(__file__))
import config as C

TMP = C.TMP


def read_jsonl(p):
    return [json.loads(l) for l in open(p, encoding='utf-8') if l.strip()]


def write_jsonl(p, rows):
    with open(p, 'w', encoding='utf-8') as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + '\n')


def st_of(idx):
    seg = idx.split('-')[-1]
    return ''.join(ch for ch in seg if ch.isalpha())


def main():
    dev = read_jsonl(C.DEV)
    cal_v3 = read_jsonl(TMP / 'cal_items_v3.jsonl')

    # every premise/hypothesis the test side has ever used (v1 80 + v2 450)
    test_files = [p for p in [C.TEST_FULL, TMP / 'exp_items_v2.jsonl',
                              C.TEST_ITEMS, TMP / 'dhard_items.jsonl']
                  if p.exists()]
    test_rows = [r for p in test_files for r in read_jsonl(p)]
    used_premises = {r['premise'] for r in test_rows}
    used_hyps = {r['h1'] for r in test_rows} | {r['h2'] for r in test_rows}
    cal_premises = {it['premise'] for it in cal_v3}

    assert Counter(st_of(it['idx']) for it in cal_v3) == {'r': 20, 'e': 10, 'h': 30}, \
        'cal v3 mix changed -- revisit the expansion plan'

    # ---- new items ------------------------------------------------------
    random.seed(C.SEED + 2000)                    # fresh stream, not v2/v3's
    pool = [d for d in dev
            if d['premise'] not in used_premises and d['premise'] not in cal_premises]
    random.shuffle(pool)

    new_real = []
    for ri, it in enumerate(pool[:100]):
        new_real.append({'idx': f'cal4-r{ri}', 'type': 'real', 'premise': it['premise'],
                         'ask_for': it['ask-for'], 'h1': it['hypothesis1'],
                         'h2': it['hypothesis2'], 'gold': str(it['label'] + 1)})

    new_easy = []
    i = 0
    for it in pool[100:]:                        # premises after the real block
        if len(new_easy) >= 20:                  # 2026-10-15 fix: hard cap
            break
        placed = False
        for _ in range(200):                     # bounded donor resampling
            donors = random.sample(dev, 2)
            if (all(d['premise'] != it['premise'] for d in donors)
                    and donors[0]['hypothesis1'] != donors[1]['hypothesis1']
                    and donors[0]['hypothesis1'] not in used_hyps
                    and donors[1]['hypothesis1'] not in used_hyps):
                placed = True
                break
        if not placed:
            continue                             # skip premise, take the next one
        new_easy.append({'idx': f'cal4-e{i}', 'type': 'neg-easy', 'premise': it['premise'],
                         'ask_for': it['ask-for'], 'h1': donors[0]['hypothesis1'],
                         'h2': donors[1]['hypothesis1'], 'gold': '3'})
        i += 1

    v4 = [dict(it) for it in cal_v3] + new_real + new_easy

    # ---- write items + re-seed raw outputs ------------------------------
    out_items = TMP / 'cal_items_p1.jsonl'
    write_jsonl(out_items, v4)

    for src_name, dst_name in [('results_aeroplus_cal_v3.jsonl', 'results_aeroplus_cal_p1.jsonl'),
                               ('results_cot_cal_v3.jsonl', 'results_cot_cal_p1.jsonl')]:
        src, dst = TMP / src_name, TMP / dst_name
        if src.exists():
            old_idx = {it['idx'] for it in cal_v3}
            seeded = [r for r in read_jsonl(src) if r['idx'] in old_idx]
            write_jsonl(dst, seeded)
            print(f'seeded {len(seeded):3d} existing records -> {dst_name}')
        else:
            print(f'[warn] {src_name} missing: start collectors from scratch')

    # ---- sanity checks ----------------------------------------------------
    idxs = [it['idx'] for it in v4]
    assert len(idxs) == len(set(idxs)) == 180, 'idx collision/size'
    mix = Counter(st_of(i) for i in idxs)
    assert mix == {'r': 120, 'e': 30, 'h': 30}, f'stratum mix {mix}'
    assert not ({it['premise'] for it in v4} & used_premises), 'premise leak into test'
    prem = [it['premise'] for it in v4]
    assert len(prem) == len(set(prem)), 'duplicate premise in cal'
    # leak policy (2026-10-15, consistent with make_cal_v3 precedent):
    #  * CONSTRUCTED negatives (easy): donors are OUR choice -> strict assert.
    #  * NATURAL real items: h1/h2 are the dev item's own hypotheses; text
    #    collisions with test are an intrinsic e-CARE property (cal v2 items
    #    already carry the same kind of collisions) -> report, do not block.
    bad_new = [it['idx'] for it in new_easy
               if it['h1'] in used_hyps or it['h2'] in used_hyps]
    assert not bad_new, f'hyp leak into test (constructed items): {bad_new}'
    real_coll = [it['idx'] for it in new_real
                 if it['h1'] in used_hyps or it['h2'] in used_hyps]
    print(f'note: {len(real_coll)}/{len(new_real)} new real items share a hypothesis '
          f'text with test items (intrinsic e-CARE overlap, same as cal v2 '
          f'precedent; premises are disjoint): {real_coll}')

    aero_raw = TMP / 'results_aeroplus_cal_p1.jsonl'
    seeded = {r['idx'] for r in read_jsonl(aero_raw)} if aero_raw.exists() else set()
    todo = [it['idx'] for it in v4 if it['idx'] not in seeded]
    cot_raw = TMP / 'results_cot_cal_p1.jsonl'
    seeded_c = {r['idx'] for r in read_jsonl(cot_raw)} if cot_raw.exists() else set()
    todo_c = [it['idx'] for it in v4 if it['idx'] not in seeded_c]

    print(f'cal p1: {dict(mix)} (60 reused + 100 real + 20 easy) -> {out_items}')
    print(f'to collect: aero {len(todo)}, cot {len(todo_c)} '
          f'(~{len(todo) * 3 + len(todo_c)} API calls)')
    print(f'  todo idx: {todo[0]} ... {todo[-1]}')
    ex = new_real[0]
    print('\nnew real example:\n  P :', ex['premise'][:110])
    print('  h1:', ex['h1'][:110], '\n  h2:', ex['h2'][:110], ' gold', ex['gold'])


if __name__ == '__main__':
    main()
