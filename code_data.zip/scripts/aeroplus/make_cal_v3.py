#!/usr/bin/env python3
"""Build calibration items v3 for e-CARE (H3 fix; does NOT touch v2 files).

Why: with v2 fusion the cal/test mismatch is concentrated in DHard difficulty:
test neg-hard betp0 median .38 vs cal negatives .82 (easy .86 / old hard .64).
Mondrian q[0] fitted on too-easy cal negatives is anti-conservative on test.

Design (60 items, only 20 need fresh LLM collection):
 - 20 real (cal-r*)  + 10 easy-neg (cal-e*) + 10 old hard-neg (cal-h*):
   REUSED verbatim from cal_items_v2 -- existing raw records are re-seeded
   into results_aeroplus_cal_v3.jsonl, so the collector (resumable by idx)
   only collects the 20 new items.
 - 20 NEW hard-neg (idx cal3-h0..19): same DHard recipe as data_prep.py
   (gold hyps of topically-closest same-direction donors), fresh premises
   from the dev pool, donors excluding test/cal-v2 hypotheses.

Run:   python3 scripts/aeroplus/make_cal_v3.py
Then:  node scripts/collect_v3.mjs --system aeroplus \
           --input tmp/cal_items_v3.jsonl \
           --output tmp/results_aeroplus_cal_v3.jsonl
       python3 scripts/aeroplus/run_offline.py --dataset ecare \
           --cal tmp/results_aeroplus_cal_v3.jsonl --tag ecare-v3
"""
import json, random, re, sys, os
sys.path.insert(0, os.path.dirname(__file__))
import config as C

STOP = set('''a an the of in on at to for with by from into over under is are was were be been being
and or but so if then than as this that these those it its his her their our your my we they he she i you
not no do does did done have has had having will would can could shall should may might must'''.split())

def content_words(s):
    return {w for w in re.findall(r"[a-z']+", s.lower()) if w not in STOP}

def jaccard(a, b):
    A, B = content_words(a), content_words(b)
    return len(A & B) / max(len(A | B), 1)

def gold_hyp(it):
    return it['hypothesis1'] if it['label'] == 0 else it['hypothesis2']

def main():
    dev = [json.loads(l) for l in open(C.DEV)]
    test_full = [json.loads(l) for l in open(C.TEST_FULL)]
    cal_v2 = [json.loads(l) for l in open(C.CAL_ITEMS)]
    old_raw = [json.loads(l) for l in open(C.RAW_CAL)]

    used_premises = {it['premise'] for it in test_full}
    used_hyps = {it['h1'] for it in test_full} | {it['h2'] for it in test_full}
    calv2_premises = {it['premise'] for it in cal_v2}
    calv2_hyps = {it['h1'] for it in cal_v2} | {it['h2'] for it in cal_v2}

    # ---- reused block: all 40 v2 items (records already collected) ----
    v3 = [dict(it) for it in cal_v2]

    # ---- new hard negatives (fresh premises, DHard recipe) ----
    def hard_negatives(premise_item, n_needed, exclude_hyps):
        cands = [d for d in dev if d['ask-for'] == premise_item['ask-for']]
        scored = sorted(cands, key=lambda d: -jaccard(premise_item['premise'], d['premise']))
        picks, taken = [], set()
        own = {premise_item['hypothesis1'], premise_item['hypothesis2']}
        for d in scored:
            if d['premise'] == premise_item['premise']:
                continue
            g = gold_hyp(d)
            if g in own or g in exclude_hyps or g in taken or g in used_hyps:
                continue
            taken.add(g)
            picks.append(g)
            if len(picks) == n_needed:
                break
        return picks

    random.seed(C.SEED + 1000)                       # fresh stream, not v2's
    pool = [d for d in dev
            if d['premise'] not in used_premises and d['premise'] not in calv2_premises]
    random.shuffle(pool)

    new_hard, i = [], 0
    for it in pool:
        if len(new_hard) >= 20:
            break
        h = hard_negatives(it, 2, calv2_hyps)
        if len(h) == 2 and h[0] != h[1]:
            new_hard.append({'idx': f'cal3-h{i}', 'type': 'neg-hard',
                             'premise': it['premise'], 'ask_for': it['ask-for'],
                             'h1': h[0], 'h2': h[1], 'gold': '3'})
            i += 1
    v3 += new_hard

    # ---- write items v3 ----
    out_items = C.TMP / 'cal_items_v3.jsonl'
    with open(out_items, 'w') as f:
        for it in v3:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')

    # ---- pre-seed the v3 raw output with all 40 existing records ----
    out_raw = C.TMP / 'results_aeroplus_cal_v3.jsonl'
    old_idx = {it['idx'] for it in cal_v2}
    with open(out_raw, 'w') as f:
        for r in old_raw:
            if r['idx'] in old_idx:
                f.write(json.dumps(r, ensure_ascii=False) + '\n')

    # ---- sanity checks ----
    from collections import Counter
    idxs = [it['idx'] for it in v3]
    assert len(idxs) == len(set(idxs)) == 60, 'idx collision/size'
    test_idx = {it['idx'] for it in test_full}
    assert not (set(idxs) & test_idx), 'idx overlap with test'
    prem = [it['premise'] for it in v3]
    assert len(prem) == len(set(prem)), 'duplicate premise in cal'
    assert not ({it['premise'] for it in v3} & used_premises), 'premise leak into test'
    # hyp-leak check: STRICT for the 20 new items (must hold by construction);
    # reused v2 items are only reported (random-donor collisions with test
    # neg-easy hyps are a pre-existing, context-free property of cal v2).
    bad_new = [it['idx'] for it in new_hard
               if it['h1'] in used_hyps or it['h2'] in used_hyps]
    assert not bad_new, f'hyp leak into test (new items): {bad_new}'
    pre = [it['idx'] for it in cal_v2
           if it['h1'] in used_hyps or it['h2'] in used_hyps]
    print(f'note: {len(pre)} reused v2 items share a hypothesis text with test '
          f'neg-easy donors (pre-existing, harmless): {pre}')
    seeded = {json.loads(l)['idx'] for l in open(out_raw)}
    todo = [it['idx'] for it in v3 if it['idx'] not in seeded]

    # topical-closeness comparison: new hard vs test DHard
    dh = [json.loads(l) for l in open(C.DHard_ITEMS)]
    jd_new = [max(jaccard(it['premise'], it['h1']), jaccard(it['premise'], it['h2']))
              for it in new_hard]
    jd_dh = [max(jaccard(it['premise'], it['h1']), jaccard(it['premise'], it['h2']))
             for it in dh]

    print('cal v3:', Counter(it['type'] for it in v3), '->', out_items)
    print('seeded raw records:', len(seeded), '| to collect:', len(todo), '->', out_raw)
    print('  todo idx:', todo[0], '...', todo[-1])
    print(f'donor topical jaccard: new-hard max-donor med={sorted(jd_new)[10]:.3f} | '
          f'test DHard med={sorted(jd_dh)[10]:.3f}')
    ex = new_hard[0]
    print('\nnew hard-neg example:\n  P :', ex['premise'][:110])
    print('  h1:', ex['h1'][:110], '\n  h2:', ex['h2'][:110])

if __name__ == '__main__':
    main()
