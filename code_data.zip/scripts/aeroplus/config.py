"""AERO+ configuration (single source of truth)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]   # conversation workspace root
TMP = ROOT / 'tmp'
DOWNLOAD = ROOT / 'download'

# ---------------- data ----------------
DEV = TMP / 'ecare_dev.jsonl'
TEST_ITEMS = TMP / 'exp_items.jsonl'          # 60 items: 40 real + 20 neg-easy (frozen)
DHard_ITEMS = TMP / 'dhard_items.jsonl'       # 20 neg-hard (new, built by data_prep)
CAL_ITEMS = TMP / 'cal_items_v2.jsonl'        # 40: 20 real + 10 easy + 10 hard (seeded random)

TEST_FULL = TMP / 'exp_items_full.jsonl'      # 80 = TEST_ITEMS + DHard_ITEMS

# ---------------- collection ----------------
RAW_TEST = TMP / 'results_aeroplus.jsonl'     # raw L1+probe outputs (test)
RAW_CAL = TMP / 'results_aeroplus_cal.jsonl'  # raw L1+probe outputs (calibration)
CFCOT = TMP / 'results_cfcot.jsonl'           # CF-CoT proxy baseline
# legacy results (zeroshot/cot/aero_nocf/aero) are reused as-is for baselines

SEED = 20261008

# ---------------- L2 reading sampling ----------------
M_READINGS = 3           # RS-1: 3 readings per candidate inside one L1 call
ALPHA_S_GRID = [0.5, 1.0, 1.5, 2.0]   # u = min(alpha_s * sqrt(W), 0.8)
LEGACY_U_CAP = 0.5       # fallback for legacy records without reading scores

# ---------------- L3 fusion ----------------
BETA_GRID = [0.0, 0.25, 0.5, 0.75, 1.0]   # gamma = 1 - beta * max|rho_ij|
KMAX = 0.8               # K > KMAX -> Yager rule (conflict mass to Theta)

# ---------------- L3.5 calibration ----------------
LR_PENALTY = 1e-3
B3_ENABLED = True        # class-3 dependent conflict term (H7 LR test)

# ---------------- L5 conformal ----------------
ALPHA_GRID = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30]
# lambda-risk costs (spec 1.2): over-claim worse than miss
LAMBDA_MISS = 1.0
LAMBDA_OVER = 2.0
LAMBDA_ABS = 0.3
PI_REAL, PI_NEG = 2 / 3, 1 / 3   # test design mix (40 real : 20 neg-easy) x2

# ---------------- report ----------------
ANALYSIS_DIR = TMP / 'aeroplus_analysis'
