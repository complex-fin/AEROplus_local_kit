#!/usr/bin/env python3
"""核验 report.md 中 "v2_selective(全冻结触发,子集)" 行（zh 0.925 特别高）。

该行由 tmp/results_selfcons3_finsoc{L}.jsonl（r1 遗留的 test 采样，可能不完整）
决定子集。本脚本回答三个问题（零 API）：
  1. 子集有多大？idx 是否连续（采集顺序偏差风险）？
  2. 同子集上 conf-only 触发的 v2 是多少？（苹果对苹果，判断 0.925 是增益还是子集偏易）
  3. 子集与全集的 CoT/探针难度是否一致？

用法：python3 finsoc_v2_subset_check.py --lang zh
"""
import argparse, json, os, sys
from collections import Counter
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import fusion as F

PM_TAU = 0.3
TRIG_TCONF = 0.8
K = 3

def gi(g): return int(g) if g != '3' else 0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--lang', required=True, choices=['en', 'zh'])
    A = ap.parse_args()
    L = A.lang
    T = os.path.join(os.path.dirname(__file__), '..', '..', 'tmp')
    T = os.path.abspath(T)

    def load(name):
        p = os.path.join(T, name)
        if not os.path.exists(p):
            return None
        return [json.loads(l) for l in open(p, encoding='utf-8') if l.strip()]

    aero = {r['idx']: r for r in load(f'results_aero_finsoc{L}.jsonl') or []}
    cot = {r['idx']: r for r in load(f'results_cot_finsoc{L}.jsonl') or []}
    sc3 = {r['idx']: r for r in load(f'results_selfcons3_finsoc{L}.jsonl') or []}
    if not sc3:
        print(f'[check] 无 test sc3 文件（tmp/results_selfcons3_finsoc{L}.jsonl）——'
              f'report 中"全冻结触发,子集"行不应存在；若存在请回传 report 生成环境。')
        return

    common = [i for i in aero if i in cot]
    sub = [i for i in common if i in sc3]
    print(f'[{L}] 全集 n={len(common)}；sc3 子集 n={len(sub)}（覆盖率 {len(sub)/len(common):.2f}）')

    # 1) idx 连续性（采集顺序偏差风险）
    def seq_no(i):
        try: return int(i.split('-')[-1])
        except ValueError: return None
    nos = sorted(x for x in (seq_no(i) for i in sub) if x is not None)
    if nos:
        gaps = (nos[-1] - nos[0] + 1) - len(nos)
        print(f'  idx 序号范围 {nos[0]}–{nos[-1]}，缺 {gaps} 个 → '
              f'{"连续前缀（顺序偏差风险高）" if gaps == 0 and nos[0] == 0 else "非连续（可能随机/中断）"}')

    # 2) 同子集对比：全冻结触发 vs conf-only 触发（同一仲裁、同一默认）
    pl = {i: F.fuse(aero[i], 'plainds') for i in common}
    def g(i): return gi(aero[i]['gold'])
    def ca(i): return gi(cot[i]['pred'])
    def pa(i): return gi(str(pl[i]['pred']))
    def conf(i): return cot[i]['conf']
    def vmaj(i):
        v = sc3[i].get('votes') or {}
        tot = sum(v.values())
        return (max(v.values()) / tot) if tot else 0.0
    def smaj(i):
        v = sc3[i].get('votes') or {}
        return max(v, key=v.get) if v else None

    def arb(i, dflt='probe'):
        if pa(i) == ca(i): return ca(i)
        b = pl[i]['betp']
        if (b[pa(i)] - b[ca(i)]) > PM_TAU: return pa(i)
        return pa(i) if dflt == 'probe' else ca(i)

    def v2_confonly(i): return ca(i) if conf(i) >= TRIG_TCONF else arb(i)
    def v2_frozen(i):
        if vmaj(i) >= 1.0 and conf(i) >= TRIG_TCONF: return ca(i)
        if pa(i) != ca(i) and smaj(i) == str(pa(i)): return pa(i)   # 合谋分支
        return arb(i)

    for ids, tagS in [(common, '全集'), (sub, '同子集')]:
        a_c = np.mean([v2_confonly(i) == g(i) for i in ids])
        a_f = np.mean([v2_frozen(i) == g(i) for i in ids])
        t_f = np.mean([not (vmaj(i) >= 1.0 and conf(i) >= TRIG_TCONF) for i in ids])
        print(f'  {tagS:4s} n={len(ids):4d}: conf-only={a_c:.3f}  全冻结={a_f:.3f} (Δ={a_f-a_c:+.3f})  全冻结触发率={t_f:.3f}')

    # 3) 难度一致性
    for ids, tagS in [(common, '全集'), (sub, '子集')]:
        print(f'  {tagS} 难度: cot acc={np.mean([ca(i)==g(i) for i in ids]):.3f}  '
              f'plainds acc={np.mean([pa(i)==g(i) for i in ids]):.3f}  '
              f'分歧率={np.mean([pa(i)!=ca(i) for i in ids]):.3f}')

    # 4) 合谋分支在子集上的命中与正确性
    hit = [i for i in sub if pa(i) != ca(i) and smaj(i) == str(pa(i))]
    if hit:
        print(f'  合谋分支命中 {len(hit)} 条，其中探针对 {sum(pa(i)==g(i) for i in hit)}，CoT 对 {sum(ca(i)==g(i) for i in hit)}')
    # 5) 票不一致触发在子集上的增益来源
    vt = [i for i in sub if vmaj(i) < 1.0 and conf(i) >= TRIG_TCONF]  # conf 不触发、仅票触发
    if vt:
        gain = sum((v2_frozen(i) == g(i)) and (ca(i) != g(i)) for i in vt)
        loss = sum((v2_frozen(i) != g(i)) and (ca(i) == g(i)) for i in vt)
        print(f'  仅票触发（conf≥0.8 但票不一致）n={len(vt)}：修复 {gain} / 引入新错 {loss}')

if __name__ == '__main__':
    main()
