#!/usr/bin/env python3
"""Build calibration set v2 (seeded random, incl. negatives) and D_hard test items.

Fixes vs v1 (per AERO+ spec sec 2.3 / review):
 - calibration is a SEEDED RANDOM sample (not the sequential first-40) -> exchangeability
 - calibration contains gold-3 items -> Mondrian per-class conformal is feasible
 - D_hard: high-association zero-causal negatives -- both candidates are GOLD
   hypotheses of topically-closest same-direction donor premises.
"""
import json, random, re
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import config as C

STOP = set('''a an the of in on at to for with by from into over under is are was were be been being
and or but so if then than as this that these those it its his her their our your my we they he she i you
not no do does did done have has had having will would can could shall should may might must'''.split())

def content_words(s):
    return {w for w in re.findall(r"[a-z']+", s.lower()) if w not in STOP}

def jaccard(a, b):
    A, B = content_words(a), content_words(b)
    return len(A & B) / max(len(A | B), 1)

def gold_hyp(it):
    return it['hypothesis1'] if it['label'] == 0 else it['hypothesis2']

def main():
    random.seed(C.SEED)
    dev = [json.loads(l) for l in open(C.DEV)]
    test = [json.loads(l) for l in open(C.TEST_ITEMS)]
    used_premises = {it['premise'] for it in test}
    used_hyps = {it['h1'] for it in test} | {it['h2'] for it in test}
    free = [it for it in dev if it['premise'] not in used_premises]
    random.shuffle(free)

    # ---- D_hard construction ----------------------------------------
    def hard_negatives(premise_item, n_donor_needed, exclude_hyps):
        """gold hypotheses of the topically-closest same-direction donors."""
        cands = [d for d in dev if d['ask-for'] == premise_item['ask-for']]
        scored = sorted(cands, key=lambda d: -jaccard(premise_item['premise'], d['premise']))
        picks, taken = [], set()
        own = {premise_item['hypothesis1'], premise_item['hypothesis2']}
        for d in scored:
            if d['premise'] == premise_item['premise']:
                continue
            g = gold_hyp(d)
            if g in own or g in exclude_hyps or g in taken or g in used_hyps:
                continue
            taken.add(g); picks.append(g)
            if len(picks) == n_donor_needed:
                break
        return picks

    # ---- calibration set v2: 20 real + 10 easy-neg + 10 hard-neg ----
    cal = []
    for ri, it in enumerate(free[:20]):
        cal.append({'idx': f'cal-r{ri}', 'type': 'real', 'premise': it['premise'],
                    'ask_for': it['ask-for'], 'h1': it['hypothesis1'], 'h2': it['hypothesis2'],
                    'gold': str(it['label'] + 1)})
    for i, it in enumerate(free[20:30]):          # easy-neg: random donor hyp1 (v1 scheme)
        while True:
            donors = random.sample(dev, 2)
            if all(d['premise'] != it['premise'] for d in donors) and donors[0]['hypothesis1'] != donors[1]['hypothesis1']:
                break
        cal.append({'idx': f'cal-e{i}', 'type': 'neg-easy', 'premise': it['premise'],
                    'ask_for': it['ask-for'], 'h1': donors[0]['hypothesis1'], 'h2': donors[1]['hypothesis1'],
                    'gold': '3'})
    for i, it in enumerate(free[30:40]):          # hard-neg
        h = hard_negatives(it, 2, set())
        if len(h) == 2:
            cal.append({'idx': f'cal-h{i}', 'type': 'neg-hard', 'premise': it['premise'],
                        'ask_for': it['ask-for'], 'h1': h[0], 'h2': h[1], 'gold': '3'})
    with open(C.CAL_ITEMS, 'w') as f:
        for it in cal:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')

    # ---- D_hard test items (20) -------------------------------------
    dhard = []
    i = 0
    for it in free[40:120]:
        if len(dhard) >= 20:
            break
        h = hard_negatives(it, 2, set())
        if len(h) == 2 and h[0] != h[1]:
            dhard.append({'idx': f'dhard-{i}', 'type': 'neg-hard', 'premise': it['premise'],
                          'ask_for': it['ask-for'], 'h1': h[0], 'h2': h[1], 'gold': '3'})
            i += 1
    with open(C.DHard_ITEMS, 'w') as f:
        for it in dhard:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')

    # full test list (80) for the aeroplus collector
    with open(C.TEST_FULL, 'w') as f:
        for it in test + dhard:
            f.write(json.dumps(it, ensure_ascii=False) + '\n')

    from collections import Counter
    print('cal v2:', Counter(x['type'] for x in cal), '->', C.CAL_ITEMS)
    print('dhard test:', len(dhard), '->', C.DHard_ITEMS)
    print('full test:', len(test) + len(dhard), '->', C.TEST_FULL)
    # sanity: show one hard-neg example (topical overlap)
    ex = dhard[0]
    print('\nD_hard example:\n  P :', ex['premise'][:110])
    print('  h1:', ex['h1'][:110], '\n  h2:', ex['h2'][:110])

if __name__ == '__main__':
    main()
