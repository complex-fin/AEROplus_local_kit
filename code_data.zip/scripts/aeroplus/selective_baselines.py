#!/usr/bin/env python3
"""Selective-prediction BASELINE suite -- the comparison methods reviewers
asked for, computed offline from already-collected raw records.

Baselines (each produces a risk-coverage curve + alpha-grid table):
  1. conf-quantile  : verbalized-confidence quantile abstention (CoT baseline;
                      the "lambda-risk vs CoT quantile" H3' competitor)
  2. softmax-conformal: split conformal on the same confidence score with
                      class-conditional (one-vs-rest) nonconformity --
                      the standard CP baseline vs our Mondrian 3-frame CP
  3. answer-entropy : abstain when the k=5 selfcons answer distribution is
                      too dispersed (semantic-entropy proxy for 3-way choice)
  4. selfcons-vote  : plain self-consistency accuracy (no abstention layer)

Scores are ALWAYS fit on the calibration split, evaluated on the test split
(the same discipline as the AERO+ Mondrian layer -- no peeking).

Inputs (produced by run_local_v4.sh collect):
  tmp/results_cot_exp.jsonl        (conf field)
  tmp/results_selfcons_exp.jsonl   (samples field)
  or the XCOPA equivalents (pass --cot/--sc paths)
Output: tmp/selective_baselines_{tag}.json + printed table.

Usage:
  python3 scripts/aeroplus/selective_baselines.py --tag ecare-v4 \
      --cot-cal tmp/results_cot_cal.jsonl --cot-test tmp/results_cot_exp.jsonl \
      --sc-cal  tmp/results_selfcons_cal.jsonl --sc-test tmp/results_selfcons_exp.jsonl
"""
import argparse, json, math, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TMP = HERE.parent.parent / 'tmp'
ALPHAS = [0.05, 0.10, 0.15, 0.20, 0.25, 0.30]


def load(path):
    if not path or not Path(path).exists():
        return []
    out = []
    for line in open(path,encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        r = json.loads(line)
        if r.get('pred') in (None, 'parse') and not r.get('samples'):
            continue
        out.append(r)
    return out


def gold(r):
    return int(r['gold'])


def correct(r):
    return 1 if int(r.get('pred') or 0) == gold(r) else 0


def risk_coverage(recs, score_fn, higher_is_confident=True):
    """Risk & coverage when abstaining on lowest-confidence fraction.
    Returns list of (coverage, risk) sorted by coverage (desc)."""
    scored = [(score_fn(r), correct(r), r) for r in recs]
    scored = [s for s in scored if s[0] is not None]
    n = len(scored)
    if n == 0:
        return []
    scored.sort(key=lambda s: -s[0] if higher_is_confident else s[0])
    curve, cum_c, cum_n = [], 0, 0
    for i, (sc, c, r) in enumerate(scored):
        cum_c += c
        cum_n += 1
        if (i + 1) % max(1, n // 20) == 0 or i == n - 1:   # ~20 points
            curve.append((round(cum_n / n, 3), round(1 - cum_c / cum_n, 4)))
    return curve


def conf_quantile_alpha(cal, test, alpha):
    """Split-conformal style threshold on verbalized confidence:
    abstain unless conf >= q_{1-alpha} of calibration confidences."""
    confs = sorted(r['conf'] for r in cal if r.get('conf') is not None)
    if not confs:
        return None
    k = max(1, math.ceil((1 - alpha) * len(confs)))
    thr = confs[min(k, len(confs)) - 1]
    kept = [r for r in test if (r.get('conf') or 0) >= thr]
    if not kept:
        return {'alpha': alpha, 'coverage': 0.0, 'risk': None, 'thr': thr}
    return {'alpha': alpha,
            'coverage': round(len(kept) / len(test), 3),
            'risk': round(sum(1 - correct(r) for r in kept) / len(kept), 4),
            'thr': round(thr, 3)}


def answer_entropy(rec):
    ss = [s['answer'] for s in (rec.get('samples') or []) if s.get('answer')]
    if len(ss) < 2:
        return None
    ps = {}
    for a in ss:
        ps[a] = ps.get(a, 0) + 1
    h = -sum((c / len(ss)) * math.log(c / len(ss)) for c in ps.values())
    return h    # abstain when H > threshold (higher entropy = less confident)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', default='ecare-v4')
    ap.add_argument('--cot-cal'), ap.add_argument('--cot-test')
    ap.add_argument('--sc-cal'), ap.add_argument('--sc-test')
    # conf-based new baselines (Gonzalez-Nori pnps / Yu et al. sn_cot)
    ap.add_argument('--pnps-cal'), ap.add_argument('--pnps-test')
    ap.add_argument('--sncot-cal'), ap.add_argument('--sncot-test')
    ap.add_argument('--g2-cal'), ap.add_argument('--g2-test')
    a = ap.parse_args()
    cot_cal, cot_test = load(a.cot_cal), load(a.cot_test)
    sc_cal, sc_test = load(a.sc_cal), load(a.sc_test)
    out = {'tag': a.tag, 'alphas': ALPHAS}

    # generic conf-quantile for any conf-based system
    def conf_system(name, cal, test):
        if not (cal and test):
            return
        out[f'{name}_conf_quantile'] = [conf_quantile_alpha(cal, test, al) for al in ALPHAS]
        out[f'{name}_risk_coverage'] = risk_coverage(test, lambda r: r.get('conf'))
        out[f'{name}_acc'] = round(sum(correct(r) for r in test) / len(test), 4)

    # 1. CoT confidence-quantile abstention
    if cot_cal and cot_test:
        conf_system('cot', cot_cal, cot_test)
    # 1b. pnps (Gonzalez-Nori) & sn_cot (Yu et al.) same treatment
    conf_system('pnps', load(a.pnps_cal), load(a.pnps_test))
    conf_system('sncot', load(a.sncot_cal), load(a.sncot_test))
    conf_system('g2', load(a.g2_cal), load(a.g2_test))

    # 2. softmax-style conformal: same confidence score, class-conditional
    #    nonconformity (1 - conf of TRUE class is not observable at test time,
    #    so we use the class-conditional threshold form: abstain unless
    #    conf >= per-class quantile of correctly-classified calibration items)
    if cot_cal and cot_test:
        rows = []
        for al in ALPHAS:
            kept, n = [], 0
            for r in cot_test:
                cls = r.get('pred')
                pool = [c['conf'] for c in cot_cal
                        if c.get('pred') == cls and correct(c) == 1 and c.get('conf') is not None]
                if not pool:
                    kept.append(r); n += 1; continue
                thr = sorted(pool)[max(1, math.ceil((1 - al) * len(pool))) - 1]
                if (r.get('conf') or 0) >= thr:
                    kept.append(r); n += 1
            rows.append({'alpha': al, 'coverage': round(n / len(cot_test), 3),
                         'risk': round(sum(1 - correct(r) for r in kept) / max(1, n), 4) if kept else None})
        out['softmax_conformal'] = rows

    # 3/4. selfcons + answer-entropy abstention
    if sc_test:
        acc = sum(correct(r) for r in sc_test) / len(sc_test)
        out['selfcons_acc'] = round(acc, 4)
        ent_cal = [answer_entropy(r) for r in sc_cal]
        ent_cal = [e for e in ent_cal if e is not None]
        out['answer_entropy_risk_coverage'] = risk_coverage(
            sc_test, answer_entropy, higher_is_confident=False)
        rows = []
        for al in ALPHAS:
            if not ent_cal:
                break
            # threshold = (1-alpha) quantile of cal entropies; abstain above
            s = sorted(ent_cal)
            thr = s[min(len(s) - 1, max(0, int((1 - al) * len(s))))]
            kept = [r for r in sc_test
                    if (lambda e: e is not None and e <= thr)(answer_entropy(r))]
            rows.append({'alpha': al, 'coverage': round(len(kept) / len(sc_test), 3),
                         'risk': round(sum(1 - correct(r) for r in kept) / max(1, len(kept)), 4) if kept else None,
                         'H_thr': round(thr, 3)})
        out['entropy_abstain'] = rows

    dest = TMP / f'selective_baselines_{a.tag}.json'
    dest.write_text(json.dumps(out, indent=1, ensure_ascii=False))
    print(json.dumps(out, indent=1, ensure_ascii=False))
    print('[written]', dest)


if __name__ == '__main__':
    main()
