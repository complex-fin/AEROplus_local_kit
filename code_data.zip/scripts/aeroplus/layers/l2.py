"""L2: reading sampling -> marginal belief + imputation variance -> unknown-mass u.

Pure computation over an L1 CandidateParse. No LLM, fully unit-testable.

RS-1 (spec sec 3.2):
  belief = mean of reading plausibilities          (marginal over readings)
  W      = sample variance of reading plausibilities
  u      = min( alpha_s * sqrt(W * (1 + 1/M)), u_cap )
           (1+1/M corrects the plug-in variance of the mean; cap keeps u a
            mass, i.e. u < 1)

Legacy records (no readings): belief = plausibility, u from ambiguity
(capped) -- kept for backward compatibility with v1 collections.
"""
import math
from . import l1

U_CAP = 0.8
LEGACY_U_CAP = 0.5
LEGACY_AMB_DEFAULT = 0.3

def reading_stats(cp: l1.CandidateParse):
    """-> (belief, W, M) or None if not reading-sampled."""
    if not l1.is_reading_sampled(cp):
        return None
    s = [r.plausibility for r in cp.readings]
    M = len(s)
    mean = sum(s) / M
    W = sum((x - mean) ** 2 for x in s) / (M - 1) if M > 1 else 0.0
    return mean, W, M

def belief_and_u(cp: l1.CandidateParse, alpha_s: float = 1.0):
    """-> (belief, u, rs_flag). Canonical L2 interface used by L3 fusion."""
    st = reading_stats(cp)
    if st is not None:
        mean, W, M = st
        u = min(alpha_s * math.sqrt(W * (1.0 + 1.0 / M)), U_CAP)
        return mean, u, True
    bel = cp.plausibility if cp.plausibility is not None else 0.5
    amb = cp.ambiguity if cp.ambiguity is not None else LEGACY_AMB_DEFAULT
    return bel, min(amb, LEGACY_U_CAP), False
