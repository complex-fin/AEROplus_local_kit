"""L1: normalize raw LLM parse output into a validated L1Record.

The LLM call itself lives in scripts/aero_prompts.mjs (Node/SDK side);
this module owns schema validation, defaults and legacy-record compatibility,
so that downstream layers (L2, L3) never see raw prompt JSON.

L1Record (per candidate h_k):
  missing      : str   -- description of missing event elements
  readings     : [ {completion: str, plausibility: float} ]   (RS-1, M=3)
  hidden       : str   -- unobserved confounder narrative
  plausibility : float -- overall association/plausibility (fallback belief)
  confounder   : float -- f source score
  ambiguity    : float -- legacy ambiguity (fallback u)
"""
from dataclasses import dataclass, field
from typing import Optional, List

def clamp01(v, default=None):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return default
    if x < 0:
        return 0.0
    if x > 1:
        return 1.0
    return x

@dataclass
class Reading:
    completion: str = ""
    plausibility: float = 0.5

@dataclass
class CandidateParse:
    missing: str = ""
    hidden: str = ""
    readings: List[Reading] = field(default_factory=list)
    plausibility: Optional[float] = None
    confounder: Optional[float] = None
    ambiguity: Optional[float] = None

def _parse_candidate(h: dict) -> CandidateParse:
    cp = CandidateParse()
    cp.missing = str(h.get('missing') or '')
    cp.hidden = str(h.get('hidden') or '')
    for r in h.get('readings') or []:
        p = clamp01(r.get('plausibility'))
        if p is not None:
            cp.readings.append(Reading(str(r.get('completion') or ''), p))
    cp.plausibility = clamp01(h.get('plausibility'))
    cp.confounder = clamp01(h.get('confounder'))
    cp.ambiguity = clamp01(h.get('ambiguity'))
    return cp

def normalize(callA: Optional[dict]):
    """Raw callA JSON -> {'h1': CandidateParse, 'h2': CandidateParse} (never raises)."""
    A = callA or {}
    return {'h1': _parse_candidate(A.get('h1') or {}),
            'h2': _parse_candidate(A.get('h2') or {})}

def is_reading_sampled(cp: CandidateParse) -> bool:
    """RS-1 available iff >=2 readings survived normalization."""
    return len(cp.readings) >= 2
