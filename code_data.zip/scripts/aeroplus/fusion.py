"""L3 fusion: discount Dempster-Shafer on the common 3-frame Theta = {C1, C2, C0}.

Frame: C_k = candidate k is the true causal counterpart (k=1,2);
       C_0 = no candidate has a causal link with the premise.
Sources per item: text_1, text_2 (Bel + unknown-mass u from L2), N_1, N_2,
S_1, S_2 (probes, binary), f_1, f_2 (confounder reports on C_0), and an
OPTIONAL kg_1, kg_2 (event-knowledge-graph evidence, rec['kg'], see
graph/kg_source.py). All masses are vacuously extended to the 3-frame.
Combination is EXACT (all-source tuple enumeration), so K is the true total
conflicting mass (fixing the old max-increment K).

Layering: L1 normalization lives in layers/l1.py, L2 reading marginalization
in layers/l2.py. This module only consumes their outputs.
"""
import itertools, math
import statistics
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from layers import l1 as L1, l2 as L2

CLS = (1, 2, 0)
OMEGA = frozenset(CLS)

# ---------- mass constructors ----------
def mass_belief(bel, u, k):
    """Binary mass for 'C_k holds' with belief bel and unknown-mass u,
    vacuously extended to the 3-frame."""
    return {frozenset({k}): bel * (1 - u),
            OMEGA - {k}: (1 - bel) * (1 - u),
            OMEGA: u}

def mass_point(p, k):
    """Sharp (u=0) binary mass on C_k."""
    return {frozenset({k}): p, OMEGA - {k}: 1 - p}

def mass_c0(f):
    """Confounder source: mass f on {C_0}."""
    return {frozenset({0}): f, OMEGA: 1 - f}

def f_gate(f):
    """FIX v2 (f-gating): f=0.5 means 'no confounder found' (no information),
    yet mass_c0(0.5) injects a constant 0.5 pull toward C_0 that drags split
    evidence into 'neither'. Gate so only the confident excess over 0.5 is
    injected: f<=0.5 -> vacuous source, f=1 -> full mass on C_0.
    Validated offline: e-CARE full acc .734->.797, COPA .267->.883."""
    return max(0.0, 2.0 * f - 1.0)

def discount(m, gamma):
    out = {}
    for B, v in m.items():
        if B != OMEGA:
            out[B] = out.get(B, 0.0) + gamma * v
    out[OMEGA] = (1 - gamma) + gamma * m.get(OMEGA, 0.0)
    return out

# ---------- exact multi-source combination ----------
def combine_all(masses, rule='auto', kmax=0.8):
    """Exact combination of a list of mass dicts over subsets of Theta.

    Returns (combined_mass, K, rule_used). K = total mass of tuples of focal
    sets with empty intersection (true conflict, all-source product form).
    rule: 'dempster' | 'yager' | 'auto' (yager if K > kmax).
    """
    acc, K = {}, 0.0
    for focal in itertools.product(*[list(m.items()) for m in masses]):
        sets, ws = zip(*focal)
        p = math.prod(ws)
        inter = sets[0]
        for s in sets[1:]:
            inter = inter & s
        if not inter:
            K += p
        else:
            acc[inter] = acc.get(inter, 0.0) + p
    rule_eff = 'yager' if (rule == 'auto' and K > kmax) else rule
    if rule_eff == 'yager':
        acc[OMEGA] = acc.get(OMEGA, 0.0) + K
    else:  # dempster
        if K >= 0.999:  # degenerate: vacuous result
            return {OMEGA: 1.0}, K, 'dempster'
        acc = {B: v / (1 - K) for B, v in acc.items() if v > 1e-12}
    return acc, K, rule_eff

def pignistic(m):
    """BetP(c) = sum_B m(B) |B ∩ {c}| / |B|."""
    bp = {c: 0.0 for c in CLS}
    for B, v in m.items():
        n = len(B)
        for c in B:
            bp[c] += v / n
    return bp

# ---------- per-item source extraction (delegates to L1/L2 layers) ----------
def clamp01(x, default=0.5):
    try:
        x = float(x)
    except (TypeError, ValueError):
        return default
    return min(1.0, max(0.0, x))

def extract_sources(rec, alpha_s=1.0):
    """-> {'bel': {1:..,2:..}, 'u': {1:..,2:..}, 'N': {1:..,2:..}, 'S': {1:..,2:..},
           'f': {1:..,2:..}, 'kg': {1:..,2:..}|None, 'rs': True/False}

    L1: raw callA JSON -> CandidateParse (layers/l1.py)
    L2: readings -> (belief, u) with the 1+1/M variance correction
        (layers/l2.py); legacy records fall back to plausibility/ambiguity.
    KG: rec['kg'] = {'h1': s, 'h2': s} merged by collect_v3.mjs, absent => None.
    """
    A = L1.normalize(rec.get('callA'))
    out = {'rs': False, 'N': {}, 'S': {}, 'kg': None}
    for k, hk in ((1, 'h1'), (2, 'h2')):
        cp = A[hk]
        bel, u, rs = L2.belief_and_u(cp, alpha_s)
        out['rs'] = out['rs'] or rs
        out.setdefault('bel', {})[k] = bel
        out.setdefault('u', {})[k] = u            # final u (alpha_s already applied)
        out.setdefault('f', {})[k] = cp.confounder if cp.confounder is not None else clamp01((rec.get('callA') or {}).get(hk, {}).get('confounder'))
        N = rec.get('N') or {}; S = rec.get('S') or {}
        out['N'][k] = clamp01((N or {}).get(hk))
        out['S'][k] = clamp01((S or {}).get(hk))
    kg = rec.get('kg')
    if isinstance(kg, dict) and 'h1' in kg and 'h2' in kg:
        out['kg'] = {1: clamp01(kg['h1']), 2: clamp01(kg['h2'])}
    return out

def with_ambiguity(src, rec):
    """attach legacy ambiguity when needed"""
    if src.get('amb') is None:
        A = rec.get('callA') or {}
        src['amb'] = max(clamp01((A.get('h1') or {}).get('ambiguity'), 0.3),
                         clamp01((A.get('h2') or {}).get('ambiguity'), 0.3))
    return src

def fuse(rec, variant='full', gammas=None, alpha_s=1.0, kmax=0.8):
    """Fuse one raw aeroplus/legacy record.

    variant: 'full'    all sources (incl. kg when present), gamma-discounted,
                       auto Dempster/Yager
             'plainds' all sources, NO discount (H6 contrast)
             'nocf'    text + confounder only (H1 contrast)
             'nods'    score averaging + legacy s3 rule (H6 contrast)
    Returns {'betp': {1,2,0}, 'K': float, 'rule': str, 'pred': int}
    """
    src = extract_sources(rec, alpha_s)
    if not src['rs']:
        src = with_ambiguity(src, rec)
    g = gammas or {}

    if variant == 'nods':
        b = {k: statistics.mean([src['bel'][k], src['N'][k], src['S'][k]]) for k in (1, 2)}
        s3 = max(1 - max(b[1], b[2]), (src['f'][1] + src['f'][2]) / 2)
        tot = b[1] + b[2] + s3 or 1e-9
        betp = {1: b[1] / tot, 2: b[2] / tot, 0: s3 / tot}
        return {'betp': betp, 'K': 0.0, 'rule': 'avg', 'pred': max(betp, key=betp.get)}

    masses = []
    for k in (1, 2):
        m_text = mass_belief(src['bel'][k], src['u'][k], k)
        m_N = mass_point(src['N'][k], k)
        m_S = mass_point(src['S'][k], k)
        m_f = mass_c0(f_gate(src['f'][k]))   # FIX v2: gated confounder mass
        if variant == 'nocf':
            masses += [m_text, m_f]
        else:
            if variant in ('full',) and g:
                m_text = discount(m_text, g.get('text', 1.0))
                m_N = discount(m_N, g.get('N', 1.0))
                m_S = discount(m_S, g.get('S', 1.0))
                m_f = discount(m_f, g.get('f', 1.0))
            masses += [m_text, m_N, m_S, m_f]
        if variant in ('full', 'plainds') and src['kg']:
            m_kg = mass_point(src['kg'][k], k)
            if g and variant == 'full':
                m_kg = discount(m_kg, g.get('kg', 1.0))
            masses.append(m_kg)
    combined, K, rule = combine_all(masses, rule='auto', kmax=kmax)
    betp = pignistic(combined)
    return {'betp': betp, 'K': K, 'rule': rule, 'pred': max(betp, key=betp.get)}

# ---------- gamma estimation from calibration records ----------
def pearson(xs, ys):
    n = len(xs)
    if n < 3:
        return 0.0
    mx, my = sum(xs) / n, sum(ys) / n
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    sxx = sum((x - mx) ** 2 for x in xs)
    syy = sum((y - my) ** 2 for y in ys)
    if sxx <= 0 or syy <= 0:
        return 0.0
    return sxy / math.sqrt(sxx * syy)

def estimate_gammas(cal_recs, beta):
    """gamma_i = 1 - beta * max_{j != i} |rho_ij| over source score vectors
    pooled across candidates (text=Bel, N, S, f, and kg when present)."""
    vec = {'text': [], 'N': [], 'S': [], 'f': []}
    has_kg = any(isinstance(r.get('kg'), dict) for r in cal_recs)
    if has_kg:
        vec['kg'] = []
    for rec in cal_recs:
        s = extract_sources(rec)
        for k in (1, 2):
            vec['text'].append(s['bel'][k]); vec['N'].append(s['N'][k])
            vec['S'].append(s['S'][k]); vec['f'].append(s['f'][k])
            if has_kg:
                vec['kg'].append(s['kg'][k] if s['kg'] else 0.5)
    names = list(vec)
    gam = {}
    for i, a in enumerate(names):
        worst = max(abs(pearson(vec[a], vec[b])) for b in names if b != a)
        gam[a] = max(0.05, 1.0 - beta * worst)
    return gam, {f'rho_{a}_{b}': round(pearson(vec[a], vec[b]), 3)
                 for i, a in enumerate(names) for b in names[i + 1:]}
