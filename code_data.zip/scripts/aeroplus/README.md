# AERO+ 结构化代码库

按《AERO+ 完整模型规范 v1.0》实现的五层管线 + 对比方法 + 假设检验。

## 文件

| 文件 | 职责 |
|---|---|
| `config.py` | 唯一配置源：路径、种子、超参网格、λ 代价、π 混合 |
| `data_prep.py` | 校准集 v2（种子化随机 20 real + 10 易负 + 10 难负）与 D_hard 测试项构造 |
| `../collect_v2.mjs` | LLM 采集器：`aeroplus`（L1 含逐读法评分 + 最小骨架探针）、`cf_cot`（CF-CoT 代理基线） |
| `fusion.py` | L3：γ 折扣 + 三分框架 vacuous 扩展 + 精确多源 Dempster/Yager + 正确口径 K + pignistic |
| `calibration.py` | L3.5：两参数 logistic（a, b, c0, b3）——冲突信息符号由数据学出 |
| `conformal.py` | L5：Mondrian 按类保形弃权 + α 网格 λ-风险选择 + 覆盖修正 |
| `validity.py` | L4/H5/H6：探针效度 AUC（精确置换 + 条目级聚类 bootstrap）、信念-边一致性配对比较 |
| `run_offline.py` | 离线编排：原始输出 → 融合 → 校准 → 保形 → 假设检验 → 报告 |
| `smoke_test.py` | 融合/保形数学单元测试（10 项，须全部通过） |
| `../supervisor_v2.sh` | 后台采集监管：断点续采、限流等待、完成后自动分析 |

## 关键设计

**离线回放契约**：只采集一套 `aeroplus` 原始输出（L1 + 探针），
`aero_nocf`（去探针）、`aero_nods`（均值融合）、`plain-DS`（无折扣）全部
**离线派生**——消融零边际 API 成本。

**探针独立性**：采集器的探针调用只接收最小事件骨架（前提 + 候选），
不接收 L1 上下文（修复 V2 审查发现的源非独立问题）。

**旧数据兼容**：`fusion.extract_sources` 自动检测 legacy 记录（无逐读法
评分时回退 u=min(ambiguity, 0.5)），旧 aero 结果可直接进入新管线。

## 运行

```bash
python3 scripts/aeroplus/smoke_test.py          # 数学单元测试
bash scripts/supervisor_v2.sh                    # 采集（后台，限流自愈）
python3 scripts/aeroplus/run_offline.py          # 分析（自动检测 cal/interim 模式）
```

输出：`tmp/aeroplus_analysis/report.md` + `metrics.json`。

## 假设 → 代码位置

- H1 探针增量：`run_offline.py` McNemar（full vs nocf，负例过度判因）
- H2 λ-风险：`conformal.risk_on_cal` + 报告对比表
- H3 覆盖保证：`conformal.mondrian_quantiles` + H3 覆盖检查
- H4 校准：Brier/logloss，betp vs 校准后 c
- H5 探针效度：`validity.cluster_bootstrap_ci` + 精确置换
- H6 融合一致性：`validity.paired_bootstrap_diff`
- H7 类依赖冲突：`calibration.lr_test_b3`
