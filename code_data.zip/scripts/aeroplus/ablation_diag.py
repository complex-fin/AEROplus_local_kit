"""Ablation diagnostics for the hybrid verifier (v4).

Answers, in one run, the four questions raised by the ecare ablation:
  1. Is conf-only (0.8133) really better than full (0.8022)?  -> pairwise
     McNemar between variants at the pre-registered tau (default 0.5).
  2. Is the probe signal real but drowned by cal noise?  -> per-feature
     single-feature AUC on cal vs test (label: cot_correct); a probe with
     test AUC clearly > 0.5 but cal AUC unstable = estimation problem,
     not absence of signal.
  3. Which feature subset would an HONEST cal-LOO selection pick, and what
     does it give on test (evaluated once)?
  4. Where exactly do probe-driven flips differ from conf-only flips?

Usage:
  python scripts/aeroplus/ablation_diag.py --tag ecare-v4 --tau 0.5 \
    --aero-cal tmp/results_aeroplus_cal_v3.jsonl --aero-test tmp/results_aero_exp.jsonl \
    --cot-cal  tmp/results_cot_cal_v3.jsonl      --cot-test tmp/results_cot_exp.jsonl \
    [--refs selfcons=tmp/results_selfcons_exp.jsonl ...]
Writes tmp/ablation_<tag>.json
"""
import argparse
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from hybrid_verifier import (FEATS, feats_one, fit_logistic, load, gold_int,  # noqa: E402
                             mcnemar, pred_int)

SUBSETS = {
    'full': FEATS,
    'conf_only': ['cot_conf'],
    'probe_only': ['agree', 'betp_cot', 'N_gap', 'S_gap', 'f_gap', 'K'],
    'conf+betp_cot': ['cot_conf', 'betp_cot'],
    'conf+agree': ['cot_conf', 'agree'],
    'conf+N_gap': ['cot_conf', 'N_gap'],
    'conf+S_gap': ['cot_conf', 'S_gap'],
    'conf+agree+betp_cot': ['cot_conf', 'agree', 'betp_cot'],
    'conf+N_gap+betp_cot': ['cot_conf', 'N_gap', 'betp_cot'],
    'conf_pruned3': ['cot_conf', 'betp_cot', 'N_gap'],
    # v2: stratum-aware (SA) — N/S 语义按 idx 前缀分层翻转（Simpson 悖论），
    #     全局系数错误；交互列 = 原特征 × 层指示
    'SA_min': ['cot_conf', 'betp_cot', 'is_r', 'is_h',
               'N_gap_r', 'N_gap_h', 'N_gap_e'],
    'SA+S': ['cot_conf', 'betp_cot', 'is_r', 'is_h',
             'N_gap_r', 'N_gap_h', 'N_gap_e',
             'S_gap_r', 'S_gap_h', 'S_gap_e'],
    'SA_probe': ['betp_cot', 'is_r', 'is_h',
                 'N_gap_r', 'N_gap_h', 'N_gap_e'],
}

AUG_NAMES = FEATS + ['is_r', 'is_h', 'is_e'] + \
    [f'{f}_{s}' for f in ('N_gap', 'S_gap') for s in ('r', 'h', 'e')]


def stratum(idx):
    seg = idx.split('-')[-1]
    s = ''.join(ch for ch in seg if ch.isalpha())
    return s or 'unknown'


def aug_matrix(rows, X):
    """FEATS + stratum indicators + stratum-masked N/S columns."""
    strat = np.array([stratum(r['idx']) for r in rows])
    cols = [X]
    for s in ('r', 'h', 'e'):
        cols.append((strat == s).astype(float)[:, None])
    for f in ('N_gap', 'S_gap'):
        j = FEATS.index(f)
        for s in ('r', 'h', 'e'):
            cols.append((X[:, j] * (strat == s)).astype(float)[:, None])
    return np.hstack(cols)


def auc(x, y):
    """Rank AUC of feature x for label y (1 = cot_correct)."""
    order = np.argsort(x)
    ys = y[order]
    n1, n0 = int(ys.sum()), int((1 - ys).sum())
    if n1 == 0 or n0 == 0:
        return None
    ranks = np.empty(len(x))
    sx = x[order]
    i = 0
    while i < len(x):  # midranks for ties
        j = i
        while j + 1 < len(x) and sx[j + 1] == sx[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2 + 1
        i = j + 1
    return float((ranks[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def loo_probs(Xc, yc, l2):
    p = np.zeros(len(yc))
    for i in range(len(yc)):
        m = np.ones(len(yc), dtype=bool)
        m[i] = False
        Xi, yi = Xc[m], yc[m]
        mi, si = Xi.mean(0), Xi.std(0) + 1e-9
        wl, bl = fit_logistic((Xi - mi) / si, yi, l2=l2)
        p[i] = 1.0 / (1.0 + np.exp(-np.clip(((Xc[i] - mi) / si) @ wl + bl, -30, 30)))
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', default='ecare-v4')
    ap.add_argument('--aero-cal', required=True)
    ap.add_argument('--aero-test', required=True)
    ap.add_argument('--cot-cal', required=True)
    ap.add_argument('--cot-test', required=True)
    ap.add_argument('--refs', nargs='*', default=[])
    ap.add_argument('--tau', type=float, default=0.5)
    ap.add_argument('--alpha-s', type=float, default=1.5)
    ap.add_argument('--l2', type=float, default=1.0)
    args = ap.parse_args()
    TMP = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), 'tmp')

    def build(cot_rows, aero_rows):
        amap = {r['idx']: r for r in aero_rows}
        out = []
        for c in cot_rows:
            a = amap.get(c['idx'])
            if a is None:
                continue
            fk = feats_one(a, c, args.alpha_s)
            if fk is None:
                continue
            x, aero_pred, k = fk
            out.append({'idx': c['idx'], 'x': x, 'k': k, 'aero_pred': aero_pred,
                        'gold': gold_int(a),
                        'cot_correct': k == gold_int(a),
                        'aero_correct': aero_pred == gold_int(a)})
        return out

    cal = build(load(args.cot_cal), load(args.aero_cal))
    test = build(load(args.cot_test), load(args.aero_test))
    yc = np.array([1.0 if r['cot_correct'] else 0.0 for r in cal])
    yt = np.array([1.0 if r['cot_correct'] else 0.0 for r in test])
    Xc = np.array([r['x'] for r in cal])
    Xt = np.array([r['x'] for r in test])

    out = {'tag': args.tag, 'n_cal': len(cal), 'n_test': len(test),
           'tau': args.tau, 'note': 'test columns for non-LOO-selected subsets are '
           'exploratory (selection on test = leakage); only loo_pick is honest'}

    # --- Q2: single-feature AUC, cal vs test --------------------------------
    auc_tab = {}
    for j, f in enumerate(FEATS):
        auc_tab[f] = {'cal': round(auc(Xc[:, j], yc), 3) if auc(Xc[:, j], yc) else None,
                      'test': round(auc(Xt[:, j], yt), 3) if auc(Xt[:, j], yt) else None}
    out['single_feature_auc'] = auc_tab

    # --- variants at tau ----------------------------------------------------
    Xca, Xta = aug_matrix(cal, Xc), aug_matrix(test, Xt)
    preds = {}
    accs = {}
    for name, feats in SUBSETS.items():
        idx = [AUG_NAMES.index(f) for f in feats]
        Xcs, Xts = Xca[:, idx], Xta[:, idx]
        mu, sd = Xcs.mean(0), Xcs.std(0) + 1e-9
        w, b = fit_logistic((Xcs - mu) / sd, yc, l2=args.l2)
        p = 1.0 / (1.0 + np.exp(-np.clip(((Xts - mu) / sd) @ w + b, -30, 30)))
        pr = [r['k'] if pi >= args.tau else r['aero_pred'] for r, pi in zip(test, p)]
        preds[name] = pr
        accs[name] = sum(1 for a, r in zip(pr, test) if a == r['gold']) / len(test)

    def mcm(a, b_):
        ca = [x == r['gold'] for x, r in zip(preds[a], test)]
        cb = [x == r['gold'] for x, r in zip(preds[b_], test)]
        bb, cc, pv = mcnemar(ca, cb)
        return {'acc_a': round(accs[a], 4), 'acc_b': round(accs[b_], 4),
                'discordant': [bb, cc],
                'p': round(pv, 5) if pv is not None else None}

    out['pairwise_at_tau'] = {
        'full_vs_conf_only': mcm('full', 'conf_only'),
        'full_vs_probe_only': mcm('full', 'probe_only'),
        'conf_only_vs_probe_only': mcm('conf_only', 'probe_only'),
        'SA+S_vs_conf_only': mcm('SA+S', 'conf_only'),
        'SA+S_vs_full': mcm('SA+S', 'full'),
        'SA+S_vs_SA_probe': mcm('SA+S', 'SA_probe'),
        'SA_probe_vs_conf_only': mcm('SA_probe', 'conf_only'),
        'SA+S_vs_SA_min': mcm('SA+S', 'SA_min'),
    }

    # --- Q3: honest LOO subset selection ------------------------------------
    loo = {}
    for name, feats in SUBSETS.items():
        idx = [AUG_NAMES.index(f) for f in feats]
        p_loo = loo_probs(Xca[:, idx], yc, args.l2)
        pr = [r['k'] if pi >= args.tau else r['aero_pred'] for r, pi in zip(cal, p_loo)]
        loo[name] = round(sum(1 for a, r in zip(pr, cal) if a == r['gold']) / len(cal), 4)
    loo_pick = max(loo, key=lambda k: (loo[k], -len(SUBSETS[k])))  # tie-break: smaller
    out['cal_LOO_acc_by_subset'] = loo
    out['loo_pick'] = {'subset': loo_pick, 'feats': SUBSETS[loo_pick],
                       'test_acc': round(accs[loo_pick], 4)}
    out['test_acc_by_subset'] = {k: round(v, 4) for k, v in accs.items()}

    # loo_pick vs CoT (the one honest head-to-head for the paper)
    ca = [x == r['gold'] for x, r in zip(preds[loo_pick], test)]
    bb, cc, pv = mcnemar(ca, [r['cot_correct'] for r in test])
    lp_flips = sum(1 for x, r in zip(preds[loo_pick], test) if x != r['k'])
    lp_good = sum(1 for x, r in zip(preds[loo_pick], test) if x != r['k'] and x == r['gold'])
    # 2026-10-15 fix (same as proxy_sa_diag): count bad directly; `flips - good`
    # wrongly included both-wrong answer changes.
    lp_bad = sum(1 for x, r in zip(preds[loo_pick], test)
                 if x != r['k'] and x != r['gold'] and r['cot_correct'])
    assert (lp_good, lp_bad) == (bb, cc), 'flip accounting != McNemar discordant'
    out['loo_pick_vs_cot'] = {'discordant': [bb, cc],
                              'mcnemar_p': round(pv, 5) if pv is not None else None,
                              'flips': lp_flips, 'good_flips': lp_good,
                              'bad_flips': lp_bad,
                              'neutral_flips': lp_flips - lp_good - lp_bad}

    # --- stratum breakdown: is the cal/test signal reversal driven by
    #     one item stratum (e.g. 'x2-r...' vs 'x2-h...')? -------------------
    def stratum(idx):
        seg = idx.split('-')[-1]
        s = ''.join(ch for ch in seg if ch.isalpha())
        return s or 'unknown'

    strat = {}
    for split, rows, y, X in (('cal', cal, yc, Xc), ('test', test, yt, Xt)):
        groups = {}
        for i, r in enumerate(rows):
            groups.setdefault(stratum(r['idx']), []).append(i)
        for s, ii in sorted(groups.items()):
            ii = np.array(ii)
            entry = {'n': len(ii), 'cot_acc': round(float(y[ii].mean()), 4)}
            for j, f in enumerate(FEATS):
                a = auc(X[ii, j], y[ii])
                entry[f] = round(a, 3) if a is not None else None
            strat.setdefault(s, {})[split] = entry
    out['by_stratum'] = strat

    # --- Q4: flip composition full vs conf_only -----------------------------
    ff = [i for i in range(len(test)) if preds['full'][i] != test[i]['k']]
    cf = [i for i in range(len(test)) if preds['conf_only'][i] != test[i]['k']]
    only_full = [i for i in ff if i not in set(cf)]
    only_conf = [i for i in cf if i not in set(ff)]
    out['flip_diff'] = {
        'flips_full': len(ff), 'flips_conf_only': len(cf),
        'only_in_full': {'n': len(only_full),
                         'good': sum(1 for i in only_full if preds['full'][i] == test[i]['gold']),
                         'idx': [test[i]['idx'] for i in only_full][:40]},
        'only_in_conf': {'n': len(only_conf),
                         'good': sum(1 for i in only_conf if preds['conf_only'][i] == test[i]['gold']),
                         'idx': [test[i]['idx'] for i in only_conf][:40]},
    }

    # --- refs vs multiple variants (conf_only, best SA, honest loo_pick) -----
    compare = {'conf_only': preds['conf_only'],
               'SA+S': preds['SA+S'],
               'SA_probe': preds['SA_probe'],
               'loo_pick': preds[loo_pick]}
    refs = {}
    for spec in args.refs:
        name, path = spec.split('=', 1)
        rows = load(path)
        pm = {r['idx']: pred_int(r) for r in rows}  # same parser as hybrid_verifier
        vals = [pm.get(r['idx']) for r in test]
        if any(v is None for v in vals):
            print(f'[warn] {name}: incomplete overlap, skipped')
            continue
        corr = [v == r['gold'] for v, r in zip(vals, test)]
        entry = {'acc': round(sum(corr) / len(corr), 4)}
        for lbl, pr in compare.items():
            # NOTE: zip with test — bare comprehension would leak the last r
            ca = [p == r['gold'] for p, r in zip(pr, test)]
            bb, cc, pv = mcnemar(ca, corr)
            entry[lbl] = {'discordant': [bb, cc],
                          'mcnemar_p': round(pv, 5) if pv is not None else None}
        refs[name] = entry
    out['vs_refs'] = refs

    dest = os.path.join(TMP, f'ablation_{args.tag}.json')
    with open(dest, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    print(f"n(cal/test) = {len(cal)}/{len(test)}   tau = {args.tau}")
    print('--- acc by subset (test, exploratory except loo_pick) ---')
    for k, v in accs.items():
        print(f"  {k:22s} {v:.4f}   calLOO {loo[k]:.4f}")
    print(f"LOO pick: {loo_pick} -> test {accs[loo_pick]:.4f}")
    lp = out['loo_pick_vs_cot']
    print(f"  loo_pick vs CoT: discordant {lp['discordant']}, p={lp['mcnemar_p']} "
          f"(flips {lp['flips']}: good {lp['good_flips']} / bad {lp['bad_flips']})")
    print('--- by stratum (cal | test): n / cot_acc / N_gap / S_gap / betp_cot AUC ---')
    for s, d in out['by_stratum'].items():
        for split in ('cal', 'test'):
            e = d.get(split)
            if e:
                print(f"  [{s} {split}] n={e['n']:4d} cot={e['cot_acc']:.3f} "
                      f"N_gap={e['N_gap']} S_gap={e['S_gap']} betp_cot={e['betp_cot']}")
    print('--- pairwise McNemar at tau ---')
    for k, v in out['pairwise_at_tau'].items():
        print(f"  {k}: {v['acc_a']:.4f} vs {v['acc_b']:.4f}  "
              f"discordant {v['discordant']}  p={v['p']}")
    print('--- single-feature AUC (cal | test) ---')
    for f, v in auc_tab.items():
        print(f"  {f:14s} {v['cal']} | {v['test']}")
    print('--- flip diff (full vs conf_only) ---')
    fd = out['flip_diff']
    print(f"  flips full={fd['flips_full']} conf={fd['flips_conf_only']}  "
          f"only_full={fd['only_in_full']['n']} (good {fd['only_in_full']['good']})  "
          f"only_conf={fd['only_in_conf']['n']} (good {fd['only_in_conf']['good']})")
    for name, r in refs.items():
        parts = ', '.join(f"{lbl} p={r[lbl]['mcnemar_p']} [{r[lbl]['discordant'][0]}"
                          f"/{r[lbl]['discordant'][1]}]" for lbl in compare)
        print(f"  vs {name} (acc {r['acc']:.4f}): {parts}")
    print('[written]', dest)


if __name__ == '__main__':
    main()
