"""P2: proxy stratification — replace idx-prefix stratum indicators (deploy-leak)
with content-inferable probe fingerprints, and test whether the SA gains survive.

Motivation (RUNLOG 2026-10-13): SA+S (stratum-aware verifier) reaches 0.8333 on
test but its is_r/is_h/is_e come from idx prefixes = construction metadata not
available at deployment. If a proxy built ONLY from probe outputs recovers the
strata (or recovers the *gain*), the claim upgrades to "the verifier
spontaneously identifies item type from probe fingerprints".

Design (honesty discipline):
  * Proxy features are probe-only and CoT-answer-independent:
      aN=|N1-N2|, aS=|S1-S2|, af=|f1-f2|, bmax, bmargin, K
    (cal prototype 2026-10-13: bmargin orders e>.94 > h>.63 > r>.41, K reverses;
    the "zero-gap" rule is FALSE — e's N_gap AUC 0.0 is anti-prediction, not 0.)
  * Two deployable stratification mechanisms:
      PSA  — k-means k=3 on cal (scipy kmeans2, seeded), clusters -> pseudo-strata
             with the same interaction structure as SA
      CS   — continuous moderation, no discretization:
             N_gap x bmargin, S_gap x bmargin interactions
  * Everything fit on cal only; test evaluated once at pre-registered tau=0.5.
  * cal-LOO honest selection is restricted to DEPLOYABLE candidates
    (SA_true variants appear only as leaky ceilings, never selectable).
  * NOTE: the stratification idea itself originated from test-side diagnosis,
    so all numbers remain exploratory until the P1 expanded-cal confirmation.

Usage:
  python scripts/aeroplus/proxy_sa_diag.py --tag ecare-p2 --tau 0.5 \
    --aero-cal tmp/results_aeroplus_cal_v3.jsonl --aero-test tmp/results_aero_exp.jsonl \
    --cot-cal  tmp/results_cot_cal_v3.jsonl      --cot-test tmp/results_cot_exp.jsonl \
    [--refs selfcons=tmp/results_selfcons_exp.jsonl ...]
  (with only --aero-* files it runs the proxy-recovery diagnostic and exits)
Writes tmp/proxy_sa_<tag>.json
"""
import argparse
import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from fusion import extract_sources, fuse                                   # noqa: E402
from hybrid_verifier import (FEATS, feats_one, fit_logistic, load,         # noqa: E402
                             gold_int, mcnemar, pred_int)
from ablation_diag import auc, loo_probs, stratum                         # noqa: E402

PROXY_FEATS = ['aN', 'aS', 'af', 'bmax', 'bmargin', 'K']


def proxy_feats_one(rec, alpha_s):
    """Probe-only, CoT-answer-independent feature dict (deployable)."""
    src = extract_sources(rec, alpha_s)
    f = fuse(rec, 'plainds', None, alpha_s)
    bv = sorted(f['betp'].values())
    return {
        'aN': abs(src['N'][1] - src['N'][2]),
        'aS': abs(src['S'][1] - src['S'][2]),
        'af': abs(src['f'][1] - src['f'][2]),
        'bmax': bv[-1],
        'bmargin': bv[-1] - bv[0],
        'K': f['K'],
    }


def ari(a, b):
    """Adjusted Rand index between two label vectors."""
    from math import comb
    n = len(a)
    ua, ub = {}, {}
    for x in a:
        ua[x] = ua.get(x, 0) + 1
    for x in b:
        ub[x] = ub.get(x, 0) + 1
    cont = {}
    for x, y in zip(a, b):
        cont[(x, y)] = cont.get((x, y), 0) + 1
    sum_ij = sum(comb(v, 2) for v in cont.values())
    sum_a = sum(comb(v, 2) for v in ua.values())
    sum_b = sum(comb(v, 2) for v in ub.values())
    exp = sum_a * sum_b / comb(n, 2)
    maxi = (sum_a + sum_b) / 2
    return float((sum_ij - exp) / (maxi - exp)) if maxi != exp else 1.0


def confusion(a, b, labels_a, labels_b):
    tab = {}
    for x, y in zip(a, b):
        tab.setdefault(x, {})[y] = tab.setdefault(x, {}).get(y, 0) + 1
    return {la: {lb: tab.get(la, {}).get(lb, 0) for lb in labels_b}
            for la in labels_a}


def kmeans_assign(Xcal, Xother, k, seed):
    """scipy kmeans2 on standardized cal; returns labels for both."""
    from scipy.cluster.vq import kmeans2, whiten
    mu, sd = Xcal.mean(0), Xcal.std(0) + 1e-9
    Zc, Zo = (Xcal - mu) / sd, (Xother - mu) / sd
    centroid, lab_cal = kmeans2(Zc, k, minit='++', seed=seed, iter=50)
    lab_other = np.argmin(((Zo[:, None, :] - centroid[None, :, :]) ** 2)
                          .sum(-1), axis=1)
    return lab_cal, lab_other, centroid


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', default='ecare-p2')
    ap.add_argument('--aero-cal', required=True)
    ap.add_argument('--aero-test', required=True)
    ap.add_argument('--cot-cal', default=None)
    ap.add_argument('--cot-test', default=None)
    ap.add_argument('--refs', nargs='*', default=[])
    ap.add_argument('--tau', type=float, default=0.5)
    ap.add_argument('--alpha-s', type=float, default=1.5)
    ap.add_argument('--l2', type=float, default=1.0)
    ap.add_argument('--seed', type=int, default=20261013)
    ap.add_argument('--proxy-feats', default='aN,aS,bmax,K',
                    help='features used for PSA clustering (cal-selected); '
                         'diagnostics always report all 6')
    args = ap.parse_args()
    TMP = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), 'tmp')

    cal_a = {r['idx']: r for r in load(args.aero_cal)}
    test_a = {r['idx']: r for r in load(args.aero_test)}

    def proxy_rows(amap):
        out = []
        for idx, r in amap.items():
            p = proxy_feats_one(r, args.alpha_s)
            p['idx'] = idx
            p['st'] = stratum(idx)
            out.append(p)
        return out

    calp, testp = proxy_rows(cal_a), proxy_rows(test_a)
    Pc = np.array([[r[f] for f in PROXY_FEATS] for r in calp])
    Pt = np.array([[r[f] for f in PROXY_FEATS] for r in testp])
    stc = [r['st'] for r in calp]
    stt = [r['st'] for r in testp]

    out = {'tag': args.tag, 'n_cal': len(calp), 'n_test': len(testp),
           'proxy_feats': PROXY_FEATS,
           'note': 'proxy stratification is a post-hoc design (idea originated '
           'from test-side stratum diagnosis); all numbers exploratory until '
           'the P1 expanded-cal confirmation run'}

    # --- proxy recovery (diagnostic; uses idx only for evaluation) -----------
    sel = [f for f in args.proxy_feats.split(',') if f in PROXY_FEATS]
    j_sel = [PROXY_FEATS.index(f) for f in sel]
    lab_c, lab_t, _ = kmeans_assign(Pc[:, j_sel], Pt[:, j_sel], 3, args.seed)
    out['proxy_cluster_feats'] = sel
    strat_labels = sorted(set(stc) | set(stt))
    out['recovery'] = {
        'confusion_cal': confusion(stc, list(lab_c), strat_labels, [0, 1, 2]),
        'confusion_test': confusion(stt, list(lab_t), strat_labels, [0, 1, 2]),
        'ari_cal': round(ari(stc, list(lab_c)), 3),
        'ari_test': round(ari(stt, list(lab_t)), 3),
        'proxy_means_by_stratum_test': {
            s: {'n': sum(1 for r in testp if r['st'] == s),
                **{f: (round(float(np.mean([r[f] for r in testp if r['st'] == s])), 3)
                      if any(r['st'] == s for r in testp) else None)
                   for f in PROXY_FEATS}} for s in strat_labels},
    }

    # single-feature separation diagnostics (test, labeled exploratory)
    sep = {}
    y_e = np.array([1.0 if s == 'e' else 0.0 for s in stt])
    y_notr = np.array([1.0 if s != 'r' else 0.0 for s in stt])
    for j, f in enumerate(PROXY_FEATS):
        a1, a2 = auc(Pt[:, j], y_e), auc(-Pt[:, j], y_notr)
        sep[f] = {
            'auc_e_vs_rest_test': round(a1, 3) if a1 is not None else None,
            'auc_notr_vs_r_test': round(a2, 3) if a2 is not None else None,
        }
    out['recovery']['single_feature'] = sep

    if not (args.cot_cal and args.cot_test):
        dest = os.path.join(TMP, f'proxy_sa_{args.tag}.json')
        with open(dest, 'w', encoding='utf-8') as fh:
            json.dump(out, fh, indent=1, ensure_ascii=False)
        print(f"[recovery-only mode] cal/test = {len(calp)}/{len(testp)}")
        print(f"  ARI cal={out['recovery']['ari_cal']}  test={out['recovery']['ari_test']}")
        print(f"  confusion(test, true->cluster): {out['recovery']['confusion_test']}")
        print('[written]', dest)
        return

    # --- verifier evaluation -------------------------------------------------
    def build(cot_rows, amap, plab):
        out2 = []
        for c in cot_rows:
            a = amap.get(c['idx'])
            if a is None:
                continue
            fk = feats_one(a, c, args.alpha_s)
            if fk is None:
                continue
            x, aero_pred, k = fk
            pf = proxy_feats_one(a, args.alpha_s)
            out2.append({'idx': c['idx'], 'x': x, 'pf': pf,
                         'st': stratum(c['idx']), 'plab': plab.get(c['idx'], -1),
                         'aero_pred': aero_pred, 'k': k,
                         'gold': gold_int(a),
                         'cot_correct': k == gold_int(a)})
        return out2

    plabc = dict(zip([r['idx'] for r in calp], list(lab_c)))
    plabt = dict(zip([r['idx'] for r in testp], list(lab_t)))
    cal = build(load(args.cot_cal), cal_a, plabc)
    test = build(load(args.cot_test), test_a, plabt)
    yc = np.array([1.0 if r['cot_correct'] else 0.0 for r in cal])
    Xc = np.array([r['x'] for r in cal])
    Xt = np.array([r['x'] for r in test])

    jN, jS = FEATS.index('N_gap'), FEATS.index('S_gap')
    bmc = np.array([[r['pf']['bmargin']] for r in cal])
    bmt = np.array([[r['pf']['bmargin']] for r in test])
    stc_ = np.array([r['st'] for r in cal])
    stt_ = np.array([r['st'] for r in test])
    plc_ = np.array([r['plab'] for r in cal])
    plt_ = np.array([r['plab'] for r in test])

    def design(rows_x, bmv, stratv, clustv):
        """Column dict: base FEATS + true/proxy/continuous interaction cols."""
        cols = {f: rows_x[:, j] for j, f in enumerate(FEATS)}
        for s in ('r', 'h', 'e'):
            cols[f'is_{s}'] = (stratv == s).astype(float)
        for f, j in (('N_gap', jN), ('S_gap', jS)):
            for s in ('r', 'h', 'e'):
                cols[f'{f}_{s}'] = rows_x[:, j] * (stratv == s)
        for c in (0, 1, 2):
            cols[f'pc_{c}'] = (clustv == c).astype(float)
        for f, j in (('N_gap', jN), ('S_gap', jS)):
            for c in (0, 1, 2):
                cols[f'{f}_pc{c}'] = rows_x[:, j] * (clustv == c)
        cols['N_gap_m'] = rows_x[:, jN] * bmv[:, 0]
        cols['S_gap_m'] = rows_x[:, jS] * bmv[:, 0]
        return cols

    Dc = design(Xc, bmc, stc_, plc_)
    Dt = design(Xt, bmt, stt_, plt_)

    SUBSETS = {
        # deployable candidates (cal-LOO selectable)
        'conf_only': ['cot_conf'],
        'full': FEATS,
        'CS':  ['cot_conf', 'betp_cot', 'N_gap', 'S_gap', 'N_gap_m', 'S_gap_m'],
        'CS_probe': ['betp_cot', 'N_gap', 'S_gap', 'N_gap_m', 'S_gap_m'],
        'PSA+S': ['cot_conf', 'betp_cot', 'pc_0', 'pc_1',
                  'N_gap_pc0', 'N_gap_pc1', 'N_gap_pc2',
                  'S_gap_pc0', 'S_gap_pc1', 'S_gap_pc2'],
        'PSA_probe': ['betp_cot', 'pc_0', 'pc_1',
                      'N_gap_pc0', 'N_gap_pc1', 'N_gap_pc2'],
        # leaky ceilings (NOT selectable; reference only)
        'SA+S_true': ['cot_conf', 'betp_cot', 'is_r', 'is_h',
                      'N_gap_r', 'N_gap_h', 'N_gap_e',
                      'S_gap_r', 'S_gap_h', 'S_gap_e'],
        'SA_probe_true': ['betp_cot', 'is_r', 'is_h',
                          'N_gap_r', 'N_gap_h', 'N_gap_e'],
    }
    LOO_CANDIDATES = ['conf_only', 'full', 'CS', 'CS_probe', 'PSA+S', 'PSA_probe']

    preds, accs = {}, {}
    for name, feats in SUBSETS.items():
        Xcs = np.column_stack([Dc[f] for f in feats])
        Xts = np.column_stack([Dt[f] for f in feats])
        mu, sd = Xcs.mean(0), Xcs.std(0) + 1e-9
        w, b = fit_logistic((Xcs - mu) / sd, yc, l2=args.l2)
        p = 1.0 / (1.0 + np.exp(-np.clip(((Xts - mu) / sd) @ w + b, -30, 30)))
        pr = [r['k'] if pi >= args.tau else r['aero_pred'] for r, pi in zip(test, p)]
        preds[name] = pr
        accs[name] = sum(1 for a, r in zip(pr, test) if a == r['gold']) / len(test)

    def mcm(a, b_):
        ca = [x == r['gold'] for x, r in zip(preds[a], test)]
        cb = [x == r['gold'] for x, r in zip(preds[b_], test)]
        bb, cc, pv = mcnemar(ca, cb)
        return {'acc_a': round(accs[a], 4), 'acc_b': round(accs[b_], 4),
                'discordant': [bb, cc],
                'p': round(pv, 5) if pv is not None else None}

    out['test_acc_by_subset'] = {k: round(v, 4) for k, v in accs.items()}
    out['pairwise_at_tau'] = {
        'CS_vs_conf_only': mcm('CS', 'conf_only'),
        'CS_vs_full': mcm('CS', 'full'),
        'PSA+S_vs_conf_only': mcm('PSA+S', 'conf_only'),
        'CS_vs_PSA+S': mcm('CS', 'PSA+S'),
        'CS_vs_SA+S_true': mcm('CS', 'SA+S_true'),
        'PSA+S_vs_SA+S_true': mcm('PSA+S', 'SA+S_true'),
        'CS_probe_vs_SA_probe_true': mcm('CS_probe', 'SA_probe_true'),
    }

    # honest cal-LOO selection among deployable candidates only
    loo = {}
    for name in LOO_CANDIDATES:
        Xcs = np.column_stack([Dc[f] for f in SUBSETS[name]])
        p_loo = loo_probs(Xcs, yc, args.l2)
        pr = [r['k'] if pi >= args.tau else r['aero_pred'] for r, pi in zip(cal, p_loo)]
        loo[name] = round(sum(1 for a, r in zip(pr, cal) if a == r['gold']) / len(cal), 4)
    loo_pick = max(LOO_CANDIDATES, key=lambda k: (loo[k], -len(SUBSETS[k])))
    out['cal_LOO_acc_by_subset'] = loo
    out['loo_pick'] = {'subset': loo_pick, 'feats': SUBSETS[loo_pick],
                       'test_acc': round(accs[loo_pick], 4)}
    ca = [x == r['gold'] for x, r in zip(preds[loo_pick], test)]
    bb, cc, pv = mcnemar(ca, [r['cot_correct'] for r in test])
    fl = sum(1 for x, r in zip(preds[loo_pick], test) if x != r['k'])
    gd = sum(1 for x, r in zip(preds[loo_pick], test) if x != r['k'] and x == r['gold'])
    # 2026-10-15 fix: bad_flips was `fl - gd`, which wrongly counted both-wrong
    # answer changes as bad. True bad = broke a correct CoT answer; neutral =
    # both wrong, answer changed (contributes nothing to McNemar discordance).
    bd = sum(1 for x, r in zip(preds[loo_pick], test)
             if x != r['k'] and x != r['gold'] and r['cot_correct'])
    assert (gd, bd) == (bb, cc), f'flip accounting != McNemar discordant {(bb, cc)}'
    out['loo_pick_vs_cot'] = {'discordant': [bb, cc],
                              'mcnemar_p': round(pv, 5) if pv is not None else None,
                              'flips': fl, 'good_flips': gd, 'bad_flips': bd,
                              'neutral_flips': fl - gd - bd}

    # refs: loo_pick + CS vs baselines
    compare = {'loo_pick': preds[loo_pick], 'CS': preds['CS'],
               'PSA+S': preds['PSA+S']}
    refs = {}
    for spec in args.refs:
        name, path = spec.split('=', 1)
        rows = load(path)
        pm = {r['idx']: pred_int(r) for r in rows}
        vals = [pm.get(r['idx']) for r in test]
        if any(v is None for v in vals):
            print(f'[warn] {name}: incomplete overlap, skipped')
            continue
        corr = [v == r['gold'] for v, r in zip(vals, test)]
        entry = {'acc': round(sum(corr) / len(corr), 4)}
        for lbl, pr in compare.items():
            ca = [p == r['gold'] for p, r in zip(pr, test)]
            bb, cc, pv = mcnemar(ca, corr)
            entry[lbl] = {'discordant': [bb, cc],
                          'mcnemar_p': round(pv, 5) if pv is not None else None}
        refs[name] = entry
    out['vs_refs'] = refs

    dest = os.path.join(TMP, f'proxy_sa_{args.tag}.json')
    with open(dest, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    print(f"n(cal/test) = {len(cal)}/{len(test)}  tau={args.tau}  seed={args.seed}")
    print('--- proxy recovery ---')
    print(f"  ARI cal={out['recovery']['ari_cal']} test={out['recovery']['ari_test']}")
    print(f"  test confusion (true->cluster): {out['recovery']['confusion_test']}")
    print('--- acc by subset (test) ---')
    for k, v in accs.items():
        tag_ = '' if k in LOO_CANDIDATES else '  [leaky ceiling]'
        loo_v = f" calLOO {loo[k]:.4f}" if k in LOO_CANDIDATES else ''
        print(f"  {k:16s} {v:.4f}{loo_v}{tag_}")
    lp = out['loo_pick_vs_cot']
    print(f"LOO pick: {loo_pick} -> test {accs[loo_pick]:.4f} | vs CoT "
          f"p={lp['mcnemar_p']} (good {lp['good_flips']}/bad {lp['bad_flips']})")
    print('--- pairwise McNemar at tau ---')
    for k, v in out['pairwise_at_tau'].items():
        print(f"  {k}: {v['acc_a']:.4f} vs {v['acc_b']:.4f}  "
              f"discordant {v['discordant']}  p={v['p']}")
    for name, r in refs.items():
        parts = ', '.join(f"{lbl} p={r[lbl]['mcnemar_p']}" for lbl in compare)
        print(f"  vs {name} (acc {r['acc']:.4f}): {parts}")
    print('[written]', dest)


if __name__ == '__main__':
    main()
