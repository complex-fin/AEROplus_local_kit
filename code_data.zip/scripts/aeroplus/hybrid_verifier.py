#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Hybrid system: AERO+ probes as a VERIFIER on top of CoT answers.

Motivation (v4 results, 2026-10-13): probe signals detect CoT errors with
AUC 0.93 (H5) but the standalone fusion answer is at parity with CoT
(0.764 vs 0.760, n.s.). The information is in the probes; the standalone
decision layer wastes it. This script tests the complementary composition:

    final(item) = CoT answer        if P(CoT correct | probes, conf) >= tau
                = AERO+ (plainds)   otherwise

Fit: L2 logistic verifier on the CALIBRATION split only (same discipline as
the Mondrian layer -- no peeking). Eval: TEST split, McNemar vs CoT and vs
optional reference systems (selfcons etc.).

Also reports: rule-based gate (no learning), tau grid, oracle upper bound.

Usage:
  python3 scripts/aeroplus/hybrid_verifier.py --tag ecare-v4 \
      --aero-cal tmp/results_aeroplus_cal_v3.jsonl \
      --aero-test tmp/results_aero_exp.jsonl \
      --cot-cal  tmp/results_cot_cal_v3.jsonl \
      --cot-test tmp/results_cot_exp.jsonl \
      [--ref name=path ...] [--alpha-s 1.5]
Writes tmp/hybrid_<tag>.json
"""
import argparse
import json
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
import fusion
from stats_tests import mcnemar_exact

TMP = None  # set in main

FEATS = ['cot_conf', 'agree', 'betp_cot', 'betp_max', 'betp_margin',
         'N_gap', 'S_gap', 'f_gap', 'K']


def load(path):
    if not os.path.exists(path):
        raise SystemExit(f'[missing] {path}')
    out = []
    for l in open(path, encoding='utf-8'):
        l = l.strip()
        if l:
            try:
                out.append(json.loads(l))
            except json.JSONDecodeError:
                pass
    return out


def pred_int(r):
    """CoT/baseline pred '1'/'2'/'3' -> class 1/2/0 (3 = neither -> C0)."""
    try:
        p = int(r.get('pred'))
    except (TypeError, ValueError):
        return None
    return 0 if p == 3 else p


def gold_int(r):
    g = int(r['gold'])
    return 0 if g == 3 else g


def feats_one(aero_rec, cot_rec, alpha_s):
    """Feature vector for 'is the CoT answer correct?' (see FEATS)."""
    src = fusion.extract_sources(aero_rec, alpha_s)
    f = fusion.fuse(aero_rec, 'plainds', None, alpha_s)
    betp = f['betp']
    k = pred_int(cot_rec)
    if k is None:
        return None
    conf = float(cot_rec.get('conf') or 0.5)
    conf = min(1.0, max(0.0, conf))
    aero_pred = max(betp, key=betp.get)
    N1, N2 = src['N'].get(1, 0.5), src['N'].get(2, 0.5)
    S1, S2 = src['S'].get(1, 0.5), src['S'].get(2, 0.5)
    f1, f2 = src['f'].get(1, 0.5), src['f'].get(2, 0.5)
    # for cot answer k: support of the chosen candidate vs the other
    if k in (1, 2):
        n_gap = (N1 if k == 1 else N2) - (N2 if k == 1 else N1)
        s_gap = (S1 if k == 1 else S2) - (S2 if k == 1 else S1)
        f_gap = (f1 if k == 1 else f2) - (f2 if k == 1 else f1)
    else:  # k == 0 (CoT said 'neither'): support = how weak BOTH candidates are
        n_gap, s_gap, f_gap = -max(N1, N2), -max(S1, S2), -max(f1, f2)
    betp_max = max(betp.values())
    return [conf,
            1.0 if aero_pred == k else 0.0,
            betp.get(k, 0.0),
            betp_max,
            betp_max - betp.get(k, 0.0),
            n_gap, s_gap, f_gap,
            f['K']], aero_pred, k


def fit_logistic(X, y, l2=1.0, iters=50):
    """Newton-IRLS L2 logistic; X standardized outside."""
    n, d = X.shape
    w = np.zeros(d)
    b = 0.0
    for _ in range(iters):
        z = X @ w + b
        p = 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
        g_w = X.T @ (p - y) / n + (l2 / n) * w   # normalized consistently with H
        g_b = np.mean(p - y)
        W = np.clip(p * (1 - p), 1e-6, None)
        H = (X.T * W) @ X / n + (l2 / n) * np.eye(d)
        try:
            dw = np.linalg.solve(H, g_w)
        except np.linalg.LinAlgError:
            break
        w -= dw
        b -= g_b / max(np.mean(W), 1e-6)
        if np.max(np.abs(dw)) < 1e-8:
            break
    return w, b


def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


def acc(rows):
    return sum(1 for r in rows if r['hyb_correct']) / max(len(rows), 1)


def mcnemar(a, b):
    """a, b: lists of bool (correct?) over the SAME items."""
    bb = sum(1 for x, y in zip(a, b) if x and not y)
    cc = sum(1 for x, y in zip(a, b) if y and not x)
    return bb, cc, mcnemar_exact(bb, cc)


def main():
    global TMP
    ap = argparse.ArgumentParser()
    ap.add_argument('--tag', default='ecare-v4')
    ap.add_argument('--aero-cal', required=True)
    ap.add_argument('--aero-test', required=True)
    ap.add_argument('--cot-cal', required=True)
    ap.add_argument('--cot-test', required=True)
    ap.add_argument('--refs', nargs='*', default=[],
                    help="extra baselines name=path (e.g. selfcons=tmp/results_selfcons_exp.jsonl)")
    ap.add_argument('--alpha-s', type=float, default=1.5)
    ap.add_argument('--l2', type=float, default=1.0)
    ap.add_argument('--tau-mode', choices=['fixed', 'loo'], default='fixed',
                    help="fixed: pre-registered tau (default 0.5, Bayes-style "
                         "0-1-loss rule; immune to selection critique). "
                         "loo: cal-LOO selection with 1-SE conservative rule "
                         "(prefers FEWER flips; needs a large cal set).")
    ap.add_argument('--tau', type=float, default=0.5,
                    help='tau value for --tau-mode fixed')
    ap.add_argument('--only-feats', default=None,
                    help='comma-separated subset of features (ablation), e.g. "cot_conf" '
                         'for conf-only verifier, or "agree,betp_cot,N_gap,S_gap,f_gap,K" '
                         'for probes-only. Default: all.')
    args = ap.parse_args()

    feat_idx = list(range(len(FEATS)))
    if args.only_feats:
        keep = [f.strip() for f in args.only_feats.split(',') if f.strip()]
        bad = [f for f in keep if f not in FEATS]
        if bad:
            raise SystemExit(f'[unknown feats] {bad}; available: {FEATS}')
        feat_idx = [FEATS.index(f) for f in keep]
        if not feat_idx:
            raise SystemExit('[empty feature subset]')

    TMP = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), 'tmp')

    def build(cot_rows, aero_rows):
        amap = {r['idx']: r for r in aero_rows}
        out = []
        for c in cot_rows:
            a = amap.get(c['idx'])
            if a is None:
                continue
            fk = feats_one(a, c, args.alpha_s)
            if fk is None:
                continue
            (x, aero_pred, k) = fk
            out.append({'idx': c['idx'], 'x': x, 'k': k, 'aero_pred': aero_pred,
                        'gold': gold_int(a),
                        'cot_correct': k == gold_int(a),
                        'aero_correct': aero_pred == gold_int(a)})
        return out

    cal = build(load(args.cot_cal), load(args.aero_cal))
    test = build(load(args.cot_test), load(args.aero_test))
    if len(cal) < 20:
        raise SystemExit(f'[cal too small] {len(cal)} items -- need >= 20')
    if len(test) < 30:
        raise SystemExit(f'[test too small] {len(test)} items')

    Xc = np.array([[r['x'][j] for j in feat_idx] for r in cal])
    yc = np.array([1.0 if r['cot_correct'] else 0.0 for r in cal])
    mu, sd = Xc.mean(0), Xc.std(0) + 1e-9
    w, b = fit_logistic((Xc - mu) / sd, yc, l2=args.l2)

    Xt = np.array([[r['x'][j] for j in feat_idx] for r in test])
    p_hat = sigmoid(((Xt - mu) / sd) @ w + b)
    for r, p in zip(test, p_hat):
        r['p_cot'] = float(p)

    TAUS = (0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85)
    cal_tau = {}

    if args.tau_mode == 'fixed':
        # pre-registered operating point: flip only when the verifier believes
        # CoT is more likely wrong than right (0-1 loss Bayes-style rule).
        tau_star = args.tau
    else:
        # --- LOO selection on CAL with 1-SE conservative rule --------------
        # 60-item cal cannot resolve tau (grid diffs = 1 item of noise): the
        # 1-SE rule prefers the FEWER-flips (lower tau) candidate within
        # 1 SE of the cal optimum -- never the aggressive edge.
        p_loo = np.zeros(len(cal))
        for i in range(len(cal)):
            m = np.ones(len(cal), dtype=bool)
            m[i] = False
            Xi, yi = Xc[m], yc[m]
            mi, si = Xi.mean(0), Xi.std(0) + 1e-9
            wl, bl = fit_logistic((Xi - mi) / si, yi, l2=args.l2)
            p_loo[i] = sigmoid(((Xc[i] - mi) / si) @ wl + bl)
        for tau in TAUS:
            keep = p_loo >= tau
            preds = [r['k'] if k else r['aero_pred'] for r, k in zip(cal, keep)]
            cal_tau[tau] = sum(1 for p, r in zip(preds, cal) if p == r['gold']) / len(cal)
        best = max(cal_tau.values())
        se = math.sqrt(best * (1 - best) / len(cal))
        cands = [t for t in TAUS if cal_tau[t] >= best - se]
        tau_star = min(cands)  # conservative: fewest flips within 1 SE

    # --- test evaluation at tau_star; full grid kept as DIAGNOSTIC only ---
    grid = {}
    for tau in TAUS:
        for r in test:
            use_cot = r['p_cot'] >= tau
            r['hy_pred'] = r['k'] if use_cot else r['aero_pred']
            r['hyb_correct'] = r['hy_pred'] == r['gold']
        flips = sum(1 for r in test if r['hy_pred'] != r['k'])
        good = sum(1 for r in test if r['hy_pred'] != r['k'] and r['hyb_correct'])
        bad = flips - good
        cot_c = [r['cot_correct'] for r in test]
        hyb_c = [r['hyb_correct'] for r in test]
        bb, cc, pv = mcnemar(hyb_c, cot_c)
        grid[tau] = {'acc_hybrid': round(acc(test), 4), 'flips': flips,
                     'good_flips': good, 'bad_flips': bad,
                     'vs_cot_mcnemar_p': round(pv, 5) if pv is not None else None}
    test_best_tau = max(grid, key=lambda t: grid[t]['acc_hybrid'])  # diagnostic only

    for r in test:  # final operating point (tau_star chosen on cal LOO)
        use_cot = r['p_cot'] >= tau_star
        r['hy_pred'] = r['k'] if use_cot else r['aero_pred']
        r['hyb_correct'] = r['hy_pred'] == r['gold']

    # --- references --------------------------------------------------------
    refs = {}
    for spec in args.refs:
        name, path = spec.split('=', 1)
        rows = load(path)
        rmap = {r['idx']: pred_int(r) for r in rows}
        preds = [rmap.get(r['idx']) for r in test]
        if any(p is None for p in preds):
            print(f'[warn] {name}: incomplete overlap, skipped')
            continue
        corr = [p == r['gold'] for p, r in zip(preds, test)]
        refs[name] = {'acc': round(sum(corr) / len(corr), 4)}
        bb, cc, pv = mcnemar([r['hyb_correct'] for r in test], corr)
        refs[name].update({'discordant': [bb, cc],
                           'mcnemar_p': round(pv, 5) if pv is not None else None})

    # rule gate (no learning): flip when disagree AND betp_max > cot conf
    cot_conf = [r['x'][0] for r in test]
    rule_correct = []
    for r, cf in zip(test, cot_conf):
        f = fusion.fuse  # noqa (features already contain what we need)
        betp_max = r['x'][3]
        agree = r['x'][1]
        rule_correct.append(r['cot_correct'] or (not agree and betp_max > cf and r['aero_correct']))
    rule_acc = sum(rule_correct) / len(rule_correct)

    oracle = sum(1 for r in test if r['cot_correct'] or r['aero_correct']) / len(test)

    feats_used = [FEATS[j] for j in feat_idx]
    out = {
        'tag': args.tag, 'n_cal': len(cal), 'n_test': len(test),
        'feats_used': feats_used, 'l2': args.l2,
        'tau_mode': args.tau_mode,
        'tau_selection': ('pre-registered fixed tau (Bayes-style 0-1-loss rule)'
                          if args.tau_mode == 'fixed'
                          else 'cal-LOO with 1-SE conservative rule (fewer flips)'),
        'acc_cot': round(sum(r['cot_correct'] for r in test) / len(test), 4),
        'acc_aero_plains': round(sum(r['aero_correct'] for r in test) / len(test), 4),
        'acc_hybrid_tau_star': round(acc(test), 4), 'tau_star': tau_star,
        'tau_grid_cal_LOO': {str(t): round(v, 4) for t, v in cal_tau.items()},
        'test_best_tau_diagnostic': {'tau': test_best_tau, 'acc': grid[test_best_tau]['acc_hybrid']},
        'coef_std': dict(zip(feats_used, [round(float(x), 3) for x in w])),
        'intercept': round(float(b), 3),
        'acc_rule_gate': round(rule_acc, 4),
        'oracle_upper_bound': round(oracle, 4),
        'tau_grid_diagnostic': grid, 'refs': refs,
    }
    dest = os.path.join(TMP, f'hybrid_{args.tag}.json')
    with open(dest, 'w', encoding='utf-8') as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)

    print(f"n(cal/test) = {len(cal)}/{len(test)}   tau* = {tau_star}")
    print(f"CoT {out['acc_cot']:.3f}  AERO+(plainds) {out['acc_aero_plains']:.3f}  "
          f"HYBRID {out['acc_hybrid_tau_star']:.3f}  rule-gate {rule_acc:.3f}  "
          f"oracle {out['oracle_upper_bound']:.3f}")
    g = grid[tau_star]
    print(f"flips: {g['flips']} (good {g['good_flips']} / bad {g['bad_flips']}), "
          f"McNemar vs CoT p={g['vs_cot_mcnemar_p']}")
    for name, r in refs.items():
        print(f"vs {name}: acc {r['acc']:.3f}, McNemar p={r['mcnemar_p']}")
    print('[written]', dest)


if __name__ == '__main__':
    main()
