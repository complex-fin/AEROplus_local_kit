#!/usr/bin/env python3
"""AERO+ offline pipeline: raw LLM outputs -> fusion -> calibration -> conformal -> report.

Modes (auto-detected):
  FULL      : calibration raw records available (>= 20) -> gammas, (a,b,b3),
              Mondrian quantiles fitted on cal; evaluated on test.
  INTERIM   : no cal yet -> in-sample fit on available test records, every
              number marked EXPLORATORY (smoke validation of the pipeline only).

Derives from one raw collection: aeroplus_full / _nocf / _nods / _plainds.
Loads baselines (zeroshot, cot, legacy aero_nocf, cf_cot) where present.
Writes: tmp/aeroplus_analysis/report.md + metrics.json
"""
import json, math, os, sys
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np
import config as C
import fusion, calibration, conformal, validity

def load(path):
    if not os.path.exists(path):
        return []
    out = []
    for l in open(path,encoding="utf-8"):
        l = l.strip()
        if l:
            try:
                out.append(json.loads(l))
            except json.JSONDecodeError:
                pass
    return out

def gold_int(r):
    """gold '1'/'2' -> class 1/2 ; gold '3' (neither) -> class 0 (C0 on the frame)."""
    g = int(r['gold'])
    return 0 if g == 3 else g

def mcnemar_exact(b, c):
    """Exact binomial p for McNemar test (b, c = discordant counts)."""
    n = b + c
    if n == 0:
        return None
    from math import comb
    k = min(b, c)
    p = sum(comb(n, i) for i in range(0, k + 1)) / 2 ** n
    return min(1.0, 2 * p)

def brier(xs, ys):
    return sum((x - y) ** 2 for x, y in zip(xs, ys)) / max(len(xs), 1)

def logloss(xs, ys):
    xs = [min(max(x, 1e-6), 1 - 1e-6) for x in xs]
    return -sum(y * math.log(x) + (1 - y) * math.log(1 - x) for x, y in zip(xs, ys)) / max(len(xs), 1)

# ---------------------------------------------------------------- main
def main():
    import argparse
    from datasets import get as get_dataset
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', default='ecare', choices=['ecare', 'copa', 'finsoc'],
                    help='which adapter supplies raw-output paths and the pi mix')
    ap.add_argument('--raw', default=None, help='override test raw-output path (e.g. synthetic data)')
    ap.add_argument('--cal', default=None, help='override calibration raw-output path')
    ap.add_argument('--tag', default=None, help='report filename tag (default: dataset name)')
    args = ap.parse_args()
    ds = get_dataset(args.dataset)
    raw_cal_path, raw_test_path = ds.raw_outputs()
    if args.raw:
        raw_test_path = args.raw
    if args.cal:
        raw_cal_path = args.cal
    pi_real, pi_neg = ds.pi_real, ds.pi_neg

    out_dir = C.ANALYSIS_DIR if args.tag is None else C.TMP / f'aeroplus_analysis_{args.tag}'
    os.makedirs(out_dir, exist_ok=True)
    raw_test = load(raw_test_path)
    raw_cal = load(raw_cal_path)
    # legacy aero records (old prompt) can bootstrap the pipeline demo
    legacy = load(C.TMP / 'results_aero.jsonl')
    if not raw_test:
        raw_test, legacy_mode = legacy, True
    else:
        legacy_mode = False
    cal = raw_cal if len(raw_cal) >= 20 else []

    mode = 'FULL' if cal else 'INTERIM'
    fit_recs = cal if cal else raw_test     # in-sample fallback

    # ---------------- stage 1: hyperparameters (beta, alpha_s) ----------------
    if cal:
        best = None
        for beta in C.BETA_GRID:
            gam, _ = fusion.estimate_gammas(cal, beta)
            for a_s in C.ALPHA_S_GRID:
                errs = []
                for r in cal:
                    f = fusion.fuse(r, 'full', gammas=gam, alpha_s=a_s)
                    errs.append((f['betp'][gold_int(r)] - 1) ** 2)
                e = sum(errs) / len(errs)
                if best is None or e < best[0]:
                    best = (e, beta, a_s, gam)
        _, beta, alpha_s, gammas = best
        rho = fusion.estimate_gammas(cal, beta)[1]
    else:
        beta, alpha_s = 0.5, 1.0
        gammas, rho = fusion.estimate_gammas(fit_recs, beta)

    # ---------------- stage 2: fuse cal + fit calibration ----------------
    def fuse_all(recs, variant):
        return {r['idx']: fusion.fuse(r, variant, gammas=gammas, alpha_s=alpha_s) for r in recs}

    fused_fit = fuse_all(fit_recs, 'full')
    betps_ks = [(f['betp'], f['K'], gold_int(r)) for r, f in
                zip(fit_recs, (fused_fit[r['idx']] for r in fit_recs))]
    theta = calibration.fit(betps_ks)
    c_fun = lambda betp, K, k: calibration.predict(theta, betp, K, k)

    # ---------------- stage 3: conformal ----------------
    if cal:
        cal_scores = [(gold_int(r), 1 - c_fun(f['betp'], f['K'], gold_int(r)))
                      for r in fit_recs for f in [fused_fit[r['idx']]]]
    else:
        # leave-one-out scores (still not fully honest; interim only)
        cal_scores = []
        for i, r in enumerate(fit_recs):
            sub = betps_ks[:i] + betps_ks[i + 1:]
            th = calibration.fit(sub)
            f = fused_fit[r['idx']]
            cal_scores.append((gold_int(r), 1 - calibration.predict(th, f['betp'], f['K'], gold_int(r))))

    cal_decisions = []
    for r in fit_recs:
        f = fused_fit[r['idx']]
        c_x = {k: c_fun(f['betp'], f['K'], k) for k in (1, 2, 0)}
        cal_decisions.append((r, f, c_x))

    def apply_alpha(alpha):
        q = conformal.mondrian_quantiles(cal_scores, alpha)
        rows = []
        for r, f, c_x in cal_decisions:
            d = conformal.decide(f['betp'], c_x, q)
            rows.append({'y': gold_int(r), 'pred': d['pred'], 'abstain': d['abstain'],
                         'type_real': r['type'] == 'real'})
        return rows

    tbl = {a: conformal.risk_on_cal(apply_alpha(a), [a], C.LAMBDA_MISS, C.LAMBDA_OVER,
                                    C.LAMBDA_ABS, pi_real, pi_neg)[a] for a in C.ALPHA_GRID}
    alpha_star = min(tbl, key=lambda a: tbl[a]['risk'])

    # ---------------- stage 4: derive variants on TEST ----------------
    variants = ['full', 'plainds', 'nocf', 'nods']
    fused_test = {v: fuse_all(raw_test, v) for v in variants}

    def final_rows(variant):
        q = conformal.mondrian_quantiles(cal_scores, alpha_star)
        rows = []
        for r in raw_test:
            f = fused_test[variant][r['idx']]
            c_x = {k: c_fun(f['betp'], f['K'], k) for k in (1, 2, 0)}
            d = conformal.decide(f['betp'], c_x, q)
            rows.append({'idx': r['idx'], 'type': r['type'], 'y': gold_int(r),
                         'pred': d['pred'], 'abstain': d['abstain'], 'corrected': d['corrected'],
                         'betp': f['betp'], 'K': f['K'], 'rule': f['rule'],
                         'c': c_x})
        return rows

    sysrows = {v: final_rows(v) for v in variants}

    # ---------------- stage 5: baselines ----------------
    baselines = {}
    for name, path in [('zero-shot', C.TMP / 'results_zeroshot.jsonl'),
                       ('CoT', C.TMP / 'results_cot.jsonl'),
                       ('aero_nocf(v1)', C.TMP / 'results_aero_nocf.jsonl'),
                       ('CF-CoT proxy', C.CFCOT)]:
        recs = [r for r in load(path) if r.get('pred') in ('1', '2', '3')]
        if recs:
            baselines[name] = recs

    # ---------------- report helpers ----------------
    def system_metrics(rows):
        n = len(rows); acc = miss = over = absr = absn = corr = 0
        n_real = sum(1 for r in rows if r['type'] == 'real')
        n_neg = n - n_real
        for r in rows:
            real = r['type'] == 'real'
            if r['abstain']:
                absr += real; absn += not real
            elif r['pred'] == r['y']:
                acc += 1; corr += 1
            else:
                miss += real; over += not real
        cov_rows = [r for r in rows if not r['abstain']]
        return {
            'n': n, 'acc': acc / max(n, 1),
            'coverage': len(cov_rows) / max(n, 1),
            'miss_rate': miss / max(n_real, 1), 'overclaim_rate': over / max(n_neg, 1),
            'abs_real': absr / max(n_real, 1), 'abs_neg': absn / max(n_neg, 1),
            'risk': pi_real * (C.LAMBDA_MISS * miss / max(n_real, 1) + C.LAMBDA_ABS * absr / max(n_real, 1))
                  + pi_neg * (C.LAMBDA_OVER * over / max(n_neg, 1) + C.LAMBDA_ABS * absn / max(n_neg, 1)),
            'n_real': n_real, 'n_neg': n_neg,
        }

    # ---------------- hypothesis tests ----------------
    hyp = {}

    # H5: probe AUC on raw test records
    if raw_test:
        for nm, fn in [('N', lambda r, k, hk: r['N'][hk]), ('S', lambda r, k, hk: r['S'][hk]),
                       ('(N+S)/2', lambda r, k, hk: (r['N'][hk] + r['S'][hk]) / 2)]:
            a0, lo, hi = validity.cluster_bootstrap_ci(raw_test, fn)
            Xl, yl, _ = validity.edge_labels(raw_test)(fn)
            pp = validity.exact_perm_pvalue(Xl, yl)
            hyp[f'H5 {nm}'] = {'auc': round(a0, 3), 'ci': [round(lo, 3), round(hi, 3)],
                               'perm_p': round(pp, 4) if pp is not None else None}

    # H6: belief-edge AUC full vs plainds vs nods (paired)
    if raw_test:
        def mk(v):
            return lambda r, k, hk: fused_test[v][r['idx']]['betp'][k]
        for other in ('plainds', 'nods'):
            d0, lo, hi = validity.paired_bootstrap_diff(raw_test, mk('full'), mk(other))
            hyp[f'H6 full vs {other}'] = {'dAUC': round(d0, 3), 'ci': [round(lo, 3), round(hi, 3)]}
        for v in ('full', 'plainds', 'nods'):
            a0, lo, hi = validity.cluster_bootstrap_ci(raw_test, mk(v))
            hyp[f'H6 AUC {v}'] = {'auc': round(a0, 3), 'ci': [round(lo, 3), round(hi, 3)]}

    # H1: overclaim full vs nocf on negatives (McNemar, same raw records -> paired)
    neg = [r for r in raw_test if r['type'] != 'real']
    if neg:
        row_by_idx = {r['idx']: i for i, r in enumerate(raw_test)}
        b = c_ = 0
        for r in neg:
            o_full = sysrows['full'][row_by_idx[r['idx']]]
            o_nocf = sysrows['nocf'][row_by_idx[r['idx']]]
            # overclaim = answered 1/2 on a negative item (abstain or 3 = no overclaim)
            of = 0 if (o_full['abstain'] or o_full['pred'] == 0) else 1
            on = 0 if (o_nocf['abstain'] or o_nocf['pred'] == 0) else 1
            if of and not on: b += 1
            if on and not of: c_ += 1
        over = lambda rows, idx: (0 if (rows[row_by_idx[idx]]['abstain'] or
                                        rows[row_by_idx[idx]]['pred'] == 0) else 1)
        hyp['H1 full vs nocf (negatives)'] = {
            'over_full': sum(over(sysrows['full'], r['idx']) for r in neg),
            'over_nocf': sum(over(sysrows['nocf'], r['idx']) for r in neg),
            'discordant': [b, c_], 'mcnemar_p': mcnemar_exact(b, c_)}

    # H4: Brier/logloss raw BetP* vs calibrated c(., y) on test
    if raw_test:
        raw_c, cal_c, ok = [], [], []
        for r, row in zip(raw_test, sysrows['full']):
            y = gold_int(r)
            raw_c.append(row['betp'][y]); cal_c.append(row['c'][y]); ok.append(1.0 if row['pred'] == y else 0.0)
        hyp['H4'] = {'brier_betp': round(brier(raw_c, ok), 3),
                     'brier_cal': round(brier(cal_c, ok), 3),
                     'logloss_betp': round(logloss(raw_c, ok), 3),
                     'logloss_cal': round(logloss(cal_c, ok), 3)}

    # H3: empirical coverage vs 1 - alpha on test
    if raw_test:
        cov_tbl = {}
        q_by_a = {a: conformal.mondrian_quantiles(cal_scores, a) for a in C.ALPHA_GRID}
        for a in C.ALPHA_GRID:
            q = q_by_a[a]; cov = 0; n_cov = 0; nset = 0
            for r in raw_test:
                f = fused_test['full'][r['idx']]
                c_x = {k: c_fun(f['betp'], f['K'], k) for k in (1, 2, 0)}
                ps = conformal.predict_set(c_x, q)
                if ps:
                    n_cov += 1
                    nset += len(ps)
                    cov += (gold_int(r) in ps)
            cov_tbl[a] = {'empirical_cov': round(cov / max(n_cov, 1), 3),
                          'target': round(1 - a, 2),
                          'mean_set_size': round(nset / max(n_cov, 1), 2),
                          'abstain_rate': round(1 - n_cov / max(len(raw_test), 1), 3)}
        hyp['H3'] = cov_tbl

    # H7: LR test for b3 (cal only)
    if cal:
        chi2, df, p, th0, th1 = calibration.h7_lr_test(betps_ks)
        hyp['H7'] = {'chi2': round(chi2, 3), 'p': round(p, 4),
                     'b3': round(float(th1[3]), 3) if len(th1) > 3 else None}

    # ---------------- assemble report ----------------
    L = []
    L.append('# AERO+ 实验报告（自动生成）\n')
    ds_label = args.dataset if not (args.raw or args.cal) else 'custom'
    L.append(f'- 模式：**{mode}**' + ('（校准集已拟合，检验有效）' if mode == 'FULL'
        else '（尚无校准集数据——超参与校准为**样本内/LOO 拟合**，全部数字仅作管线冒烟，不构成假设检验）'))
    L.append(f'- 原始记录：test {len(raw_test)} 条' + (f'（legacy 旧prompt）' if legacy_mode else '')
             + f'；cal {len(cal)} 条')
    L.append(f'- 超参：beta={beta}, alpha_s={alpha_s}, gamma={ {k: round(v, 3) for k, v in gammas.items()} }')
    if rho:
        L.append(f'- 源相关（校准集）：{rho}')
    L.append(f'- 校准参数 theta={ [round(float(t), 3) for t in theta] } (z1, z2, c0, b3)')
    L.append(f'- alpha* = {alpha_star}（λ-风险最优）\n')

    L.append('## 系统对比（测试项）\n')
    L.append('| 系统 | n | acc | coverage | miss | overclaim | abstain(real) | abstain(neg) | λ-risk |')
    L.append('|---|---|---|---|---|---|---|---|---|')
    for v in variants:
        m = system_metrics(sysrows[v])
        L.append(f"| AERO+ {v} | {m['n']} | {m['acc']:.2f} | {m['coverage']:.2f} | "
                 f"{m['miss_rate']:.2f} | {m['overclaim_rate']:.2f} | {m['abs_real']:.2f} | "
                 f"{m['abs_neg']:.2f} | {m['risk']:.3f} |")
    idxs = {r['idx'] for r in raw_test}
    for name, recs in baselines.items():
        sub = [r for r in recs if r['idx'] in idxs and r.get('pred') in ('1', '2', '3')]
        if not sub:
            continue
        n = len(sub); n_real = sum(1 for r in sub if r['type'] == 'real'); n_neg = n - n_real
        acc = sum(1 for r in sub if int(r['pred']) == int(r['gold']))
        miss = sum(1 for r in sub if r['type'] == 'real' and int(r['pred']) != int(r['gold']))
        over = sum(1 for r in sub if r['type'] != 'real' and int(r['pred']) != 3)
        risk = pi_real * C.LAMBDA_MISS * miss / max(n_real, 1) + pi_neg * C.LAMBDA_OVER * over / max(n_neg, 1)
        L.append(f"| {name} | {n} | {acc / n:.2f} | 1.00 | {miss / max(n_real, 1):.2f} | "
                 f"{over / max(n_neg, 1):.2f} | 0.00 | 0.00 | {risk:.3f} |")

    L.append('\n（基线无弃权——λ-risk 不含弃权代价；AERO+ 的公平比较需基线校准集运行后另行报告）\n')

    # SOTA / published-baseline comparison (honest: pending citations render as such)
    try:
        import sota
        rows_ours = [{'dataset': f'{ds_label} ({mode})', 'system': f'AERO+ {v}',
                      'value': round(system_metrics(sysrows[v])['acc'], 3)} for v in variants]
        L.append('## 与已发表基线/SOTA 对比\n')
        L.append(sota.render(rows_ours))
        L.append('\n（value=null 的行是占位——引用核实后回填 download/baselines_published.json，禁止估计填数）\n')
    except Exception as e:
        L.append(f'(SOTA table unavailable: {e})\n')

    L.append('## 假设检验\n```json')
    L.append(json.dumps(hyp, indent=1, ensure_ascii=False))
    L.append('```\n')

    L.append('## α 网格上的校准集风险\n')
    L.append('| α | risk | miss | over | abs(real) | abs(neg) | coverage |')
    L.append('|---|---|---|---|---|---|---|')
    for a in C.ALPHA_GRID:
        t = tbl[a]
        L.append(f"| {a:.2f} | {t['risk']:.3f} | {t['miss']:.2f} | {t['over']:.2f} | "
                 f"{t['abs_real']:.2f} | {t['abs_neg']:.2f} | {t['coverage']:.2f} |")

    # per-item predictions (variant=full) for downstream paired stats (stats_v4)
    # semantics: y = gold int; pred = final decision (0 if abstain); abstain flag;
    # correct = (abstain and gold==3) or (not abstain and pred==gold)
    # -- abstaining on a negative is a correct rejection, on a real item a miss.
    with open(C.TMP / f'preds_{args.tag or "report"}.jsonl', 'w') as f:
        for r in sysrows['full']:
            y = r['y']
            p = 0 if (r['abstain'] or r['pred'] in (None, 0)) else int(r['pred'])
            correct = (y == 3) if r['abstain'] else (p == y)
            f.write(json.dumps({'idx': r['idx'], 'type': r['type'], 'gold': y,
                                'pred': p, 'abstain': bool(r['abstain']),
                                'correct': bool(correct)}, ensure_ascii=False) + '\n')

    report = '\n'.join(L)
    with open(out_dir / 'report.md', 'w') as f:
        f.write(report)
    with open(out_dir / 'metrics.json', 'w') as f:
        json.dump({'mode': mode, 'beta': beta, 'alpha_s': alpha_s, 'gammas': gammas,
                   'theta': [float(t) for t in theta], 'alpha_star': alpha_star,
                   'hyp': hyp, 'tbl': tbl}, f, indent=1, ensure_ascii=False)
    print(report)
    print(f'\n[written] {out_dir}/report.md')

if __name__ == '__main__':
    main()
