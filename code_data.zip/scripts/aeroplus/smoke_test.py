#!/usr/bin/env python3
"""Unit tests for the AERO+ fusion / conformal math."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import fusion, conformal, calibration

def approx(a, b, eps=1e-9):
    assert abs(a - b) < eps, f'{a} != {b}'

# --- T1: two agreeing point masses sharpen belief ---
m1 = fusion.mass_point(0.9, 1)
m2 = fusion.mass_point(0.8, 1)
comb, K, rule = fusion.combine_all([m1, m2])
bp = fusion.pignistic(comb)
approx(bp[1], 0.9 * 0.8 / (0.9 * 0.8 + 0.1 * 0.2))   # classic DS result 0.72/0.74
approx(sum(bp.values()), 1.0)
approx(K, 0.26)   # disjoint pairs: {1}x{2,0}: 0.9*0.2 + {2,0}x{1}: 0.1*0.8
print('T1 ok  BetP1 =', round(bp[1], 4), ' K =', K)

# --- T2: full conflict -> K=1 -> auto Yager -> all to Theta ---
m3 = fusion.mass_point(1.0, 1)
m4 = fusion.mass_point(1.0, 2)
comb, K, rule = fusion.combine_all([m3, m4])
approx(K, 1.0); assert rule == 'yager'
approx(comb[fusion.OMEGA], 1.0)
approx(sum(fusion.pignistic(comb).values()), 1.0)
print('T2 ok  K=1 -> yager, Theta mass = 1')

# --- T3: discount moves mass to Theta ---
m = fusion.mass_point(0.9, 1)
md = fusion.discount(m, 0.5)
approx(md[fusion.OMEGA], 1 - 0.5 + 0.5 * 0.0)   # 0.5
approx(md[frozenset({1})], 0.45)
approx(sum(md.values()), 1.0)
print('T3 ok  discount preserves total mass')

# --- T4: 3-frame extension: text with unknown u ---
m = fusion.mass_belief(0.7, 0.2, 1)
approx(sum(m.values()), 1.0)
approx(m[frozenset({1})], 0.7 * 0.8)
approx(m[frozenset({2, 0})], 0.3 * 0.8)     # Omega - {1} = {2, 0}
approx(m[fusion.OMEGA], 0.2)
print('T4 ok  vacuous extension to 3-frame')

# --- T5: confounder mass ---
m = fusion.mass_c0(0.6)
approx(m[frozenset({0})], 0.6); approx(m[fusion.OMEGA], 0.4)
print('T5 ok  C0 source')

# --- T6: K with u>0 sources is the true product-form conflict ---
m1 = fusion.mass_belief(0.9, 0.1, 1)
m2 = fusion.mass_point(0.9, 1)
comb, K, rule = fusion.combine_all([m1, m2])
# disjoint tuples: {1}(0.81)x{2,0}(0.1) + {2,0}(0.09)x{1}(0.9)
approx(K, 0.162, 1e-9)
bp = fusion.pignistic(comb)
approx(sum(bp.values()), 1.0)
print('T6 ok  exact K =', K)

# --- T7: fuse() end-to-end on a synthetic record ---
rec = {'idx': 't', 'type': 'real', 'gold': '1',
       'callA': {'h1': {'readings': [{'plausibility': 0.8}, {'plausibility': 0.7}, {'plausibility': 0.9}],
                        'confounder': 0.1},
                 'h2': {'readings': [{'plausibility': 0.3}, {'plausibility': 0.2}, {'plausibility': 0.3}],
                        'confounder': 0.1}},
       'N': {'h1': 0.8, 'h2': 0.2}, 'S': {'h1': 0.7, 'h2': 0.3}}
for v in ('full', 'plainds', 'nocf', 'nods'):
    f = fusion.fuse(rec, v)
    approx(sum(f['betp'].values()), 1.0, 1e-6)
    assert 0 <= f['K'] <= 1
f = fusion.fuse(rec, 'full')
assert f['betp'][1] > f['betp'][2], f
print('T7 ok  fuse full: BetP =', {k: round(v, 3) for k, v in f['betp'].items()},
      'K =', round(f['K'], 3), 'rule =', f['rule'])

# --- T8: legacy record fallback (no readings) ---
rec_l = {'idx': 't2', 'type': 'negative', 'gold': '3',
         'callA': {'h1': {'plausibility': 0.4, 'ambiguity': 0.6, 'confounder': 0.2},
                   'h2': {'plausibility': 0.5, 'ambiguity': 0.3, 'confounder': 0.3}},
         'N': {'h1': 0.2, 'h2': 0.3}, 'S': {'h1': 0.3, 'h2': 0.2}}
f = fusion.fuse(rec_l, 'full')
approx(sum(f['betp'].values()), 1.0, 1e-6)
print('T8 ok  legacy fallback BetP =', {k: round(v, 3) for k, v in f['betp'].items()})

# --- T9: Mondrian quantile edge cases ---
q = conformal.mondrian_quantiles([(1, 0.2), (1, 0.4), (2, 0.3), (0, 0.1)], alpha=0.25)
# class 1: n=2, r=ceil(3*0.75)=3 > 2 -> inf; class 2: n=1, r=2 > 1 -> inf; class 0: n=1 -> inf
assert q[1] == float('inf')
ps = conformal.predict_set({1: 0.9, 2: 0.05, 0: 0.05}, {1: 0.5, 2: float('inf'), 0: float('inf')})
assert ps == [1, 2, 0]   # inf quantile = class can never be excluded (conservative)
ps = conformal.predict_set({1: 0.4, 2: 0.3, 0: 0.3}, {1: 0.05, 2: 0.05, 0: 0.05})
assert ps == []          # low confidence + tight thresholds -> empty -> ABSTAIN
d = conformal.decide({1: 0.9, 2: 0.05, 0: 0.05}, {1: 0.95, 2: 0.02, 0: 0.03}, {1: 0.5, 2: 9, 0: 9})
assert d['pred'] == 1 and not d['abstain']
# coverage correction: argmax BetP (class 1) outside set -> fall back to argmax c inside set
d = conformal.decide({1: 0.7, 2: 0.2, 0: 0.1}, {1: 0.1, 2: 0.5, 0: 0.4}, {1: 0.05, 2: 0.6, 0: 0.6})
assert d['pred'] == 2 and d.get('corrected'), d
print('T9 ok  mondrian quantiles / predict_set / decide')

# --- T10: calibration fit recovers a monotone map ---
import random
rng = random.Random(0)
bks = []
for _ in range(200):
    p1, p2 = rng.random(), rng.random()
    p0 = max(0.05, 1 - p1 - p2)
    betp = {1: p1 / (p1 + p2 + p0), 2: p2 / (p1 + p2 + p0), 0: p0 / (p1 + p2 + p0)}
    gold = rng.choices([1, 2, 0], weights=[betp[1], betp[2], betp[0]])[0]
    bks.append((betp, rng.random() * 0.5, gold))
th = calibration.fit(bks)
assert abs(th[0] - 1) < 0.5, f'a should be near 1, got {th[0]}'   # BetP already ~ calibrated
print('T10 ok calibration a =', round(float(th[0]), 3), ' b =', round(float(th[1]), 3))

print('\nALL SMOKE TESTS PASSED')
