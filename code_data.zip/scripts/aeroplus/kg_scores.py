#!/usr/bin/env python3
"""Materialize KG evidence scores for an item file (offline, batch).

Usage:
  python3 kg_scores.py --input tmp/exp_items_full.jsonl --out tmp/kg_ecare.jsonl
  python3 kg_scores.py --adapter lexical --input ... --out ...   (default)
Real adapters register here once implemented (ASER/ATOMIC -- see graph/kg_source.py).
"""
import json, argparse, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from graph import kg_source

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--adapter', default='lexical')
    args = ap.parse_args()

    adapters = {'lexical': kg_source.LexicalKG}
    kg = adapters[args.adapter]()

    with open(args.out, 'w') as f:
        for l in open(args.input):
            l = l.strip()
            if not l:
                continue
            item = json.loads(l)
            f.write(json.dumps({'idx': item['idx'], 'kg': kg_source.score_item(item, kg),
                                'kg_adapter': kg.name}, ensure_ascii=False) + '\n')
    print(f'[kg_scores] {kg.name} -> {args.out}')

if __name__ == '__main__':
    main()
