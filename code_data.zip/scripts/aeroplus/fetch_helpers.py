#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Shared helpers for fetch_missing_data (bash + Windows .bat drivers).

Subcommands:
  convert-train : validate + convert tmp/ecare_train_raw.json -> tmp/ecare_train.jsonl
  check         : data-asset self-check with expected minimums
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent


def convert_train():
    raw = ROOT / 'tmp/ecare_train_raw.json'
    if not raw.exists() or raw.stat().st_size == 0:
        print('[warn] no downloaded raw file; download manually (see README)')
        return 1
    head = raw.read_text(encoding='utf-8', errors='ignore')[:200]
    if '404' in head or '<!DOCTYPE' in head:
        print('[warn] both sources unreachable; download e-CARE train manually:')
        print('  official: https://github.com/Waste-Wood/e-CARE  (dataset dir)')
        print('  HF:       https://huggingface.co/datasets/12ml/e-CARE')
        return 1
    d = json.loads(raw.read_text(encoding='utf-8'))
    rows = d if isinstance(d, list) else d.get('data', d.get('rows', []))
    out = ROOT / 'tmp/ecare_train.jsonl'
    with open(out, 'w', encoding='utf-8') as f:
        for r in rows:
            f.write(json.dumps({
                'index': r.get('index', ''),
                'premise': r.get('premise', ''),
                'ask-for': r.get('ask-for', ''),
                'hypothesis1': r.get('hypothesis1', ''),
                'hypothesis2': r.get('hypothesis2', ''),
                'label': r.get('label', 0)}, ensure_ascii=False) + '\n')
    print(f'[OK] e-CARE train {len(rows)} rows -> tmp/ecare_train.jsonl')
    return 0


CHECKS = [
    ('tmp/ecare_dev.jsonl', 'e-CARE dev pool (eval neg donor)', 2100),
    ('tmp/exp_items_v2.jsonl', 'e-CARE frozen 450 test', 450),
    ('tmp/cal_items_v3.jsonl', 'e-CARE calibration 60', 60),
    ('tmp/XCOPA/zh-test.parquet', 'XCOPA zh test', 0),
    ('tmp/XCOPA/vi-test.parquet', 'XCOPA vi test', 0),
    ('tmp/XCOPA/th-test.parquet', 'XCOPA th test', 0),
    ('tmp/XCOPA/sw-test.parquet', 'XCOPA sw test', 0),
    ('tmp/COPA/train.jsonl', 'COPA train (official 400)', 400),
    ('tmp/finsoc_en_test_v1.jsonl', 'FINSOC en test 1040', 1040),
    ('tmp/finsoc_zh_test_v1.jsonl', 'FINSOC zh test 1040', 1040),
    ('tmp/ecare_train.jsonl', 'e-CARE train (only needed for finetune baseline)', 0),
]


def check():
    print(f'{"item":46s} {"status":8s} rows')
    for path, desc, expect in CHECKS:
        fp = ROOT / path
        if not fp.exists():
            print(f'{desc:46s} MISSING')
            continue
        n = sum(1 for _ in open(fp, encoding='utf-8')) if path.endswith('.jsonl') else '-'
        ok = 'OK' if (expect == 0 or (isinstance(n, int) and n >= expect)) else 'SHORT!'
        print(f'{desc:46s} {ok:8s} {n}')
    print('note: missing e-CARE train does NOT affect evaluation; only the optional finetune baseline.')
    return 0


if __name__ == '__main__':
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'check'
    sys.exit({'convert-train': convert_train, 'check': check}.get(cmd, check)())
