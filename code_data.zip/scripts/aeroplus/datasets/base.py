"""Dataset adapters: external benchmarks -> AERO+ core item schema.

Core item schema (what L1 prompts and the whole pipeline consume):
  {idx, type: real|neg-easy|neg-hard, premise, ask_for: cause|effect,
   h1, h2, gold: "1"|"2"|"3"}

Each adapter declares:
  has_neither : whether gold '3' occurs naturally in this benchmark
  pi_real/pi_neg : design mix for lambda-risk weighting on its test set
  build() -> (cal_items, test_items)

Adding a dataset = one file + registry entry. No pipeline code changes.
"""
import json, random
from pathlib import Path

class DatasetAdapter:
    name = 'base'
    has_neither = False
    pi_real, pi_neg = 1.0, 0.0

    def build(self):
        raise NotImplementedError

    # ---------- shared helpers ----------
    @staticmethod
    def _read_jsonl(path):
        return [json.loads(l) for l in open(path) if l.strip()]

    @staticmethod
    def _neg_from_donors(base_items, donor_pool, n, seed, tag):
        """Constructed negatives: both candidates from unrelated donor premises
        => zero causal edge => gold '3' (needed to calibrate the C0 class)."""
        rng = random.Random(seed)
        out, i = [], 0
        for it in base_items:
            if len(out) >= n:
                break
            while True:
                donors = rng.sample(donor_pool, 2)
                if (donors[0]['premise'] != it['premise']
                        and donors[1]['premise'] != it['premise']):
                    break
            out.append({'idx': f'{tag}-{i}', 'type': 'neg-easy', 'premise': it['premise'],
                        'ask_for': it['ask_for'], 'h1': donors[0]['h1'], 'h2': donors[1]['h1'],
                        'gold': '3'})
            i += 1
        return out

REGISTRY = {}

def register(cls):
    REGISTRY[cls.name] = cls
    return cls

def get(name):
    return REGISTRY[name]()
