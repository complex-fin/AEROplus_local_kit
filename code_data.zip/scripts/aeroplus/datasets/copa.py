"""COPA (SuperGLUE) adapter: premise + 2 alternatives, question = cause|effect.

Natural gold only in {1,2}; class-0 (neither) never occurs naturally, so we
add constructed negatives to the CALIBRATION set only (to fit the class-0
conflict term b3); the test set stays natural COPA (pi_neg = 0).

Split (seeded, from train.jsonl which has labels; 400 items):
  test : 60 real
  cal  : 20 real + 10 constructed neg-easy
"""
import random, sys, os
from pathlib import Path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import config as C
from .base import DatasetAdapter, register

@register
class CopaAdapter(DatasetAdapter):
    name = 'copa'
    has_neither = False
    pi_real, pi_neg = 1.0, 0.0

    def build(self):
        src = self._read_jsonl(C.TMP / 'COPA' / 'train.jsonl')
        rng = random.Random(C.SEED)
        order = list(range(len(src)))
        rng.shuffle(order)
        core = [{'idx': f'copa-{i}', 'type': 'real', 'premise': it['premise'],
                 'ask_for': it['question'], 'h1': it['choice1'], 'h2': it['choice2'],
                 'gold': str(it['label'] + 1)}
                for i, it in enumerate(src)]
        test = [core[i] for i in order[:60]]
        cal_real = [dict(core[i], idx=f'copacal-r{j}') for j, i in enumerate(order[60:80])]
        donors = [core[i] for i in order[80:]]
        cal_neg = self._neg_from_donors([core[i] for i in order[60:70]], donors, 10,
                                        C.SEED + 1, 'copacal-e')
        return cal_real + cal_neg, test

    def raw_outputs(self):
        return C.TMP / 'results_copa_cal.jsonl', C.TMP / 'results_copa.jsonl'
