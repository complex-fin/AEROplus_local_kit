"""e-CARE adapter: wraps the already-frozen v2 files (do not regenerate --
collection is mid-flight against these exact idx values)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import config as C
from .base import DatasetAdapter, register

@register
class EcareAdapter(DatasetAdapter):
    name = 'ecare'
    has_neither = False          # negatives are constructed, not natural
    pi_real, pi_neg = 2 / 3, 1 / 3

    def build(self):
        cal = self._read_jsonl(C.CAL_ITEMS)
        test = self._read_jsonl(C.TEST_FULL)     # 40 real + 20 neg-easy + 20 neg-hard
        return cal, test

    def raw_outputs(self):
        return C.RAW_CAL, C.RAW_TEST
