"""FINSOC domain-transfer adapter: constructed social & financial event
causal reasoning (bilingual; en primary, zh mirror for paired analysis).

Composition (frozen v1, seed 20261012):
  test : 1040 = 640 real (gold 1/2) + 200 negative + 200 neg-hard (gold 3)
  cal  : 100  = 64 real + 18 + 18
Distractors in real items are valence-flipped counterparts (must know the
mechanism); negatives are cross-domain (easy) or same-topic confounds (hard).
Generator: scripts/make_finsoc_dataset.py -- do not regenerate by hand.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import config as C
from .base import DatasetAdapter, register


@register
class FinsocAdapter(DatasetAdapter):
    name = 'finsoc'
    has_neither = False          # negatives are constructed, as in e-CARE v2
    pi_real, pi_neg = 640 / 1040, 400 / 1040

    def build(self):
        cal = self._read_jsonl(C.TMP / 'finsoc_en_cal_v1.jsonl')
        test = self._read_jsonl(C.TMP / 'finsoc_en_test_v1.jsonl')
        return cal, test

    def raw_outputs(self):
        return (C.TMP / 'results_aero_finsoc.jsonl', C.TMP / 'results_aero_finsoc_cal.jsonl')
