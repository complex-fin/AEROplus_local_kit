from .base import REGISTRY, get, DatasetAdapter
from . import ecare, copa, finsoc   # import triggers @register
