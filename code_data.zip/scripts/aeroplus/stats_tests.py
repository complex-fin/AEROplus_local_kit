#!/usr/bin/env python3
"""Significance & power utilities for AERO+ v4 paper tables.

Implements the statistics the reviewers asked for:
 - mcnemar_exact(): paired accuracy comparison on the SAME items (H1/H6 style)
 - boot_ci(): percentile bootstrap for acc / lambda-risk / AUC (seeded)
 - detectable_delta(): post-hoc power analysis (what effect size is
   detectable at alpha=.05, power=.80 given n and base acc)
Usage: python3 stats_tests.py            # self-test
       import in analysis drivers.
"""
import json, math, random, sys
from pathlib import Path

# ---------------------------------------------------------------- McNemar
def mcnemar_exact(b, c):
    """Exact two-sided McNemar (binomial on discordant pairs).
    b = system A right & B wrong count; c = A wrong & B right count."""
    n = b + c
    if n == 0:
        return 1.0
    k = min(b, c)
    # two-sided binomial p under p=0.5
    def binom_p(k, n):
        p = sum(math.comb(n, i) for i in range(0, k + 1)) / 2 ** n
        return min(1.0, 2 * p)
    return binom_p(k, n)

def paired_correct(recs_a, recs_b):
    """Join two result files by idx -> (b, c) discordant counts.
    recs_* : list of dicts with idx + correctness field (pred==gold)."""
    def okmap(recs):
        m = {}
        for r in recs:
            hit = (r.get('pred') == r.get('gold'))
            m[r['idx']] = bool(hit)
        return m
    ma, mb = okmap(recs_a), okmap(recs_b)
    common = set(ma) & set(mb)
    b = sum(1 for i in common if ma[i] and not mb[i])
    c = sum(1 for i in common if not ma[i] and mb[i])
    return b, c, len(common)

# ---------------------------------------------------------------- bootstrap
def boot_ci(vals, stat=lambda v: sum(v) / len(v), n_boot=10000, seed=7, a=0.05):
    """Percentile bootstrap CI for a statistic of a list of numbers."""
    rng = random.Random(seed)
    n = len(vals)
    stats = []
    for _ in range(n_boot):
        stats.append(stat([vals[rng.randrange(n)] for _ in range(n)]))
    stats.sort()
    lo = stats[int(a / 2 * n_boot)]
    hi = stats[min(n_boot - 1, int((1 - a / 2) * n_boot))]
    return stat(vals), lo, hi

def boot_ci_delta(vals_a, vals_b, n_boot=10000, seed=7, a=0.05):
    """Bootstrap CI for mean difference (paired by position)."""
    assert len(vals_a) == len(vals_b)
    rng = random.Random(seed)
    n = len(vals_a)
    ds = []
    for _ in range(n_boot):
        i = [rng.randrange(n) for _ in range(n)]
        ds.append(sum(vals_a[k] for k in i) / n - sum(vals_b[k] for k in i) / n)
    ds.sort()
    point = sum(vals_a) / n - sum(vals_b) / n
    return point, ds[int(a / 2 * n_boot)], ds[min(n_boot - 1, int((1 - a / 2) * n_boot))]

# ---------------------------------------------------------------- power
def detectable_delta(n, base_acc=0.8, alpha=0.05, power=0.8):
    """Smallest detectable accuracy delta (Cohen's h, two-proportion normal
    approx, unpaired conservative estimate). Closed form."""
    z_a, z_b = 1.96, 0.8416          # alpha=.05 two-sided, power=.80
    h = (z_a + z_b) / math.sqrt(n)   # required effect size (arc-sine)
    phi1 = 2 * math.asin(math.sqrt(base_acc))
    phi2 = phi1 - h
    if phi2 <= 0:
        return float('nan')
    p2 = math.sin(phi2 / 2) ** 2
    return base_acc - p2

# ---------------------------------------------------------------- self-test
if __name__ == '__main__':
    # McNemar sanity: 10 vs 2 discordant
    p = mcnemar_exact(10, 2)
    assert 0.01 < p < 0.1, p
    # bootstrap sanity: mean of 100 zeros/ones ~ [0.3, 0.7]
    m, lo, hi = boot_ci([1] * 50 + [0] * 50)
    assert 0.35 < lo < 0.5 < hi < 0.65, (lo, hi)
    # power sanity
    for n, expect in ((300, 0.09), (450, 0.07), (79, 0.18)):
        d = detectable_delta(n, 0.8)
        print(f'n={n}: detectable delta at power .80 ≈ {d:.3f} '
              f'({"OK" if abs(d - expect) < 0.04 else "CHECK"})')
    print('self-test PASS | mcnemar(10,2) p=%.4f, boot mean %.2f [%.2f, %.2f]' % (p, m, lo, hi))
