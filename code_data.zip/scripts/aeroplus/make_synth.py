#!/usr/bin/env python3
"""Generate SYNTHETIC raw records with a known generative process, to verify
the FULL offline pipeline end-to-end without any API usage.

Design (planted effects -> expected test outcomes):
  real items (67%): gold candidate bel ~ N(0.72, 0.03) over 3 readings,
                    non-gold bel ~ N(0.38, 0.03), f ~ U(0.1,0.3),
                    N/S ~ 0.7 for the true edge, ~0.35 otherwise.
  negatives      : candidate 1 HIGH association (bel ~ N(0.70,0.03)), candidate 2
                    low (~0.42), zero causal edge; f ~ U(0.5,0.65), N/S ~ 0.35.
  -> aero_nocf (text+f) should OVERCLAIM on negatives (asymmetric text beats
     mild f), full adds N/S pushing to C0 -> H1 should fire.
  -> calibrated conf should beat raw BetP -> H4 improves.
  -> Mondrian coverage ~ 1-alpha -> H3 check.
Also injects shared noise between N and S (source correlation, exercises gamma).
"""
import json, random, math, sys, os
sys.path.insert(0, os.path.dirname(__file__))
import config as C

def gauss(mu, sd, rng):
    return max(0.02, min(0.98, rng.gauss(mu, sd)))

def make_record(rng, real, gold=None, tag='syn', i=0):
    if real:
        gold = gold or rng.choice([1, 2])
    bels, Ns, Ss, fs = {}, {}, {}, {}
    shared_noise = rng.gauss(0, 0.08)          # N-S shared noise -> correlation
    for k in (1, 2):
        if not real:
            # D_hard pattern: h1 looks strongly associated, h2 weak, no real edge
            bel = gauss(0.62, 0.05, rng) if k == 1 else gauss(0.50, 0.05, rng)
            f = rng.uniform(0.50, 0.65)
        elif k == gold:
            bel = gauss(0.64, 0.05, rng)
            f = rng.uniform(0.10, 0.30)
        else:
            bel = gauss(0.46, 0.05, rng)
            f = rng.uniform(0.10, 0.30)
        base = 0.58 if (real and k == gold) else 0.45
        N = gauss(base, 0.08, rng) + shared_noise
        S = gauss(base, 0.08, rng) + shared_noise
        bels[k] = max(0.02, min(0.98, bel))
        Ns[k] = max(0.02, min(0.98, N))
        Ss[k] = max(0.02, min(0.98, S))
        fs[k] = f
    callA = {'h1': {}, 'h2': {}}
    for k, hk in ((1, 'h1'), (2, 'h2')):
        readings = [{'completion': f'r{j}', 'plausibility': round(max(0.02, min(0.98, bels[k] + rng.gauss(0, 0.10))), 3)}
                    for j in range(3)]
        callA[hk] = {'missing': '', 'readings': readings, 'hidden': '',
                     'plausibility': round(bels[k], 3), 'confounder': round(fs[k], 3),
                     'ambiguity': 0.2}
    gold_s = str(gold) if real else '3'
    return {'idx': f'{tag}-{i}', 'type': 'real' if real else 'neg-easy', 'gold': gold_s,
            'callA': callA, 'N': {'h1': round(Ns[1], 3), 'h2': round(Ns[2], 3)},
            'S': {'h1': round(Ss[1], 3), 'h2': round(Ss[2], 3)}}

def main():
    rng = random.Random(42)
    out_cal = C.TMP / 'results_synth_cal.jsonl'
    out_test = C.TMP / 'results_synth_test.jsonl'
    with open(out_cal, 'w') as f:
        for i in range(30):     # 18 real + 12 neg
            real = i < 18
            f.write(json.dumps(make_record(rng, real, tag='synccal', i=i)) + '\n')
    with open(out_test, 'w') as f:
        for i in range(40):     # 24 real + 16 neg
            real = i < 24
            f.write(json.dumps(make_record(rng, real, tag='synctest', i=i)) + '\n')
    print(f'[synth] cal 30 -> {out_cal}')
    print(f'[synth] test 40 -> {out_test}')

if __name__ == '__main__':
    main()
