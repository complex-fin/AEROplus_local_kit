"""L5: Mondrian per-class split-conformal abstention + lambda-risk alpha selection.

Scores: s(x, y) = 1 - c(x, y) with c the calibrated per-class confidence.
Calibration items are grouped by true class; per-class quantiles use the
standard finite-sample order statistic ceil((n_y + 1)(1 - alpha)).
Prediction set empty  <=>  ABSTAIN.
"""
import math
import config as C

def mondrian_quantiles(cal_scores, alpha):
    """cal_scores: list of (y, s). Returns per-class thresholds q[y] (inf => never accept)."""
    by_class = {}
    for y, s in cal_scores:
        by_class.setdefault(y, []).append(s)
    q = {}
    for y, ss in by_class.items():
        ss = sorted(ss)
        n = len(ss)
        r = math.ceil((n + 1) * (1 - alpha))
        q[y] = ss[r - 1] if 1 <= r <= n else float('inf')
    for y in (1, 2, 0):          # ensure all classes present
        q.setdefault(y, float('inf'))
    return q

def predict_set(c_x, q):
    """c_x: {class: calibrated conf}. Returns sorted list of accepted classes."""
    return [k for k in (1, 2, 0) if 1 - c_x[k] <= q[k]]

def decide(betp, c_x, q):
    """Full L5 decision: yhat = argmax BetP; if not in set, coverage-corrected
    choice = argmax c within set (counted as correction); empty set = ABSTAIN.

    FIX v2 (C0-keep): an explicit C0 argmax from the fusion layer is TRUSTED.
    Correcting 'neither' -> '1/2' when C0 is outside the prediction set was the
    single largest overclaim source on e-CARE (36/40 negative items flipped by
    this rule; cal/test negative-difficulty drift makes q[0] too tight for
    hard test negatives). C0 is kept as the prediction instead."""
    yhat = max(betp, key=betp.get)
    ps = predict_set(c_x, q)
    if yhat == 0:
        return {'pred': 0, 'abstain': False, 'set': ps, 'corrected': False}
    if not ps:
        return {'pred': None, 'abstain': True, 'set': [], 'corrected': False}
    corrected = yhat not in ps
    pred = yhat if not corrected else max(ps, key=lambda k: c_x[k])
    return {'pred': pred, 'abstain': False, 'set': ps, 'corrected': corrected}

def risk_on_cal(cal_items, alphas, l_miss, l_over, l_abs, pi_real, pi_neg):
    """cal_items: list of dicts with keys y (gold int), pred, abstain, type_real (bool).
    Returns for each alpha: lambda-risk and diagnostics on the calibration set."""
    out = {}
    for a in alphas:
        miss = over = abs_r = abs_n = 0; n_r = n_n = 0; cov = 0
        for it in cal_items:
            real = it['type_real']
            if real: n_r += 1
            else: n_n += 1
            if it['abstain']:
                if real: abs_r += 1
                else: abs_n += 1
            elif it['pred'] != it['y']:
                if real: miss += 1
                else: over += 1
            else:
                cov += 1
        R = pi_real * (l_miss * miss / max(n_r, 1) + l_abs * abs_r / max(n_r, 1)) \
          + pi_neg * (l_over * over / max(n_n, 1) + l_abs * abs_n / max(n_n, 1))
        out[a] = {'risk': R, 'miss': miss / max(n_r, 1), 'over': over / max(n_n, 1),
                  'abs_real': abs_r / max(n_r, 1), 'abs_neg': abs_n / max(n_n, 1),
                  'coverage': cov / max(n_r + n_n, 1)}
    return out

def select_alpha(cal_items, alphas=None):
    if alphas is None:
        alphas = C.ALPHA_GRID
    rk = risk_on_cal(cal_items, alphas, C.LAMBDA_MISS, C.LAMBDA_OVER, C.LAMBDA_ABS,
                     C.PI_REAL, C.PI_NEG)
    best = min(rk, key=lambda a: rk[a]['risk'])
    return best, rk
