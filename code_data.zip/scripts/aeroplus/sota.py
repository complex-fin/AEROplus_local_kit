#!/usr/bin/env python3
"""SOTA / published-baseline comparison layer.

Loads download/baselines_published.json and renders a comparison table.
RULES (honesty):
 - 'published' rows must carry a verifiable citation; value=null rows are
   placeholders and are rendered as 'pending citation' -- never fabricated;
 - 'our-run' rows are appended automatically from result files by the report.
Adding a SOTA number = adding one JSON entry, no code changes.
"""
import json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
import config as C

PATH = C.DOWNLOAD / 'baselines_published.json'

def load():
    if not PATH.exists():
        return []
    data = json.load(open(PATH))
    return data.get('entries', data) if isinstance(data, dict) else data

def render(rows_ours=None):
    """rows_ours: list of dicts {dataset, system, metric, value}."""
    out = ['| dataset | system | kind | value | source |', '|---|---|---|---|---|']
    for e in load():
        if e.get('skip'):
            continue
        val = e.get('value')
        out.append(f"| {e['dataset']} | {e['system']} | {e.get('kind','published')} | "
                   f"{'pending citation' if val is None else val} | {e.get('source','')} |")
    for r in rows_ours or []:
        out.append(f"| {r['dataset']} | {r['system']} | our-run | {r['value']} | this work |")
    return '\n'.join(out)

if __name__ == '__main__':
    print(render())
