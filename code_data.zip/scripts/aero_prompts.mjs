/** AERO+ prompt builders — the ONLY place L1/L2/probe prompt logic lives.
 *
 *  Dataset-agnostic: consume the core item schema produced by Python
 *  dataset adapters (datasets/*.py). Adding a dataset never touches this.
 *
 *  L1 (call A) : probabilistic parse + RS-1 reading sampling (M=3 per
 *                candidate) -> plausibility variance feeds L2's unknown-mass.
 *  L2          : computed OFFLINE in Python (layers/l2.py) from call A
 *                readings -- nothing to prompt here.
 *  Probes(call B): N/S counterfactual probes on the MINIMAL SKELETON only
 *                (no L1 context -> source independence, spec sec 3.5).
 */

export function fmtItem(it) {
  return `Premise event: ${it.premise}\nAsk-for: ${it.ask_for}\nCandidate 1: ${it.h1}\nCandidate 2: ${it.h2}`;
}

export const L1_SYSTEM = 'You are an expert in open-world event causal analysis. Answer with a single JSON object only.';

export function l1Messages(it) {
  return [
    { role: 'assistant', content: L1_SYSTEM },
    { role: 'user', content: `${fmtItem(it)}

Open-world analysis: event descriptions are underspecified. For EACH candidate:
1) name the missing elements needed to judge the ${it.ask_for} relation (actors, instruments, location, time);
2) imagine THREE different readings of the premise (resolve missing elements differently); for each reading give the plausibility that this candidate is the true ${it.ask_for} of the premise on 0-1;
3) describe a plausible unobserved confounder (a hidden common cause or context factor) and rate how strongly it could produce the observed association instead of a direct causal link, on 0-1;
4) rate overall semantic association of the candidate with the premise on 0-1.

Return JSON:
{"h1":{"missing":"...","readings":[{"completion":"...","plausibility":0.x} x3],"hidden":"...","confounder":0.x,"plausibility":0.x},
 "h2":{...same...}}` },
  ];
}

export function probeMessages(it) {
  const necQ = it.ask_for === 'cause'
    ? `NECESSITY: counterfactually, if candidate X (the hypothesized cause) had NOT occurred, how plausible is it that the premise event would still have occurred? (high = X not necessary)`
    : `NECESSITY: counterfactually, if the premise event had NOT occurred, how plausible is it that candidate X would still occur anyway? (high = premise not necessary for X)`;
  const sufQ = it.ask_for === 'cause'
    ? `SUFFICIENCY: if candidate X occurred, how likely is the premise event to follow?`
    : `SUFFICIENCY: given the premise event occurs, how likely does candidate X follow?`;
  return [
    { role: 'assistant', content: 'You are an expert in counterfactual and interventional causal analysis. Answer with a single JSON object only.' },
    { role: 'user', content: `${fmtItem(it)}

For EACH candidate, judge both probes:
${necQ.replace(/X/g, 'the candidate')}
${sufQ.replace(/X/g, 'the candidate')}

Return JSON: {"h1":{"still":0.x,"likely":0.x,"reason":"one sentence"},"h2":{"still":0.x,"likely":0.x,"reason":"one sentence"}}` },
  ];
}

export function cfCotMessages(it) {
  const cf = it.ask_for === 'cause'
    ? `for each candidate cause: if it had NOT occurred, would the premise still occur?`
    : `if the premise event had NOT occurred, would each candidate effect still occur anyway? If yes for both candidates, neither depends on the premise.`;
  return [
    { role: 'assistant', content: 'You are an expert in event-level causal reasoning. Answer with a single JSON object only.' },
    { role: 'user', content: `${fmtItem(it)}

Options: "1" = Candidate 1 is the ${it.ask_for}, "2" = Candidate 2 is the ${it.ask_for}, "3" = NEITHER candidate has a genuine causal link with the premise.

Think step by step: (1) assess surface association of each candidate with the premise; (2) run the counterfactual checks: ${cf} (3) decide, and give your confidence.
Return JSON: {"reasoning":"2-3 sentences","answer":"1"|"2"|"3","confidence":0-1}` },
  ];
}
