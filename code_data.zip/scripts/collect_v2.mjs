#!/usr/bin/env node
/**
 * AERO+ structured collector (v2).
 *
 * Systems collected here (baselines zero-shot/CoT reuse v1 result files):
 *   aeroplus : call A  = L1 parse + RS-1 reading sampling (per-reading plausibility)
 *              call B  = N/S counterfactual probes on the MINIMAL SKELETON only
 *                        (premise + candidates; NO L1 context -> source independence)
 *   cf_cot   : CF-CoT-style proxy baseline -- CoT with integrated counterfactual
 *              checks (single call), for the "prompt-level counterfactual" contrast.
 *
 * Ablations aero_nocf / aero_nods / plain-DS are DERIVED OFFLINE from aeroplus
 * raw outputs (offline replay contract), so no extra API budget is spent on them.
 *
 * Resumable; per-item up to 2 in-run attempts; output JSONL.
 */
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, v, i, arr) => {
  if (v.startsWith('--')) a.push([v.slice(2), arr[i + 1]]);
  return a;
}, []));

const SYSTEM = args.system || 'aeroplus';
const INPUT = args.input || 'tmp/exp_items_full.jsonl';
const OUTPUT = args.output || `tmp/results_${SYSTEM}.jsonl`;
const CONCURRENCY = parseInt(args.conc || '3', 10);
const LIMIT = args.limit ? parseInt(args.limit, 10) : null;

const items = fs.readFileSync(INPUT, 'utf-8').trim().split('\n').map(JSON.parse);
const done = new Set(fs.existsSync(OUTPUT)
  ? fs.readFileSync(OUTPUT, 'utf-8').trim().split('\n').filter(Boolean).map(l => { try { return JSON.parse(l).idx; } catch { return null; } })
  : []);
const todo = items.filter(it => !done.has(it.idx)).slice(0, LIMIT || undefined);
console.log(`[${SYSTEM}] total=${items.length} done=${done.size} todo=${todo.length}`);

let zai;
let callCount = 0;
const BACKOFFS = [2000, 5000, 10000];

async function llm(messages, { temp = 0, retries = 3 } = {}) {
  for (let a = 1; a <= retries; a++) {
    try {
      callCount++;
      const completion = await zai.chat.completions.create({
        messages, thinking: { type: 'disabled' }, temperature: temp,
      });
      const content = completion.choices?.[0]?.message?.content;
      if (!content || !content.trim()) throw new Error('empty response');
      return content.trim();
    } catch (e) {
      const msg = String(e.message || e);
      const retriable = /429|500|502|503|504|timeout|empty/i.test(msg);
      if (!retriable || a === retries) throw e;
      await new Promise(r => setTimeout(r, BACKOFFS[Math.min(a - 1, BACKOFFS.length - 1)] + Math.random() * 2000));
    }
  }
}

function parseJSON(text) {
  let t = text.trim().replace(/```json/g, '').replace(/```/g, '');
  const s = t.indexOf('{'), e = t.lastIndexOf('}');
  if (s >= 0 && e > s) t = t.slice(s, e + 1);
  return JSON.parse(t);
}

async function llmJSON(messages, opts = {}) {
  const txt = await llm(messages, opts);
  try { return parseJSON(txt); } catch {
    const txt2 = await llm([...messages,
      { role: 'user', content: 'Your previous output was not valid JSON. Return ONLY the valid JSON object, no other text.' }],
      { temp: 0 });
    try { return parseJSON(txt2); } catch { return null; }
  }
}

const num = (v, lo = 0, hi = 1) => {
  const x = typeof v === 'number' ? v : parseFloat(v);
  if (Number.isNaN(x)) return null;
  return Math.min(hi, Math.max(lo, x));
};

const DIRTXT = { cause: 'possible CAUSES of the premise event', effect: 'possible EFFECTS of the premise event' };
const fmt = it => `Premise: ${it.premise}\nWe are looking for ${DIRTXT[it.ask_for]}.\nCandidate 1: ${it.h1}\nCandidate 2: ${it.h2}`;

// ---------------- AERO+ raw collection ----------------
async function runAeroPlus(it) {
  // ---- Call A: L1 parse + L2 RS-1 reading sampling ----
  const callA = await llmJSON([
    { role: 'assistant', content: 'You are an expert in event understanding and causal analysis in the open world, where event elements are often incomplete and event expressions ambiguous. You answer with a single JSON object only.' },
    { role: 'user', content: `${fmt(it)}\n\nStep 1: briefly note what key elements (agent/time/place/manner) are missing or ambiguous in each candidate and the premise.\nStep 2: for EACH candidate, write exactly 3 plausible but DIFFERENT completions/readings of the missing elements, and rate the plausibility of EACH reading separately (0-1). Also list possible UNOBSERVED events (hidden common causes, mediators) that could explain a premise-candidate co-occurrence without a direct causal link, and rate the overall:\n- "plausibility": how likely this candidate is a genuine ${it.ask_for} of the premise (0-1)\n- "confounder": how likely the observed link is instead explained by a hidden event (0-1)\n- "ambiguity": how ambiguous the event interpretation is (0-1)\n\nReturn JSON:\n{"h1":{"missing":"...","readings":[{"completion":"...","plausibility":0.x},{"completion":"...","plausibility":0.x},{"completion":"...","plausibility":0.x}],"hidden":"...","plausibility":0.x,"confounder":0.x,"ambiguity":0.x},"h2":{...}}` },
  ], { temp: 0.7 });
  if (!callA) return { error: 'parseA' };

  // ---- Call B: probes on the MINIMAL SKELETON (no L1 context) ----
  const necQ = it.ask_for === 'cause'
    ? `NECESSITY for candidate X: if candidate X had NOT occurred, would the premise event still occur anyway? ("still" = probability the premise still occurs, 0-1; high "still" means X is NOT necessary)`
    : `NECESSITY for candidate X: if the premise event had NOT occurred, would candidate X still occur anyway? ("still" = probability candidate X still occurs, 0-1; high "still" means X does not depend on the premise)`;
  const sufQ = it.ask_for === 'cause'
    ? `SUFFICIENCY for candidate X: in a comparable situation where ONLY candidate X occurs, how likely does the premise event follow? ("likely" = probability, 0-1)`
    : `SUFFICIENCY for candidate X: given the premise event occurs, how likely does candidate X follow? ("likely" = probability, 0-1)`;
  const callB = await llmJSON([
    { role: 'assistant', content: 'You are an expert in counterfactual and interventional causal analysis. Answer with a single JSON object only.' },
    { role: 'user', content: `${fmt(it)}\n\nFor EACH candidate, judge both probes by mentally simulating the counterfactual world (do not use surface plausibility or association):\n${necQ}\n${sufQ}\n\nReturn JSON: {"h1":{"still":0.x,"likely":0.x,"reason":"one sentence"},"h2":{"still":0.x,"likely":0.x,"reason":"one sentence"}}` },
  ], { temp: 0 });
  if (!callB) return { error: 'parseB' };

  const N = { h1: 1 - (num(callB.h1?.still) ?? 0.5), h2: 1 - (num(callB.h2?.still) ?? 0.5) };
  const S = { h1: num(callB.h1?.likely) ?? 0.5, h2: num(callB.h2?.likely) ?? 0.5 };
  return { callA, callB, N, S };
}

// ---------------- CF-CoT proxy baseline ----------------
async function runCFCoT(it) {
  const cf = it.ask_for === 'cause'
    ? `For each candidate X as a putative cause: counterfactually, if X had NOT occurred, would the premise event still occur anyway? If yes for both candidates, neither is a necessary cause.`
    : `For each candidate X as a putative effect: counterfactually, if the premise event had NOT occurred, would X still occur anyway? If yes for both candidates, neither depends on the premise.`;
  const res = await llmJSON([
    { role: 'assistant', content: 'You are an expert in event-level causal reasoning. Answer with a single JSON object only.' },
    { role: 'user', content: `${fmt(it)}\n\nOptions: "1" = Candidate 1 is the ${it.ask_for}, "2" = Candidate 2 is the ${it.ask_for}, "3" = NEITHER candidate has a genuine causal link with the premise.\n\nThink step by step: (1) assess surface association of each candidate with the premise; (2) run the counterfactual checks: ${cf} (3) decide, and give your confidence.\nReturn JSON: {"reasoning":"2-3 sentences","answer":"1"|"2"|"3","confidence":0-1}` },
  ], { temp: 0 });
  if (!res) return { pred: null, conf: 0.5, abstain: false, error: 'parse' };
  let pred = String(res.answer);
  if (!['1', '2', '3'].includes(pred)) pred = null;
  return { pred, conf: num(res.confidence) ?? 0.5, abstain: false, raw: res };
}

async function processItem(it) {
  let out = null;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const r = { idx: it.idx, type: it.type, gold: it.gold, system: SYSTEM };
      if (SYSTEM === 'aeroplus') Object.assign(r, await runAeroPlus(it));
      else if (SYSTEM === 'cf_cot') Object.assign(r, await runCFCoT(it));
      else throw new Error(`unknown system ${SYSTEM}`);
      if (!r.error) { out = r; break; }
      throw new Error(r.error);
    } catch (e) {
      console.log(`[${SYSTEM}] item ${it.idx} attempt ${attempt} failed: ${String(e.message || e).slice(0, 100)}`);
      if (attempt < 2) await new Promise(r2 => setTimeout(r2, 30000));
    }
  }
  if (out) fs.appendFileSync(OUTPUT, JSON.stringify(out) + '\n');
  return out;
}

async function main() {
  zai = await ZAI.create();
  let i = 0, ok = 0, err = 0;
  async function worker() {
    while (i < todo.length) {
      const it = todo[i++];
      const r = await processItem(it);
      r ? ok++ : err++;
      if ((ok + err) % 10 === 0) console.log(`[${SYSTEM}] progress ${ok + err}/${todo.length} err=${err} calls=${callCount}`);
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  console.log(`[${SYSTEM}] DONE ok=${ok} err=${err} calls=${callCount}`);
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
