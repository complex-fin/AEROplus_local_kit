#!/usr/bin/env node
/**
 * AERO+ generic collector v3 (dataset-agnostic).
 *
 *   aeroplus : call A (L1 + RS-1 readings) + call B (minimal-skeleton probes)
 *   cf_cot   : CF-CoT proxy baseline (single call)
 *
 * Any core-schema item file works (built by scripts/aeroplus/datasets/*.py):
 *   node collect_v3.mjs --system aeroplus --input tmp/copa_items.jsonl \
 *        --output tmp/results_copa.jsonl [--kg tmp/kg_copa.jsonl] [--conc 4]
 *
 * --kg FILE: merge precomputed event-KG evidence scores (graph/kg_source.py)
 *            into each record as rec.kg = {h1,h2}. Omit = no KG source.
 * Resumable by idx; identical record schema to collect_v2.mjs.
 *
 * LLM backend (auto-detected, first match wins):
 *   1. env LLM_BASE_URL + LLM_API_KEY (+ optional LLM_MODEL)
 *      -> plain fetch against any OpenAI-compatible /chat/completions endpoint
 *         (OpenAI / DeepSeek / Qwen(DashScope compat) / vLLM / Ollama ...)
 *   2. scripts/llm_config.json  {"baseUrl": "...", "apiKey": "...", "model": "..."}
 *      -> same fetch path, keeps credentials out of shell history
 *   3. .z-ai-config (project / home / /etc)  -> z-ai-web-dev-sdk (server path)
 */
import fs from 'fs';
import path from 'path';
import { l1Messages, probeMessages, cfCotMessages } from './aero_prompts.mjs';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, v, i, arr) => {
  if (v.startsWith('--')) a.push([v.slice(2), arr[i + 1]]);
  return a;
}, []));

const SYSTEM = args.system || 'aeroplus';
const INPUT = args.input;
const OUTPUT = args.output;
const KGFILE = args.kg || null;
const CONCURRENCY = parseInt(args.conc || '3', 10);
const LIMIT = args.limit ? parseInt(args.limit, 10) : null;
if (!INPUT || !OUTPUT) { console.error('need --input and --output'); process.exit(1); }

const items = fs.readFileSync(INPUT, 'utf-8').trim().split('\n').map(JSON.parse);
const kgScores = KGFILE ? Object.fromEntries(
  fs.readFileSync(KGFILE, 'utf-8').trim().split('\n').filter(Boolean).map(l => {
    const j = JSON.parse(l); return [j.idx, j.kg];
  })) : null;

const done = new Set(fs.existsSync(OUTPUT)
  ? fs.readFileSync(OUTPUT, 'utf-8').trim().split('\n').filter(Boolean).map(l => { try { return JSON.parse(l).idx; } catch { return null; } })
  : []);
const todo = items.filter(it => !done.has(it.idx)).slice(0, LIMIT || undefined);
console.log(`[${SYSTEM}] collect v3.2.1 | total=${items.length} done=${done.size} todo=${todo.length} kg=${KGFILE ? 'on' : 'off'}`);

let zai;                 // z-ai SDK instance (backend 3 only)
let FETCH_CFG = null;    // {baseUrl, apiKey, model, maxTokens, headers}
let BACKEND = 'unknown';

// maxTokens semantics: unset -> 8192 (anti-truncation default);
// 0 -> omit the field entirely (some endpoints reject it); N -> use N
function envMaxTokens(v) {
  if (v === undefined || v === '') return 8192;
  const n = Number(v);
  return Number.isFinite(n) ? n : 8192;
}

function resolveBackend() {
  if (process.env.LLM_BASE_URL && process.env.LLM_API_KEY) {
    FETCH_CFG = { baseUrl: process.env.LLM_BASE_URL.replace(/\/+$/, ''),
                  apiKey: process.env.LLM_API_KEY, model: process.env.LLM_MODEL || '',
                  maxTokens: envMaxTokens(process.env.LLM_MAX_TOKENS) };
    BACKEND = 'env-fetch';
    return;
  }
  const cfgPath = path.join(path.dirname(new URL(import.meta.url).pathname), 'llm_config.json');
  try {
    const cfg = JSON.parse(fs.readFileSync('llm_config.json', 'utf-8'));
    if (cfg.baseUrl && cfg.apiKey) {
      FETCH_CFG = { baseUrl: String(cfg.baseUrl).replace(/\/+$/, ''),
                    apiKey: String(cfg.apiKey), model: String(cfg.model || ''),
                    maxTokens: envMaxTokens(cfg.maxTokens),
                    headers: cfg.headers || {},
                    thinking: cfg.thinking || null };
      BACKEND = 'file-fetch';
      return;
    }
  } catch { /* not present */ }
  BACKEND = 'zai-sdk';   // requires .z-ai-config (project/home//etc)
}

let callCount = 0;
let consec429 = 0;   // sustained-throttle detector (quota window exhausted)
const BACKOFFS = [2000, 5000, 10000];

async function llmFetch(messages, temp) {
  const body = { model: FETCH_CFG.model, messages, temperature: temp };
  if (FETCH_CFG.maxTokens) body.max_tokens = FETCH_CFG.maxTokens;
  if (FETCH_CFG.thinking) body.thinking = FETCH_CFG.thinking;   // e.g. {"type":"disabled"} for GLM
  if (!body.model) throw new Error('LLM_MODEL required for fetch backend (env or llm_config.json)');
  const res = await fetch(`${FETCH_CFG.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${FETCH_CFG.apiKey}`,
               ...(FETCH_CFG.headers || {}) },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => '');
    throw new Error(`HTTP ${res.status} ${t.slice(0, 120)}`);
  }
  const j = await res.json();
  const m = j.choices?.[0]?.message;
  if (m?.content) return m.content;
  if (m?.reasoning_content) {   // reasoning model that left content empty
    console.error(`  [empty-content] content empty -> using reasoning_content (${String(m.reasoning_content).length} chars)`);
    return m.reasoning_content;
  }
  console.error(`  [empty-content] no message.content. Response head: ${JSON.stringify(j).slice(0, 200)}`);
  return null;
}

async function llmInner(messages, { temp = 0, retries = 3 } = {}) {
  for (let a = 1; a <= retries; a++) {
    try {
      callCount++;
      if (FETCH_CFG) return await llmFetch(messages, temp);
      const completion = await zai.chat.completions.create({
        messages, thinking: { type: 'disabled' }, temperature: temp,
      });
      const m = completion.choices?.[0]?.message;
      if (m?.content) return m.content;
      if (m?.reasoning_content) {   // gateway ignored thinking:disabled
        console.error(`  [empty-content] message.content empty -> using reasoning_content (${String(m.reasoning_content).length} chars)`);
        return m.reasoning_content;
      }
      let dump = ''; try { dump = JSON.stringify(completion).slice(0, 200); } catch { dump = String(completion).slice(0, 200); }
      console.error(`  [empty-content] reply has NO message.content. Response head: ${dump}`);
      return null;
    } catch (e) {
      const msg = String(e.message || e);
      console.error(`  [llm] attempt ${a}/${retries} failed: ${msg.slice(0, 160)}`);
      const wait = BACKOFFS[Math.min(a - 1, BACKOFFS.length - 1)];
      if (/429|rate|quota|too many/i.test(msg)) {
        consec429++;
        if (consec429 >= 8) {
          console.error('[quota] 8 consecutive 429s - quota window exhausted, aborting round (driver will retry later)');
          process.exit(13);
        }
        await new Promise(r => setTimeout(r, wait * 3));
      } else if (a === retries) throw e;
      else await new Promise(r => setTimeout(r, wait));
    }
  }
  return null;
}

async function llm(messages, opts) {
  const r = await llmInner(messages, opts);
  if (r != null) consec429 = 0;   // a real reply means quota is flowing again
  return r;
}

/** Robust JSON extraction from an LLM reply.
 *  Handles: markdown fences, <think> blocks (reasoning models), prose around
 *  the object, multiple objects (takes the largest parseable one), and
 *  reports a raw sample when nothing parses (truncation diagnostics). */
function extractJSON(text) {
  if (!text) return null;
  let t = String(text)
    .replace(/<think>[\s\S]*?<\/think>/gi, '')    // reasoning-model thoughts
    .replace(/```(?:json)?/gi, '```');            // normalise fences
  // candidate starts: every '{' in the cleaned text, scanned for balance
  const starts = [];
  for (let i = 0; i < t.length; i++) if (t[i] === '{') starts.push(i);
  if (!starts.length) return null;
  let best = null;
  for (const s of starts.slice(0, 200)) {          // cap the scan cost
    let depth = 0, inStr = false, esc = false;
    for (let i = s; i < t.length; i++) {
      const c = t[i];
      if (esc) { esc = false; continue; }
      if (c === '\\') { esc = true; continue; }
      if (c === '"') { inStr = !inStr; continue; }
      if (inStr) continue;
      if (c === '{') depth++;
      else if (c === '}') {
        depth--;
        if (depth === 0) {
          const cand = t.slice(s, i + 1);
          if (cand.length > 5) {                   // skip trivial fragments
            try {
              const obj = JSON.parse(cand);
              if (!best || cand.length > best.len) best = { obj, len: cand.length };
            } catch { /* try next */ }
          }
          break;
        }
      }
    }
  }
  return best ? best.obj : null;
}

async function llmJSON(messages, opts) {
  const t = await llm(messages, opts);
  if (!t) { console.error('  [empty-reply] model returned no usable text (see [llm]/[empty-content] above)'); return null; }
  const obj = extractJSON(t);
  if (!obj) {
    const sample = String(t).replace(/\s+/g, ' ').slice(0, 160);
    console.error(`  [parse-fail] raw reply (${String(t).length} chars): ${sample}${String(t).length > 160 ? ' ...' : ''}${String(t).length > 3000 && !String(t).trim().endsWith('}') ? '   <-- possibly TRUNCATED (raise maxTokens in llm_config.json)' : ''}`);
  }
  return obj;
}

const num = (v, d = 0.5) => (typeof v === 'number' && isFinite(v)) ? v : d;

async function processItem(it) {
  let out = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      if (SYSTEM === 'aeroplus') {
        const callA = await llmJSON(l1Messages(it), { temp: 0.7 });   // reading diversity
        if (!callA) throw new Error('callA parse');
        const callB = await llmJSON(probeMessages(it));
        if (!callB) throw new Error('callB parse');
        const N = { h1: 1 - num(callB.h1?.still), h2: 1 - num(callB.h2?.still) };
        const S = { h1: num(callB.h1?.likely), h2: num(callB.h2?.likely) };
        out = { idx: it.idx, type: it.type, gold: String(it.gold), ask_for: it.ask_for,
                callA, N, S, system: 'aeroplus', useCF: true };
        if (kgScores && kgScores[it.idx]) out.kg = kgScores[it.idx];
      } else if (SYSTEM === 'cf_cot') {
        const res = await llmJSON(cfCotMessages(it));
        if (!res) return { idx: it.idx, type: it.type, gold: String(it.gold),
                           pred: null, conf: 0.5, abstain: false, error: 'parse', system: 'cf_cot' };
        let pred = String(res.answer);
        if (!['1', '2', '3'].includes(pred)) pred = null;
        out = { idx: it.idx, type: it.type, gold: String(it.gold),
                pred, conf: num(res.confidence), reasoning: res.reasoning || '',
                abstain: false, system: 'cf_cot' };
      } else throw new Error(`unknown system ${SYSTEM}`);
      if (!out.error) break;
      throw new Error(out.error);
    } catch (e) {
      console.log(`[${SYSTEM}] item ${it.idx} attempt ${attempt} failed: ${String(e.message || e).slice(0, 100)}`);
      if (attempt < 1) await new Promise(r2 => setTimeout(r2, 30000));
    }
  }
  if (out) fs.appendFileSync(OUTPUT, JSON.stringify(out) + '\n');
  return out;
}

async function main() {
  resolveBackend();
  if (BACKEND === 'zai-sdk') {
    const { default: ZAI } = await import('z-ai-web-dev-sdk');
    zai = await ZAI.create();
  }
  console.log(`[${SYSTEM}] backend=${BACKEND}` + (FETCH_CFG ? ` model=${FETCH_CFG.model || '(unset)'}` : ''));

  // startup self-test: one trivial JSON round-trip -> separates backend trouble from parse trouble
  let probeOk = false, probeErr = '';
  try {
    const probe = await llmJSON(
      [{ role: 'user', content: 'Reply with exactly this JSON and nothing else: {"ok":1,"n":2}' }],
      { temp: 0, retries: 4 });
    probeOk = !!probe && probe.ok === 1;
    if (!probeOk) probeErr = 'reply did not contain the expected JSON';
  } catch (e) { probeErr = String(e.message || e).slice(0, 160); }
  if (!probeOk) {
    console.error(`[${SYSTEM}] SELF-TEST FAIL: ${probeErr}`);
    if (BACKEND === 'zai-sdk')
      console.error('  backend=zai-sdk -> check .z-ai-config (JSON with baseUrl+apiKey) in the directory you launch from, or your home dir, or /etc. See [llm]/[empty-content] lines above for the concrete error.');
    else
      console.error(`  backend=${BACKEND} -> check llm_config.json or LLM_* env vars: baseUrl (ending in /v1), apiKey, model (required for fetch). See [llm]/[empty-content] lines above.`);
    process.exit(1);
  }
  console.log(`[${SYSTEM}] self-test PASS`);

  let i = 0, ok = 0, err = 0;
  async function worker() {
    while (i < todo.length) {
      const it = todo[i++];
      const r = await processItem(it);
      r ? (r.error ? err++ : ok++) : err++;
      if ((ok + err) % 10 === 0) console.log(`[${SYSTEM}] progress ${ok + err}/${todo.length} err=${err} calls=${callCount}`);
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  console.log(`[${SYSTEM}] DONE ok=${ok} err=${err} calls=${callCount}`);
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
