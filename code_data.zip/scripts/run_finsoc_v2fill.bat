@echo off
rem FINSOC v2 fill collection entry, small-scale edition (r2: zero test collection)
rem task1 (required, 200 calls): cal CoT -> default-direction selection
rem task2 (optional, 600 calls): cal k=3 consistency -> frozen-rule replication + trigger check
rem usage: scripts\run_finsoc_v2fill.bat verify|collect|collect-min|analyze
setlocal
cd /d "%~dp0.."
set MODE=%1
if "%MODE%"=="" set MODE=verify
set LIMIT=
if "%MODE%"=="verify" set LIMIT=--limit 2

if "%MODE%"=="analyze" goto analyze

for %%L in (en zh) do (
  rem task 1: cal CoT (100 items per language)
  node scripts\run_exp.mjs --system cot --input tmp\finsoc_%%L_cal_v1.jsonl --output tmp\results_cot_finsoc%%L_cal.jsonl %LIMIT%
  if errorlevel 1 goto fail
)
if "%MODE%"=="collect-min" goto done

for %%L in (en zh) do (
  rem task 2 (optional): k=3 consistency on cal
  node scripts\collect_consistency.mjs --input tmp\finsoc_%%L_cal_v1.jsonl --output tmp\results_selfcons3_finsoc%%L_cal.jsonl --k 3 --conc 4 %LIMIT%
  if errorlevel 1 goto fail
)
goto done

:analyze
for %%L in (en zh) do (
  python scripts\aeroplus\finsoc_v2_arbitrate.py --lang %%L
  if errorlevel 1 goto fail
)
goto done

:fail
echo [finsoc-v2fill] FAILED
exit /b 1

:done
echo [finsoc-v2fill] %MODE% done
