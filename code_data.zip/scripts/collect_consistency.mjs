#!/usr/bin/env node
/**
 * v2 consistency collector (FinSoC 补采任务②).
 *
 *   k 路 sampled CoT rollouts (temp 0.8), majority vote, stores ALL samples
 *   so v2's behavioural-consistency trigger (vote margin) can be computed
 *   offline. Prompt is BYTE-IDENTICAL to run_exp.mjs runSelfCons so the
 *   protocol stays comparable with the e-CARE selfcons arm.
 *
 *   node collect_consistency.mjs --input tmp/finsoc_en_test_v1.jsonl \
 *        --output tmp/results_selfcons3_finsocen.jsonl [--k 3] [--conc 4]
 *
 * Record schema (identical to results_selfcons_exp.jsonl + k field):
 *   {idx, type, gold, system:'selfcons', k, pred, conf, abstain:false,
 *    samples:[{answer:"1"|"2"|"3"|null, conf}], votes:{"1":n,...}}
 *
 * Resumable by idx. Sustained-429 -> exit code 13 (supervisor retries later).
 * Backend: env LLM_* / llm_config.json / z-ai-sdk (same as collect_v3.mjs).
 */
import fs from 'fs';
import path from 'path';

const args = Object.fromEntries(process.argv.slice(2).reduce((a, v, i, arr) => {
  if (v.startsWith('--')) a.push([v.slice(2), arr[i + 1]]);
  return a;
}, []));

const INPUT = args.input;
const OUTPUT = args.output;
const K = parseInt(args.k || '3', 10);
const CONCURRENCY = parseInt(args.conc || '4', 10);
const LIMIT = args.limit ? parseInt(args.limit, 10) : null;
if (!INPUT || !OUTPUT) { console.error('need --input and --output'); process.exit(1); }

const items = fs.readFileSync(INPUT, 'utf-8').trim().split('\n').map(JSON.parse);
const done = new Set(fs.existsSync(OUTPUT)
  ? fs.readFileSync(OUTPUT, 'utf-8').trim().split('\n').filter(Boolean).map(l => { try { return JSON.parse(l).idx; } catch { return null; } })
  : []);
const todo = items.filter(it => !done.has(it.idx)).slice(0, LIMIT || undefined);
console.log(`[selfcons] v2 collector | total=${items.length} done=${done.size} todo=${todo.length} k=${K}`);

// ---- three-channel backend (aligned with collect_v3.mjs) ----
let FETCH_CFG = null;
let BACKEND = 'unknown';
function envMaxTokens(v) {
  if (v === undefined || v === '') return 8192;
  const n = Number(v);
  return Number.isFinite(n) ? n : 8192;
}
function resolveBackend() {
  if (process.env.LLM_BASE_URL && process.env.LLM_API_KEY) {
    FETCH_CFG = { baseUrl: process.env.LLM_BASE_URL.replace(/\/+$/, ''),
                  apiKey: process.env.LLM_API_KEY, model: process.env.LLM_MODEL || '',
                  maxTokens: envMaxTokens(process.env.LLM_MAX_TOKENS), headers: {} };
    BACKEND = 'env-fetch';
    return;
  }
  const cfgPath = path.join(path.dirname(new URL(import.meta.url).pathname), 'llm_config.json');
  try {
    const cfg = JSON.parse(fs.readFileSync('llm_config.json', 'utf-8'));
    if (cfg.baseUrl && cfg.apiKey) {
      FETCH_CFG = { baseUrl: String(cfg.baseUrl).replace(/\/+$/, ''),
                    apiKey: String(cfg.apiKey), model: String(cfg.model || ''),
                    maxTokens: envMaxTokens(cfg.maxTokens), headers: cfg.headers || {},
                    thinking: cfg.thinking || null };
      BACKEND = 'file-fetch';
      return;
    }
  } catch { /* not present */ }
  BACKEND = 'zai-sdk';
}

let zai = null;
let callCount = 0;
let consec429 = 0;
const BACKOFFS = [2000, 5000, 10000];

async function llmFetch(messages, temp) {
  const body = { model: FETCH_CFG.model, messages, temperature: temp };
  if (FETCH_CFG.maxTokens) body.max_tokens = FETCH_CFG.maxTokens;
  if (FETCH_CFG.thinking) body.thinking = FETCH_CFG.thinking;
  if (!body.model) throw new Error('LLM_MODEL required for fetch backend (env or llm_config.json)');
  const res = await fetch(`${FETCH_CFG.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${FETCH_CFG.apiKey}`,
               ...(FETCH_CFG.headers || {}) },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const t = await res.text().catch(() => '');
    throw new Error(`HTTP ${res.status} ${t.slice(0, 120)}`);
  }
  const j = await res.json();
  const m = j.choices?.[0]?.message;
  if (m?.content && m.content.trim()) return m.content.trim();
  if (m?.reasoning_content) return String(m.reasoning_content).trim();
  throw new Error('empty response');
}

async function llm(messages, { temp = 0, retries = 3 } = {}) {
  for (let a = 1; a <= retries; a++) {
    try {
      callCount++;
      if (FETCH_CFG) { const r = await llmFetch(messages, temp); consec429 = 0; return r; }
      const completion = await zai.chat.completions.create({
        messages, thinking: { type: 'disabled' }, temperature: temp,
      });
      const m = completion.choices?.[0]?.message;
      if (m?.content && m.content.trim()) { consec429 = 0; return m.content.trim(); }
      if (m?.reasoning_content) { consec429 = 0; return String(m.reasoning_content).trim(); }
      throw new Error('empty response');
    } catch (e) {
      const msg = String(e.message || e);
      console.error(`  [llm] attempt ${a}/${retries} failed: ${msg.slice(0, 160)}`);
      if (/429|rate|quota|too many/i.test(msg)) {
        consec429++;
        if (consec429 >= 8) {
          console.error('[quota] 8 consecutive 429s - quota window exhausted, aborting round (rerun to resume)');
          process.exit(13);
        }
      }
      const wait = BACKOFFS[Math.min(a - 1, BACKOFFS.length - 1)];
      if (a === retries) throw e;
      await new Promise(r => setTimeout(r, wait + (/429|rate|quota|too many/i.test(msg) ? wait * 2 : 0)));
    }
  }
}

function parseJSON(text) {
  let t = String(text).trim()
    .replace(/<think>[\s\S]*?<\/think>/gi, '')
    .replace(/```json/gi, '```').replace(/```/g, '');
  const s = t.indexOf('{'), e = t.lastIndexOf('}');
  if (s >= 0 && e > s) t = t.slice(s, e + 1);
  return JSON.parse(t);
}

async function llmJSON(messages, opts = {}) {
  const txt = await llm(messages, opts);
  try { return parseJSON(txt); } catch {
    const txt2 = await llm([...messages,
      { role: 'user', content: 'Your previous output was not valid JSON. Return ONLY the valid JSON object, no other text.' },
    ], { temp: 0 });
    try { return parseJSON(txt2); } catch {
      console.error(`  [parse-fail] raw reply (${String(txt).length} chars): ${String(txt).replace(/\s+/g, ' ').slice(0, 140)}`);
      return null;
    }
  }
}

const num = (v, d = 0.5) => {
  const x = typeof v === 'number' ? v : parseFloat(v);
  return Number.isFinite(x) ? Math.min(1, Math.max(0, x)) : d;
};

// ---- prompt: byte-identical to run_exp.mjs runSelfCons ----
const DIRTXT = { cause: 'possible CAUSES of the premise event', effect: 'possible EFFECTS of the premise event' };
const fmt = it => `Premise: ${it.premise}\nWe are looking for ${DIRTXT[it.ask_for]}.\nCandidate 1: ${it.h1}\nCandidate 2: ${it.h2}`;

async function runSelfCons(it, k) {
  const sys = 'You are an expert in event-level causal reasoning. Answer with a single JSON object only.';
  const user = `${fmt(it)}\n\nOptions: "1" = Candidate 1 is the ${it.ask_for}, "2" = Candidate 2 is the ${it.ask_for}, "3" = NEITHER candidate has a genuine causal link with the premise.\nThink step by step, then decide.\nReturn JSON: {"answer": "1"|"2"|"3", "confidence": <0-1>}`;
  const samples = [];
  for (let i = 0; i < k; i++) {
    const res = await llmJSON([
      { role: 'system', content: sys },
      { role: 'user', content: user },
    ], { temp: 0.8 });
    let a = res ? String(res.answer) : null;
    if (!['1', '2', '3'].includes(a)) a = null;
    samples.push({ answer: a, conf: res ? num(res.confidence) : null });
  }
  const votes = {};
  for (const s of samples) if (s.answer) votes[s.answer] = (votes[s.answer] || 0) + 1;
  const valid = Object.values(votes).reduce((a, b) => a + b, 0);
  const pred = valid ? Object.entries(votes).sort((x, y) => y[1] - x[1])[0][0] : null;
  const conf = pred ? votes[pred] / valid : 0.34;
  return { pred, conf, abstain: false, samples, votes };
}

async function processItem(it) {
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const r = await runSelfCons(it, K);
      if (!r.pred) throw new Error('no valid answer in any sample');
      const out = { idx: it.idx, type: it.type, gold: String(it.gold),
                    system: 'selfcons', k: K, ...r };
      fs.appendFileSync(OUTPUT, JSON.stringify(out) + '\n');
      return out;
    } catch (e) {
      console.log(`[selfcons] item ${it.idx} attempt ${attempt} failed: ${String(e.message || e).slice(0, 100)}`);
      if (attempt < 2) await new Promise(r2 => setTimeout(r2, 30000));
    }
  }
  return null;   // not written -> resumable rerun picks it up
}

async function main() {
  resolveBackend();
  if (BACKEND === 'zai-sdk') {
    const { default: ZAI } = await import('z-ai-web-dev-sdk');
    zai = await ZAI.create();
  }
  console.log(`[selfcons] backend=${BACKEND}` + (FETCH_CFG ? ` model=${FETCH_CFG.model || '(unset)'}` : ''));

  // startup self-test (same trivial JSON round-trip as collect_v3)
  let probeOk = false, probeErr = '';
  try {
    const probe = await llmJSON(
      [{ role: 'user', content: 'Reply with exactly this JSON and nothing else: {"ok":1,"n":2}' }],
      { temp: 0, retries: 4 });
    probeOk = !!probe && probe.ok === 1;
    if (!probeOk) probeErr = 'reply did not contain the expected JSON';
  } catch (e) { probeErr = String(e.message || e).slice(0, 160); }
  if (!probeOk) {
    console.error(`[selfcons] SELF-TEST FAIL: ${probeErr}`);
    console.error('  check llm_config.json or LLM_* env vars: baseUrl (ending in /v1), apiKey, model');
    process.exit(1);
  }
  console.log(`[selfcons] self-test PASS`);

  let i = 0, ok = 0, err = 0;
  async function worker() {
    while (i < todo.length) {
      const it = todo[i++];
      const r = await processItem(it);
      r ? ok++ : err++;
      if ((ok + err) % 20 === 0) console.log(`[selfcons] progress ${ok + err}/${todo.length} err=${err} calls=${callCount}`);
    }
  }
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));
  console.log(`[selfcons] DONE ok=${ok} err=${err} calls=${callCount}`);
}

main().catch(e => { console.error('FATAL', e); process.exit(1); });
