#!/bin/bash
# AERO+ v4 supervisor: expanded e-CARE (450) + XCOPA 4 languages.
# Priority order (paper-critical first). Resumable by idx; 429-tolerant.
cd "$(dirname "$0")/.."
LOG=tmp/supervisor_v4.log
echo "$(date +%F' '%T) supervisor_v4 start" >> $LOG

need() { n=$(wc -l < "$1" 2>/dev/null || echo 0); [ "$n" -lt "$2" ]; }

for round in $(seq 1 600); do
  # P1 e-CARE expansion: main system (confirmation experiment)
  need tmp/results_aero_exp.jsonl 450 && \
    timeout 100 node scripts/collect_v3.mjs --system aeroplus \
      --input tmp/exp_items_v2.jsonl --output tmp/results_aero_exp.jsonl --conc 4 2>/dev/null
  # P2 e-CARE expansion: cf_cot competitor
  need tmp/results_cfcot_exp.jsonl 450 && \
    timeout 100 node scripts/collect_v3.mjs --system cf_cot \
      --input tmp/exp_items_v2.jsonl --output tmp/results_cfcot_exp.jsonl --conc 4 2>/dev/null
  # P2b e-CARE expansion: cot + zeroshot baselines
  need tmp/results_cot_exp.jsonl 450 && \
    timeout 100 node scripts/run_exp.mjs --system cot \
      --input tmp/exp_items_v2.jsonl --output tmp/results_cot_exp.jsonl --conc 4 2>/dev/null
  need tmp/results_zeroshot_exp.jsonl 450 && \
    timeout 100 node scripts/run_exp.mjs --system zeroshot \
      --input tmp/exp_items_v2.jsonl --output tmp/results_zeroshot_exp.jsonl --conc 4 2>/dev/null
  # P2c e-CARE expansion: newer top-venue baselines (NeurIPS24/25) + selfcons
  for SYS in selfcons pnps sn_cot g2; do
    need tmp/results_${SYS}_exp.jsonl 450 && \
      timeout 100 node scripts/run_exp.mjs --system $SYS \
        --input tmp/exp_items_v2.jsonl --output tmp/results_${SYS}_exp.jsonl --conc 4 2>/dev/null
    need tmp/results_${SYS}_cal_v3.jsonl 60 && \
      timeout 100 node scripts/run_exp.mjs --system $SYS \
        --input tmp/cal_items_v3.jsonl --output tmp/results_${SYS}_cal_v3.jsonl --conc 4 2>/dev/null
  done
  # P3 XCOPA: cal + test per language, main system then baselines
  for L in zh vi th sw; do
    need tmp/results_aero_xc${L}_cal.jsonl 30 && \
      timeout 100 node scripts/collect_v3.mjs --system aeroplus \
        --input tmp/xcopa_${L}_cal.jsonl --output tmp/results_aero_xc${L}_cal.jsonl --conc 4 2>/dev/null
    need tmp/results_aero_xc${L}.jsonl 100 && \
      timeout 100 node scripts/collect_v3.mjs --system aeroplus \
        --input tmp/xcopa_${L}_test.jsonl --output tmp/results_aero_xc${L}.jsonl --conc 4 2>/dev/null
  done
  for L in zh vi th sw; do
    need tmp/results_cot_xc${L}.jsonl 100 && \
      timeout 100 node scripts/run_exp.mjs --system cot \
        --input tmp/xcopa_${L}_test.jsonl --output tmp/results_cot_xc${L}.jsonl --conc 4 2>/dev/null
  done
  for L in zh vi th sw; do
    need tmp/results_cfcot_xc${L}.jsonl 100 && \
      timeout 100 node scripts/collect_v3.mjs --system cf_cot \
        --input tmp/xcopa_${L}_test.jsonl --output tmp/results_cfcot_xc${L}.jsonl --conc 4 2>/dev/null
  done
  # progress heartbeat
  echo "$(date +%T) r$round | aero_exp=$(wc -l < tmp/results_aero_exp.jsonl 2>/dev/null || echo 0) cfcot_exp=$(wc -l < tmp/results_cfcot_exp.jsonl 2>/dev/null || echo 0) cot_exp=$(wc -l < tmp/results_cot_exp.jsonl 2>/dev/null || echo 0) zs_exp=$(wc -l < tmp/results_zeroshot_exp.jsonl 2>/dev/null || echo 0) xc_aero=$(cat tmp/results_aero_xc*.jsonl 2>/dev/null | wc -l)" >> $LOG
  # all-done check
  total=$(cat tmp/results_aero_exp.jsonl tmp/results_cfcot_exp.jsonl tmp/results_cot_exp.jsonl tmp/results_zeroshot_exp.jsonl tmp/results_selfcons_exp.jsonl tmp/results_pnps_exp.jsonl tmp/results_sn_cot_exp.jsonl tmp/results_g2_exp.jsonl tmp/results_aero_xc*.jsonl tmp/results_cot_xc*.jsonl tmp/results_cfcot_xc*.jsonl 2>/dev/null | wc -l)
  [ "$total" -ge 5220 ] && { echo "$(date +%T) ALL DONE" >> $LOG; break; }
  sleep 20
done
